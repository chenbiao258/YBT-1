package com.service;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;


import com.util.*;
public class WMSWebService {

	public String getValue(String id,String tConfDoc){
		System.out.println("进入getValue");
		WebServiceConfig w=new WebServiceConfig();
		Document cConfDoc=w.load();
		@SuppressWarnings("unchecked")
		List<Element> mSocketList = cConfDoc.getRootElement().getChildren("bea");
		String result=null;
		for (int i = 0; i < mSocketList.size(); i++) {
			Element ttSocket = mSocketList.get(i);
			if(ttSocket.getChildText("id").equals(id)){
				System.out.println(ttSocket.getChildText("name"));
				
				result=w.invokeRemoteFuc(ttSocket.getChildText("method"), ttSocket.getChildText("url"), tConfDoc, ttSocket.getChildText("packagePath"));
				System.out.println(result+"=====================================");
				break;
			}else{
				continue;
			}
			
		}
		return result;
	}


	public String getValue1(String a){
		System.out.println("进入方法getValue1");
		return "测试";
	}

	

}
