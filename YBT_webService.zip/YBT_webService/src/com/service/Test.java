package com.service;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String url= "http://10.70.16.24:8888/bank/BanktWebService";
		url = "http://127.0.0.1:9999/bankybt/services/AService";
		url = "http://localhost:8080/YBT_webService/services/WMSService";
		
		//url = "http://10.192.65.44:7001/ybtbank/services/WMSService";
		String operater = "P_Bankt_PoPrint";
		operater = "getValue";
		String a="002";
		try{
			Call call;
			Service service = new Service();
			call = (Call) service.createCall();
			call.setTargetEndpointAddress(url);  
			call.setOperation(operater); 
			String result=(String) call.invoke(new Object[] {a,"我事陈彪"});
			
			System.out.println(result);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
