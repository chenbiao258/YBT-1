package com.service;

import java.io.IOException;
import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.ServiceException;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;


public class webServiceTest {
	public String invokeRemoteFuc(String method,String xmlText) {
		//String endpoint = "http://uat-wealth-fps-hbcn.hk.hsbc:30001/fps-ws-web/GoalSolutionWebServiceEndpoint";
		String endpoint = "http://192.168.8.101:8080/new_eservice_business/ybt/HelloWorld";
		endpoint = "http://localhost:8080/YBT_webService/services/WMSService";
		String result ="";
		Service service = new Service();
		Call call;
		Object[] object = new Object[2];
		object[0] = "002";//Object是用来存储方法的参数
		object[1] = xmlText;
		try {
			call = (Call) service.createCall();
			call.setTargetEndpointAddress(endpoint);// 远程调用路径
//			call.setOperationName(method);// 调用的方法名
			call.setOperationName(new QName("http://cxftest.ui.business.service.sinosoft.com/", method));
			
			try {
				call.setTimeout(15000);//15秒超时
			} catch (Exception e) {
				System.out.println("连接超时");
				e.printStackTrace();
			}
		
			result = (String) call.invoke(object);// 远程调用
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) {
		webServiceTest webServiceTest =new webServiceTest();		
		String result=webServiceTest.invokeRemoteFuc("getValue", "我是谁谁谁");
		System.out.println(result);
	}
}
