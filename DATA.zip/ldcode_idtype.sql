prompt Importing table ldcode...
set feedback off
set define off
insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'A', '�������ô���/INSTITU CREDIT CODE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'B', '��֯��������֤/ENTERPRISE CODE CERT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'D', '��ʻִ��/DRIVING LICENCE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'E', 'ʿ��֤/SOLDIER''S ID CARD', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'F', '����֤/MILITARY OFFICER ID', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'I', '��������֤/IDENTITY CARD', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'L', '˰��Ǽ�֤����˰��/LOCAL TAX REG CERT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'N', '��װ��������֤/POLICEMAN ID CARD', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'P', '����/PASSPORT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'R', '��ְ�ɲ�֤/CARDRE''S ID CARD', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'T', '˰��Ǽ�֤����˰��/STATE TAX REG CERT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'U', 'UNDEFINED ID TYPE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'X', '�۰�̨����ͨ��֤/PASS TO MAINLAND PRC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idtype', 'Z', 'Ӫҵִ��/BUSI LISC/REGIS CERT', null, null, null);

prompt Done.
