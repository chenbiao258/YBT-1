prompt Importing table ldcode...
set feedback off
set define off
insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AD', '������/ANDORRA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AE', '������/UNITED ARAB EMIRATES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AF', '������/AFGHANISTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AG', '����ϣ�����/ANTIGUA AND BARBUDA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AI', 'ANGUILLA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AL', '����������/ALBANIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AM', '��������/ARMENIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AN', '������˹Ⱥ��/NETHERLAND ANTILLES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AO', '������/ANGOLA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AQ', '�ϼ���/ANTARCTICA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AR', '����͢/ARGENTINA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AS', '��Ħ��Ⱥ��/AMERICAN SAMOA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AT', '�µ���/AUSTRIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AU', '�Ĵ�����/AUSTRALIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AW', 'ARUBA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AX', 'ALAND ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'AZ', '�����ݽ�/AZERBAIJAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BA', '��˹���Ǻͺ�����ά��/BOSNIA AND HERZEGOVINA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BB', '�ͰͶ�˹������/BARBADOS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BD', '�ϼ�����/BANGLADESH', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BE', '����ʱ/BELGIUM', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BF', 'BURKINA FASO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BG', '��������/BULGARIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BH', '���֣�����/BAHRAIN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BI', '��¡��/BURUNDI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BJ', '����/BENIN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BL', 'SAINT BARTHELEMY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BM', '��Ľ��Ⱥ��/BERMUDA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BN', '����/BRUNEI DARUSSALAM', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BO', '����ά��/BOLIVIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BQ', 'BONAIR, SAINT EUSTATIAS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BR', '����/BRAZIL', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BS', '�͹���Ⱥ��/BAHAMAS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BT', '����/BHUTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BV', 'BOUVET ISLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BW', '��������/BOTSWANA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BY', 'BELARUS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'BZ', '������/BELIZE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CA', '���ô�/CANADA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CC', 'COCOS (KELLING) ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CD', '�չ��������͹�/CONGO DEMOCRATIC REP OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CF', '�зǹ��͹�/CENTRAL AFRICAN REPUBLIC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CG', '�չ�/CONGO PEOPLE REP OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CH', '��ʿ/SWITZERLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CI', '��������/COTE D''IVOIRE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CK', '�¿˵�/COOK ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CL', '����/CHILE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CM', '����¡/CAMEROON', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CN', '�й�/CHINA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CO', '���ױ���/COLOMBIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CR', '��˹�����/COSTA RICA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CU', '�Ű�/CUBA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CV', '��ý�/CAPE VERDE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CW', 'CURACAO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CX', 'CHRISTMAS ISLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CY', '����·˹/CYPRUS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'CZ', '�ݿ�/CZECH REPUBLIC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'DE', '�¹�/GERMANY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'DJ', '������/DJIBOUTI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'DK', '����/DENMARK', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'DM', '�������/DOMINICA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'DO', '������ӹ��͹�/DOMINICAN REPUBLIC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'DZ', '����������/ALGERIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'EC', '��϶��/ECUADOR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'EE', 'ESTONIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'EG', '����/EGYPT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'EH', 'WESTERN SAHARA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'EO', 'INT ORG (NOT FOR CUS IN)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ER', 'THE STATE OF ERITREA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ES', '������/SPAIN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ET', '����������/ETHIOPIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'EU', 'EUR U (NOT FOR CUS INFO)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FI', '����/FINLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FJ', '쳼�/FIJI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FK', 'FALKLAND IS (MALVINAS)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FM', 'MICRONESIA-FED STATES OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FO', 'FAROE ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FR', '����/FRANCE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'FX', 'FRANCE, METROPOLITAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GA', '����/GABON', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GB', 'Ӣ��/UNITED KINGDOM', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GD', '�����ɴ����/GRENADA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GE', '��³����/GEORGIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GF', 'FRENCH GUIANA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GG', 'CHANNEL ISLANDS,GUERNSEY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GH', '����/GHANA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GI', 'ֱ������/GIBRALTAR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GL', '��������������/GREENLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GM', '�Ա���/GAMBIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GN', '������/GUINEA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GP', '�ϵ����գ�����/GUADELOUPE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GQ', '���������/EQUATORIAL GUINEA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GR', 'ϣ��/GREECE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GS', 'SO GEORGIA & SO SANDWICH', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GT', 'Σ������/GUATEMALA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GU', '�ص�/GUAM', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GW', '�����ǣ����ܣ�/GUINEA-BISSAU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'GY', '������/GUYANA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'HK', '�й����/HONG KONG', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'HM', 'HEARD & MCDONALD IS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'HN', '�鶼��˹/HONDURAS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'HR', '���޵���/CROATIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'HT', '����/HAITI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'HU', '������/HUNGARY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ID', 'ӡ��������/INDONESIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IE', '������/IRELAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IL', '��ɫ��/ISRAEL', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IM', 'ISLE OF MAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IN', 'ӡ��/INDIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IO', 'ӡ����Ⱥ��/BRITISH INDIAN OCEAN TER', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IQ', '������/IRAQ', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IR', '����/IRAN (ISLAMIC REP OF)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IS', '����/ICELAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'IT', '�����/ITALY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'JE', 'CHANNEL ISLANDS, JERSEY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'JM', '�����/JAMAICA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'JO', 'Լ��/JORDAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'JP', '�ձ�/JAPAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KE', '������/KENYA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KG', 'KYRGYZSTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KH', '����կ/CAMBODIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KI', 'KIRIBATI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KM', 'COMOROS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KN', 'SAINT KITTS AND NEVIS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KP', '����/KOREA, D PEOPLE''S REP OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KR', '����/KOREA, REPUBLIC OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KW', '������/KUWAIT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KY', 'CAYMAN ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'KZ', '������/KAZAKHSTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LA', '����/LAO PEOPLE''S D REPUBLIC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LB', '�����/LEBANON', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LC', 'ST LUCIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LI', '��֧��ʿ��/LIECHTENSTEIN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LK', '˹������/SRI LANKA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LR', '��������/LIBERIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LS', '������/LESOTHO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LT', '������/LITHUANIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LU', '¬ɭ��/LUXEMBOURG', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LV', '����ά��/LATVIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'LY', '������/LIBYAN ARAB JAMAHIRIYA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MA', 'Ħ���/MOROCCO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MC', 'Ħ�ɸ�/MONACO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MD', 'Ħ������/MOLDOVA, REPUBLIC OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ME', 'REPUBLIC OF MONTENEGRO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MF', 'SAINT MARTIN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MG', '�����˹��/MADAGASCAR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MH', '���ܶ�Ⱥ��/MARSHALL ISLANDS-REP OF', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MK', '�����/MACEDONIA,FORMER YUGOSL', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ML', '����/MALI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MM', 'MYANMAR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MN', '�ɹ�/MONGOLIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MO', '����/MACAU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MP', '����������Ⱥ��/NORTHERN MARIANA IS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MQ', '������ˣ�����/MARTINQUE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MR', 'ë��������/MAURITANIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MS', 'MONTSERRAT', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MT', '������/MALTA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MU', 'ë����˹/MAURITIUS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MV', '��������/MALDIVES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MW', '����ά/MALAWI', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MX', 'ī����/MEXICO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MY', '��������/MALAYSIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'MZ', 'Īɣ�ȿ�/MOZAMBIQUE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NA', '���ױ���/NAMIBIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NC', 'NEW CALEDONIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NE', '���ն�/NIGER', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NF', 'ŵ���˵�/NORFOLK ISLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NG', '��������/NIGERIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NI', '�������/NICARAGUA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NL', '����/NETHERLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NO', 'Ų��/NORWAY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NP', '�Ჴ��/NEPAL', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NR', '�³/NAURU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NU', 'NIUE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'NZ', '������/NEW ZEALAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'OI', 'OFFSHORE ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'OM', '����/OMAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'OO', 'INT ORG (NOT FOR CUS IN)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PA', '������/PANAMA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PE', '��³/PERU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PF', '����������/FRENCH POLYNESIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PG', '�Ͳ����¼�����/PAPUA NEW GUINEA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PH', '���ɱ�/PHILIPPINES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PK', '�ͻ�˹̹/PAKISTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PL', '����/POLAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PM', 'ST PIERRE & MIQUELON', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PN', 'PITCAIRN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PR', '�������/PUERTO RICO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PS', 'PALESTINIAN TERRITORY OC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PT', '������/PORTUGAL', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PW', 'PALAU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PY', '������/PARAGUAY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'PZ', 'PANAMA CANAL ZONE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'QA', '������/QATAR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'RE', '��������/REUNION', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'RO', '��������/ROMANIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'RS', 'SERBIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'RU', '����˹��������/RUSSIA FEDERATION', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'RW', '¬����/RWANDA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SA', 'ɳ�ذ�����/SAUDI ARABIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SB', '������Ⱥ��/SOLOMON ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SC', '�����Ⱥ��/SEYCHELLES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SD', '���յ�/SUDAN NORTH', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SE', '���/SWEDEN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SG', '�¼���/SINGAPORE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SH', 'ST HELENA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SI', '˹��������/SLOVENIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SJ', 'SVALBARD & JAN MAYEN IS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SK', '˹�工��/SLOVAKIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SL', 'SIERRA LEONE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SM', 'SAN MARINO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SN', '���ڼӶ�/SENEGAL', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SO', '������/SOMALIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SR', '������/SURINAM', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SS', 'SOUTH SUDAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ST', 'ʥ���������������ȵ�/SAO TOME AND PRINCIPE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SV', '�����߶�/EL SALVADOR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SX', 'SINT MAARTEN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SY', '������/SYRIAN ARAB REPUBLIC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'SZ', '˹��ʿ��/SWAZILAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TC', 'TURKS AND CAICOS ISLANDS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TD', 'է��/CHAD', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TF', 'FRENCH SOUTHERN TER', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TG', '���/TOGO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TH', '̩��/THAILAND', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TJ', 'TAJIKISTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TK', 'TOKELAU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TL', 'TIMOR-LESTE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TM', '������/TURKMENISTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TN', 'ͻ��˹/TUNISIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TO', '����/TONGA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TP', '������/EAST TIMOR', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TR', '������/TURKEY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TT', '�������Ͷ�͸�/TRINIDAD & TOBAGO', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TV', 'TUVALU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TW', '̨��/TAIWAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'TZ', '̹ɣ����/TANZANIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'UA', '�ڿ���/UKRAINE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'UG', '�ڸɴ�/UGANDA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'UM', 'US MINOR OUTLYING IS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'US', '����/UNITED STATES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'UY', '������/URUGUAY', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'UZ', '���ȱ��/UZBEKISTAN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VA', '��ٸ�/VATICAN CITY STATE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VC', 'ST VINCENT & GRENADINES', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VE', 'ί������/VENEZUELA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VG', 'ά����Ⱥ��/VIRGIN ISLANDS(BRITISH)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VI', 'VIRGIN ISLANDS (U.S.)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VN', 'Խ��/VIETNAM', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'VU', 'VANUATU', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'WB', 'WEST BANK - PALESTINE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'WF', 'WALLIS AND FUTUNA IS', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'WS', '��Ħ��Ⱥ��/SAMOA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'XE', '��ó����ؿͻ�/CROSS-CITY FTZ CUSTOMER', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'XF', '��ó��ͬ�ǿͻ�/SAME CITY FTZ CUSTOMER', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'XX', '�й������ؾ���/CN (WITHIN LOCAL PBOC)', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'YD', 'YEMEN DEMOCRATIC', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'YE', 'Ҳ��/YEMEN', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'YT', 'MAYOTTE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ZA', '�Ϸ�/SOUTH AFRICA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ZM', '�ޱ���/ZAMBIA', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ZW', '��Ͳ�Τ/ZIMBABWE', null, null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('iss_country', 'ZZ', 'δע��/UNDEFINED', null, null, null);

prompt Done.
