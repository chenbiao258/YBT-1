package com.service;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.axis.client.Call;


public class URLpostXML {
	
	
	 void testPost(String urlStr) {
	        try {
	            URL url = new URL(urlStr);
	            URLConnection conn = url.openConnection();
	            HttpURLConnection con=(HttpURLConnection) conn;
	            con.setDoInput(true);
	            con.setDoOutput(true);
	            con.setRequestMethod("post");
	            
	            con.setRequestProperty("content-type", "text/xml;charset=UTF-8");
	            String xml="陈彪";
	            OutputStream out=con.getOutputStream();
	            out.write(xml.getBytes());
	            out.close();
	            
	            int code=con.getResponseCode();
	            if(code == 200){//服务端返回正常
	            	System.out.println("成功");
	            	InputStream is = con.getInputStream();
	            	 byte[] b = new byte[1024];
	            	 StringBuffer sb = new StringBuffer();
	            	 int len = 0;
	            	 while((len = is.read(b)) != -1){
	            		 String str = new String(b,0,len,"UTF-8");
	            		 sb.append(str);
	            		}
	            	 System.out.println(sb.toString());
	            	 is.close();
	            }
	            con.disconnect();
	            
	        } catch (MalformedURLException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private String getXmlInfo() {
	        StringBuilder sb = new StringBuilder();
	        sb.append("<videoSend>");
	        sb.append("    <header>");
	        sb.append("        <sid>1</sid>");
	        sb.append("        <type>service</type>");
	        sb.append("    </header>");
	        sb.append("    <service name=\"videoSend\">");
	        sb.append("        <fromNum>0000021000011001</fromNum>");
	        sb.append("           <toNum>33647405</toNum>");
	        sb.append("        <videoPath>mnt/5.0.217.50/resources/80009.mov</videoPath>");
	        sb.append("        <chargeNumber>0000021000011001</chargeNumber>");
	        sb.append("    </service>");
	        sb.append("</videoSend>");
	        return sb.toString();
	    }
	    
	    

	   /* public static void main(String[] args) {
	        String url = "http://192.168.8.101:8080/YBT_webService/services/WMSService?wsdl";
	        new URLpostXML().testPost(url);
	    }*/
	
	    
	    public static void main(String[] args) {
	    	try {
				URL url=new URL("http://192.168.8.107:8080/YBT_webService/services/WMSService");
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	
	    	 
		}
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
}
