
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.AlternativeProductAttribute;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.GoalSolutionRiderInformation;


/**
 * <p>alternativeProduct complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="alternativeProduct"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="alternativeProductAttribute" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}alternativeProductAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalSolutionRiderInformationList" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalSolutionRiderInformation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productId" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "alternativeProduct", propOrder = {
    "alternativeProductAttribute",
    "goalSolutionRiderInformationList",
    "productId"
})
public class AlternativeProduct {

    @XmlElement(nillable = true)
    protected List<AlternativeProductAttribute> alternativeProductAttribute;
    @XmlElement(nillable = true)
    protected List<GoalSolutionRiderInformation> goalSolutionRiderInformationList;
    @XmlElement(nillable = true)
    protected List<ProductId> productId;

    /**
     * Gets the value of the alternativeProductAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternativeProductAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternativeProductAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AlternativeProductAttribute }
     * 
     * 
     */
    public List<AlternativeProductAttribute> getAlternativeProductAttribute() {
        if (alternativeProductAttribute == null) {
            alternativeProductAttribute = new ArrayList<AlternativeProductAttribute>();
        }
        return this.alternativeProductAttribute;
    }

    /**
     * Gets the value of the goalSolutionRiderInformationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalSolutionRiderInformationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalSolutionRiderInformationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalSolutionRiderInformation }
     * 
     * 
     */
    public List<GoalSolutionRiderInformation> getGoalSolutionRiderInformationList() {
        if (goalSolutionRiderInformationList == null) {
            goalSolutionRiderInformationList = new ArrayList<GoalSolutionRiderInformation>();
        }
        return this.goalSolutionRiderInformationList;
    }

    /**
     * Gets the value of the productId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductId }
     * 
     * 
     */
    public List<ProductId> getProductId() {
        if (productId == null) {
            productId = new ArrayList<ProductId>();
        }
        return this.productId;
    }

}
