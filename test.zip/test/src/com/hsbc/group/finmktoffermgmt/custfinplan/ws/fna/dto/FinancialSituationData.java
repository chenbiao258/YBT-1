
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.dto.Dependant;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.dto.EmergencyFund;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.Comment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CommentAction;


/**
 * <p>financialSituationData complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="financialSituationData"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="comment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="commentAction" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}commentAction" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="countryISOCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dependant" type="{http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}dependant" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="emergencyFund" type="{http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}emergencyFund" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="emergencyFundCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="financialSituationDetail" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}financialSituationDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="fxRate" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}fxRate" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="groupMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="insurancePolicy" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}insurancePolicy" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="insurancePriority" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}insurancePriority" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investorIndicator" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investorIndicator" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="rolePlayerIdentificationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "financialSituationData", propOrder = {
    "comment",
    "commentAction",
    "countryISOCode",
    "currencyCode",
    "dependant",
    "emergencyFund",
    "emergencyFundCurrencyCode",
    "financialSituationDetail",
    "fxRate",
    "groupMemberCode",
    "insurancePolicy",
    "insurancePriority",
    "investorIndicator",
    "rolePlayerIdentificationNumber"
})
public class FinancialSituationData {

    @XmlElement(nillable = true)
    protected List<Comment> comment;
    @XmlElement(nillable = true)
    protected List<CommentAction> commentAction;
    protected String countryISOCode;
    protected String currencyCode;
    @XmlElement(nillable = true)
    protected List<Dependant> dependant;
    @XmlElement(nillable = true)
    protected List<EmergencyFund> emergencyFund;
    protected String emergencyFundCurrencyCode;
    @XmlElement(nillable = true)
    protected List<FinancialSituationDetail> financialSituationDetail;
    @XmlElement(nillable = true)
    protected List<FxRate> fxRate;
    protected String groupMemberCode;
    @XmlElement(nillable = true)
    protected List<InsurancePolicy> insurancePolicy;
    @XmlElement(nillable = true)
    protected List<InsurancePriority> insurancePriority;
    @XmlElement(nillable = true)
    protected List<InvestorIndicator> investorIndicator;
    protected String rolePlayerIdentificationNumber;

    /**
     * Gets the value of the comment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<Comment>();
        }
        return this.comment;
    }

    /**
     * Gets the value of the commentAction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the commentAction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCommentAction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommentAction }
     * 
     * 
     */
    public List<CommentAction> getCommentAction() {
        if (commentAction == null) {
            commentAction = new ArrayList<CommentAction>();
        }
        return this.commentAction;
    }

    /**
     * ��ȡcountryISOCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryISOCode() {
        return countryISOCode;
    }

    /**
     * ����countryISOCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryISOCode(String value) {
        this.countryISOCode = value;
    }

    /**
     * ��ȡcurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * ����currencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the dependant property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dependant property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDependant().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Dependant }
     * 
     * 
     */
    public List<Dependant> getDependant() {
        if (dependant == null) {
            dependant = new ArrayList<Dependant>();
        }
        return this.dependant;
    }

    /**
     * Gets the value of the emergencyFund property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emergencyFund property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmergencyFund().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmergencyFund }
     * 
     * 
     */
    public List<EmergencyFund> getEmergencyFund() {
        if (emergencyFund == null) {
            emergencyFund = new ArrayList<EmergencyFund>();
        }
        return this.emergencyFund;
    }

    /**
     * ��ȡemergencyFundCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmergencyFundCurrencyCode() {
        return emergencyFundCurrencyCode;
    }

    /**
     * ����emergencyFundCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmergencyFundCurrencyCode(String value) {
        this.emergencyFundCurrencyCode = value;
    }

    /**
     * Gets the value of the financialSituationDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the financialSituationDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFinancialSituationDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FinancialSituationDetail }
     * 
     * 
     */
    public List<FinancialSituationDetail> getFinancialSituationDetail() {
        if (financialSituationDetail == null) {
            financialSituationDetail = new ArrayList<FinancialSituationDetail>();
        }
        return this.financialSituationDetail;
    }

    /**
     * Gets the value of the fxRate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fxRate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFxRate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FxRate }
     * 
     * 
     */
    public List<FxRate> getFxRate() {
        if (fxRate == null) {
            fxRate = new ArrayList<FxRate>();
        }
        return this.fxRate;
    }

    /**
     * ��ȡgroupMemberCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupMemberCode() {
        return groupMemberCode;
    }

    /**
     * ����groupMemberCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupMemberCode(String value) {
        this.groupMemberCode = value;
    }

    /**
     * Gets the value of the insurancePolicy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the insurancePolicy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInsurancePolicy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InsurancePolicy }
     * 
     * 
     */
    public List<InsurancePolicy> getInsurancePolicy() {
        if (insurancePolicy == null) {
            insurancePolicy = new ArrayList<InsurancePolicy>();
        }
        return this.insurancePolicy;
    }

    /**
     * Gets the value of the insurancePriority property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the insurancePriority property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInsurancePriority().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InsurancePriority }
     * 
     * 
     */
    public List<InsurancePriority> getInsurancePriority() {
        if (insurancePriority == null) {
            insurancePriority = new ArrayList<InsurancePriority>();
        }
        return this.insurancePriority;
    }

    /**
     * Gets the value of the investorIndicator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investorIndicator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestorIndicator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestorIndicator }
     * 
     * 
     */
    public List<InvestorIndicator> getInvestorIndicator() {
        if (investorIndicator == null) {
            investorIndicator = new ArrayList<InvestorIndicator>();
        }
        return this.investorIndicator;
    }

    /**
     * ��ȡrolePlayerIdentificationNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRolePlayerIdentificationNumber() {
        return rolePlayerIdentificationNumber;
    }

    /**
     * ����rolePlayerIdentificationNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRolePlayerIdentificationNumber(String value) {
        this.rolePlayerIdentificationNumber = value;
    }

}
