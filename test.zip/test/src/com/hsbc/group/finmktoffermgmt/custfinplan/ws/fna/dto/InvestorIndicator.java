
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>investorIndicator complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="investorIndicator"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="indicatorAcceptanceDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="indicatorExpiryDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="indicatorKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="indicatorValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "investorIndicator", propOrder = {
    "indicatorAcceptanceDateTime",
    "indicatorExpiryDateTime",
    "indicatorKey",
    "indicatorValue"
})
public class InvestorIndicator {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar indicatorAcceptanceDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar indicatorExpiryDateTime;
    protected String indicatorKey;
    protected String indicatorValue;

    /**
     * ��ȡindicatorAcceptanceDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIndicatorAcceptanceDateTime() {
        return indicatorAcceptanceDateTime;
    }

    /**
     * ����indicatorAcceptanceDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIndicatorAcceptanceDateTime(XMLGregorianCalendar value) {
        this.indicatorAcceptanceDateTime = value;
    }

    /**
     * ��ȡindicatorExpiryDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIndicatorExpiryDateTime() {
        return indicatorExpiryDateTime;
    }

    /**
     * ����indicatorExpiryDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIndicatorExpiryDateTime(XMLGregorianCalendar value) {
        this.indicatorExpiryDateTime = value;
    }

    /**
     * ��ȡindicatorKey���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndicatorKey() {
        return indicatorKey;
    }

    /**
     * ����indicatorKey���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndicatorKey(String value) {
        this.indicatorKey = value;
    }

    /**
     * ��ȡindicatorValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndicatorValue() {
        return indicatorValue;
    }

    /**
     * ����indicatorValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndicatorValue(String value) {
        this.indicatorValue = value;
    }

}
