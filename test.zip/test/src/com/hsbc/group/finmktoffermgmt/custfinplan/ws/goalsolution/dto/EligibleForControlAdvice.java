
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>eligibleForControlAdvice complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="eligibleForControlAdvice"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="eligibleForControlAdvice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eligibleForControlAdvice", propOrder = {
    "eligibleForControlAdvice"
})
public class EligibleForControlAdvice {

    protected String eligibleForControlAdvice;

    /**
     * ��ȡeligibleForControlAdvice���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibleForControlAdvice() {
        return eligibleForControlAdvice;
    }

    /**
     * ����eligibleForControlAdvice���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibleForControlAdvice(String value) {
        this.eligibleForControlAdvice = value;
    }

}
