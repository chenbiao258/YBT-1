
package com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>financialGoal complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="financialGoal"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="goalCompletionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalMonthCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="goalObjectiveTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="jurisdictionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="periodicityGoalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="recordCreateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="recordUpdateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="skipRiskProfilingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "financialGoal", propOrder = {
    "goalCompletionDateTime",
    "goalDescription",
    "goalMonthCount",
    "goalObjectiveTypeCode",
    "goalTargetAmount",
    "goalTargetCurrencyCode",
    "goalTypeCode",
    "jurisdictionType",
    "needTypeCode",
    "periodicityGoalCode",
    "recordCreateDateTime",
    "recordUpdateDateTime",
    "skipRiskProfilingIndicator"
})
public class FinancialGoal {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalCompletionDateTime;
    protected String goalDescription;
    protected int goalMonthCount;
    protected String goalObjectiveTypeCode;
    protected BigDecimal goalTargetAmount;
    protected String goalTargetCurrencyCode;
    protected String goalTypeCode;
    protected String jurisdictionType;
    protected String needTypeCode;
    protected String periodicityGoalCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordCreateDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordUpdateDateTime;
    protected String skipRiskProfilingIndicator;

    /**
     * ��ȡgoalCompletionDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalCompletionDateTime() {
        return goalCompletionDateTime;
    }

    /**
     * ����goalCompletionDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalCompletionDateTime(XMLGregorianCalendar value) {
        this.goalCompletionDateTime = value;
    }

    /**
     * ��ȡgoalDescription���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalDescription() {
        return goalDescription;
    }

    /**
     * ����goalDescription���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalDescription(String value) {
        this.goalDescription = value;
    }

    /**
     * ��ȡgoalMonthCount���Ե�ֵ��
     * 
     */
    public int getGoalMonthCount() {
        return goalMonthCount;
    }

    /**
     * ����goalMonthCount���Ե�ֵ��
     * 
     */
    public void setGoalMonthCount(int value) {
        this.goalMonthCount = value;
    }

    /**
     * ��ȡgoalObjectiveTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalObjectiveTypeCode() {
        return goalObjectiveTypeCode;
    }

    /**
     * ����goalObjectiveTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalObjectiveTypeCode(String value) {
        this.goalObjectiveTypeCode = value;
    }

    /**
     * ��ȡgoalTargetAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoalTargetAmount() {
        return goalTargetAmount;
    }

    /**
     * ����goalTargetAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoalTargetAmount(BigDecimal value) {
        this.goalTargetAmount = value;
    }

    /**
     * ��ȡgoalTargetCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetCurrencyCode() {
        return goalTargetCurrencyCode;
    }

    /**
     * ����goalTargetCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetCurrencyCode(String value) {
        this.goalTargetCurrencyCode = value;
    }

    /**
     * ��ȡgoalTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * ����goalTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * ��ȡjurisdictionType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJurisdictionType() {
        return jurisdictionType;
    }

    /**
     * ����jurisdictionType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJurisdictionType(String value) {
        this.jurisdictionType = value;
    }

    /**
     * ��ȡneedTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * ����needTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

    /**
     * ��ȡperiodicityGoalCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicityGoalCode() {
        return periodicityGoalCode;
    }

    /**
     * ����periodicityGoalCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicityGoalCode(String value) {
        this.periodicityGoalCode = value;
    }

    /**
     * ��ȡrecordCreateDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordCreateDateTime() {
        return recordCreateDateTime;
    }

    /**
     * ����recordCreateDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordCreateDateTime(XMLGregorianCalendar value) {
        this.recordCreateDateTime = value;
    }

    /**
     * ��ȡrecordUpdateDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordUpdateDateTime() {
        return recordUpdateDateTime;
    }

    /**
     * ����recordUpdateDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordUpdateDateTime(XMLGregorianCalendar value) {
        this.recordUpdateDateTime = value;
    }

    /**
     * ��ȡskipRiskProfilingIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSkipRiskProfilingIndicator() {
        return skipRiskProfilingIndicator;
    }

    /**
     * ����skipRiskProfilingIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSkipRiskProfilingIndicator(String value) {
        this.skipRiskProfilingIndicator = value;
    }

}
