
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.LeadIdInfoRequestDto;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>retrieveGoalSummaryListByLeadIdWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalSummaryListByLeadIdWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="leadIdInfoRequestArray" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}leadIdInfoRequestDto" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalSummaryListByLeadIdWSRequest", propOrder = {
    "leadIdInfoRequestArray"
})
public class RetrieveGoalSummaryListByLeadIdWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<LeadIdInfoRequestDto> leadIdInfoRequestArray;

    /**
     * Gets the value of the leadIdInfoRequestArray property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the leadIdInfoRequestArray property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLeadIdInfoRequestArray().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LeadIdInfoRequestDto }
     * 
     * 
     */
    public List<LeadIdInfoRequestDto> getLeadIdInfoRequestArray() {
        if (leadIdInfoRequestArray == null) {
            leadIdInfoRequestArray = new ArrayList<LeadIdInfoRequestDto>();
        }
        return this.leadIdInfoRequestArray;
    }

}
