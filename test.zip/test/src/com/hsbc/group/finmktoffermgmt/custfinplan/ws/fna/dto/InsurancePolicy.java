
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>insurancePolicy complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="insurancePolicy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="futureValueAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="futureValueCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="insurancePolicyCoverage" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}insurancePolicyCoverage" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="insurancePolicyId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="maturityDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="productName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "insurancePolicy", propOrder = {
    "futureValueAmount",
    "futureValueCurrencyCode",
    "insurancePolicyCoverage",
    "insurancePolicyId",
    "maturityDate",
    "productName"
})
public class InsurancePolicy {

    protected BigDecimal futureValueAmount;
    protected String futureValueCurrencyCode;
    @XmlElement(nillable = true)
    protected List<InsurancePolicyCoverage> insurancePolicyCoverage;
    protected Long insurancePolicyId;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar maturityDate;
    protected String productName;

    /**
     * ��ȡfutureValueAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFutureValueAmount() {
        return futureValueAmount;
    }

    /**
     * ����futureValueAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFutureValueAmount(BigDecimal value) {
        this.futureValueAmount = value;
    }

    /**
     * ��ȡfutureValueCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFutureValueCurrencyCode() {
        return futureValueCurrencyCode;
    }

    /**
     * ����futureValueCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFutureValueCurrencyCode(String value) {
        this.futureValueCurrencyCode = value;
    }

    /**
     * Gets the value of the insurancePolicyCoverage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the insurancePolicyCoverage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInsurancePolicyCoverage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InsurancePolicyCoverage }
     * 
     * 
     */
    public List<InsurancePolicyCoverage> getInsurancePolicyCoverage() {
        if (insurancePolicyCoverage == null) {
            insurancePolicyCoverage = new ArrayList<InsurancePolicyCoverage>();
        }
        return this.insurancePolicyCoverage;
    }

    /**
     * ��ȡinsurancePolicyId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getInsurancePolicyId() {
        return insurancePolicyId;
    }

    /**
     * ����insurancePolicyId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setInsurancePolicyId(Long value) {
        this.insurancePolicyId = value;
    }

    /**
     * ��ȡmaturityDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMaturityDate() {
        return maturityDate;
    }

    /**
     * ����maturityDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMaturityDate(XMLGregorianCalendar value) {
        this.maturityDate = value;
    }

    /**
     * ��ȡproductName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * ����productName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

}
