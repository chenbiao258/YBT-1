
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>leadIdInfoRequestDto complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="leadIdInfoRequestDto"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="leadSourceSystemNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="sourceSystemRolePlayerCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "leadIdInfoRequestDto", propOrder = {
    "leadSourceSystemNumber",
    "sourceSystemRolePlayerCode"
})
public class LeadIdInfoRequestDto {

    protected Long leadSourceSystemNumber;
    protected String sourceSystemRolePlayerCode;

    /**
     * ��ȡleadSourceSystemNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLeadSourceSystemNumber() {
        return leadSourceSystemNumber;
    }

    /**
     * ����leadSourceSystemNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLeadSourceSystemNumber(Long value) {
        this.leadSourceSystemNumber = value;
    }

    /**
     * ��ȡsourceSystemRolePlayerCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSystemRolePlayerCode() {
        return sourceSystemRolePlayerCode;
    }

    /**
     * ����sourceSystemRolePlayerCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSystemRolePlayerCode(String value) {
        this.sourceSystemRolePlayerCode = value;
    }

}
