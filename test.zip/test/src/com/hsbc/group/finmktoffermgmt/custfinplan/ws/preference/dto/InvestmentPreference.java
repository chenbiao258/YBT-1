
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>investmentPreference complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="investmentPreference"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="investmentPreferenceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="investmentPreferenceTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "investmentPreference", propOrder = {
    "investmentPreferenceCode",
    "investmentPreferenceTypeCode"
})
public class InvestmentPreference {

    protected String investmentPreferenceCode;
    protected String investmentPreferenceTypeCode;

    /**
     * ��ȡinvestmentPreferenceCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceCode() {
        return investmentPreferenceCode;
    }

    /**
     * ����investmentPreferenceCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceCode(String value) {
        this.investmentPreferenceCode = value;
    }

    /**
     * ��ȡinvestmentPreferenceTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceTypeCode() {
        return investmentPreferenceTypeCode;
    }

    /**
     * ����investmentPreferenceTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceTypeCode(String value) {
        this.investmentPreferenceTypeCode = value;
    }

}
