
package com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>fundingDetailByWrapper complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="fundingDetailByWrapper"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="fundCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="fundMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wrapperType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fundingDetailByWrapper", propOrder = {
    "fundAmount",
    "fundCurrencyCode",
    "fundMonthlyAmount",
    "fundMonthlyCurrencyCode",
    "wrapperType"
})
public class FundingDetailByWrapper {

    protected BigDecimal fundAmount;
    protected String fundCurrencyCode;
    protected BigDecimal fundMonthlyAmount;
    protected String fundMonthlyCurrencyCode;
    protected String wrapperType;

    /**
     * ��ȡfundAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundAmount() {
        return fundAmount;
    }

    /**
     * ����fundAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundAmount(BigDecimal value) {
        this.fundAmount = value;
    }

    /**
     * ��ȡfundCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCurrencyCode() {
        return fundCurrencyCode;
    }

    /**
     * ����fundCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCurrencyCode(String value) {
        this.fundCurrencyCode = value;
    }

    /**
     * ��ȡfundMonthlyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundMonthlyAmount() {
        return fundMonthlyAmount;
    }

    /**
     * ����fundMonthlyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundMonthlyAmount(BigDecimal value) {
        this.fundMonthlyAmount = value;
    }

    /**
     * ��ȡfundMonthlyCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundMonthlyCurrencyCode() {
        return fundMonthlyCurrencyCode;
    }

    /**
     * ����fundMonthlyCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundMonthlyCurrencyCode(String value) {
        this.fundMonthlyCurrencyCode = value;
    }

    /**
     * ��ȡwrapperType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperType() {
        return wrapperType;
    }

    /**
     * ����wrapperType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperType(String value) {
        this.wrapperType = value;
    }

}
