
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveManagedSolutionDetailWSRequest;


/**
 * <p>retrieveManagedSolutionDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveManagedSolutionDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="arg0" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}retrieveManagedSolutionDetailWSRequest" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveManagedSolutionDetail", propOrder = {
    "arg0"
})
public class RetrieveManagedSolutionDetail {

    protected RetrieveManagedSolutionDetailWSRequest arg0;

    /**
     * ��ȡarg0���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link RetrieveManagedSolutionDetailWSRequest }
     *     
     */
    public RetrieveManagedSolutionDetailWSRequest getArg0() {
        return arg0;
    }

    /**
     * ����arg0���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveManagedSolutionDetailWSRequest }
     *     
     */
    public void setArg0(RetrieveManagedSolutionDetailWSRequest value) {
        this.arg0 = value;
    }

}
