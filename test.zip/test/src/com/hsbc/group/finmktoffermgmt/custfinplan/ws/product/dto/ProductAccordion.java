
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.Attribute;


/**
 * <p>productAccordion complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productAccordion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accordionAmount" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currencyAmount" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="accordionAttribute" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}attribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="accordionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="product" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}product" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productAccordion", propOrder = {
    "accordionAmount",
    "accordionAttribute",
    "accordionType",
    "product"
})
public class ProductAccordion {

    @XmlElement(nillable = true)
    protected List<CurrencyAmount> accordionAmount;
    @XmlElement(nillable = true)
    protected List<Attribute> accordionAttribute;
    protected String accordionType;
    @XmlElement(nillable = true)
    protected List<Product> product;

    /**
     * Gets the value of the accordionAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accordionAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccordionAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAmount }
     * 
     * 
     */
    public List<CurrencyAmount> getAccordionAmount() {
        if (accordionAmount == null) {
            accordionAmount = new ArrayList<CurrencyAmount>();
        }
        return this.accordionAmount;
    }

    /**
     * Gets the value of the accordionAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accordionAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccordionAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Attribute }
     * 
     * 
     */
    public List<Attribute> getAccordionAttribute() {
        if (accordionAttribute == null) {
            accordionAttribute = new ArrayList<Attribute>();
        }
        return this.accordionAttribute;
    }

    /**
     * ��ȡaccordionType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccordionType() {
        return accordionType;
    }

    /**
     * ����accordionType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccordionType(String value) {
        this.accordionType = value;
    }

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Product }
     * 
     * 
     */
    public List<Product> getProduct() {
        if (product == null) {
            product = new ArrayList<Product>();
        }
        return this.product;
    }

}
