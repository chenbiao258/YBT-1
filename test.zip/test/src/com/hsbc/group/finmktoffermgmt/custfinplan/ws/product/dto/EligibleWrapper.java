
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>eligibleWrapper complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="eligibleWrapper"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="wrapperCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wrapperDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wrapperTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eligibleWrapper", propOrder = {
    "wrapperCode",
    "wrapperDescription",
    "wrapperTypeCode"
})
public class EligibleWrapper {

    protected String wrapperCode;
    protected String wrapperDescription;
    protected String wrapperTypeCode;

    /**
     * ��ȡwrapperCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperCode() {
        return wrapperCode;
    }

    /**
     * ����wrapperCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperCode(String value) {
        this.wrapperCode = value;
    }

    /**
     * ��ȡwrapperDescription���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperDescription() {
        return wrapperDescription;
    }

    /**
     * ����wrapperDescription���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperDescription(String value) {
        this.wrapperDescription = value;
    }

    /**
     * ��ȡwrapperTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperTypeCode() {
        return wrapperTypeCode;
    }

    /**
     * ����wrapperTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperTypeCode(String value) {
        this.wrapperTypeCode = value;
    }

}
