
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CalculateFinancialSituationDataWSRequest }
     * 
     */
    public CalculateFinancialSituationDataWSRequest createCalculateFinancialSituationDataWSRequest() {
        return new CalculateFinancialSituationDataWSRequest();
    }

    /**
     * Create an instance of {@link Assets }
     * 
     */
    public Assets createAssets() {
        return new Assets();
    }

    /**
     * Create an instance of {@link CalculationRequest }
     * 
     */
    public CalculationRequest createCalculationRequest() {
        return new CalculationRequest();
    }

    /**
     * Create an instance of {@link Expense }
     * 
     */
    public Expense createExpense() {
        return new Expense();
    }

    /**
     * Create an instance of {@link Income }
     * 
     */
    public Income createIncome() {
        return new Income();
    }

    /**
     * Create an instance of {@link Liability }
     * 
     */
    public Liability createLiability() {
        return new Liability();
    }

    /**
     * Create an instance of {@link CalculateFinancialSituationDataWSResponse }
     * 
     */
    public CalculateFinancialSituationDataWSResponse createCalculateFinancialSituationDataWSResponse() {
        return new CalculateFinancialSituationDataWSResponse();
    }

    /**
     * Create an instance of {@link CalculationResult }
     * 
     */
    public CalculationResult createCalculationResult() {
        return new CalculationResult();
    }

    /**
     * Create an instance of {@link RecordFinancialSituationDataWSRequest }
     * 
     */
    public RecordFinancialSituationDataWSRequest createRecordFinancialSituationDataWSRequest() {
        return new RecordFinancialSituationDataWSRequest();
    }

    /**
     * Create an instance of {@link FinancialSituationData }
     * 
     */
    public FinancialSituationData createFinancialSituationData() {
        return new FinancialSituationData();
    }

    /**
     * Create an instance of {@link FinancialSituationDetail }
     * 
     */
    public FinancialSituationDetail createFinancialSituationDetail() {
        return new FinancialSituationDetail();
    }

    /**
     * Create an instance of {@link AdditionalSituation }
     * 
     */
    public AdditionalSituation createAdditionalSituation() {
        return new AdditionalSituation();
    }

    /**
     * Create an instance of {@link Investment }
     * 
     */
    public Investment createInvestment() {
        return new Investment();
    }

    /**
     * Create an instance of {@link FxRate }
     * 
     */
    public FxRate createFxRate() {
        return new FxRate();
    }

    /**
     * Create an instance of {@link InsurancePolicy }
     * 
     */
    public InsurancePolicy createInsurancePolicy() {
        return new InsurancePolicy();
    }

    /**
     * Create an instance of {@link InsurancePolicyCoverage }
     * 
     */
    public InsurancePolicyCoverage createInsurancePolicyCoverage() {
        return new InsurancePolicyCoverage();
    }

    /**
     * Create an instance of {@link InsurancePriority }
     * 
     */
    public InsurancePriority createInsurancePriority() {
        return new InsurancePriority();
    }

    /**
     * Create an instance of {@link InsurancePriorityDetail }
     * 
     */
    public InsurancePriorityDetail createInsurancePriorityDetail() {
        return new InsurancePriorityDetail();
    }

    /**
     * Create an instance of {@link InvestorIndicator }
     * 
     */
    public InvestorIndicator createInvestorIndicator() {
        return new InvestorIndicator();
    }

    /**
     * Create an instance of {@link RecordFinancialSituationDataWSResponse }
     * 
     */
    public RecordFinancialSituationDataWSResponse createRecordFinancialSituationDataWSResponse() {
        return new RecordFinancialSituationDataWSResponse();
    }

    /**
     * Create an instance of {@link RetrieveFinancialSituationDataWSRequest }
     * 
     */
    public RetrieveFinancialSituationDataWSRequest createRetrieveFinancialSituationDataWSRequest() {
        return new RetrieveFinancialSituationDataWSRequest();
    }

    /**
     * Create an instance of {@link RetrieveFinancialSituationDataWSResponse }
     * 
     */
    public RetrieveFinancialSituationDataWSResponse createRetrieveFinancialSituationDataWSResponse() {
        return new RetrieveFinancialSituationDataWSResponse();
    }

}
