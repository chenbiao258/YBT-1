
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>emergencyFund complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="emergencyFund"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="amountSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyEmergencyFundCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="emergencyFundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="reasonOverriding" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "emergencyFund", propOrder = {
    "amountSource",
    "currencyEmergencyFundCode",
    "emergencyFundAmount",
    "reasonOverriding"
})
public class EmergencyFund {

    protected String amountSource;
    protected String currencyEmergencyFundCode;
    protected BigDecimal emergencyFundAmount;
    protected String reasonOverriding;

    /**
     * ��ȡamountSource���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmountSource() {
        return amountSource;
    }

    /**
     * ����amountSource���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmountSource(String value) {
        this.amountSource = value;
    }

    /**
     * ��ȡcurrencyEmergencyFundCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyEmergencyFundCode() {
        return currencyEmergencyFundCode;
    }

    /**
     * ����currencyEmergencyFundCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyEmergencyFundCode(String value) {
        this.currencyEmergencyFundCode = value;
    }

    /**
     * ��ȡemergencyFundAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEmergencyFundAmount() {
        return emergencyFundAmount;
    }

    /**
     * ����emergencyFundAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEmergencyFundAmount(BigDecimal value) {
        this.emergencyFundAmount = value;
    }

    /**
     * ��ȡreasonOverriding���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonOverriding() {
        return reasonOverriding;
    }

    /**
     * ����reasonOverriding���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonOverriding(String value) {
        this.reasonOverriding = value;
    }

}
