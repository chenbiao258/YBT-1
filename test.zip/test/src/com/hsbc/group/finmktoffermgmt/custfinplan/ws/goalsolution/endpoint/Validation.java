
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>validation complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="validation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="validationParameters" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}validationParameters" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="validationTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "validation", propOrder = {
    "validationParameters",
    "validationTypeCode"
})
public class Validation {

    @XmlElement(nillable = true)
    protected List<ValidationParameters> validationParameters;
    protected String validationTypeCode;

    /**
     * Gets the value of the validationParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validationParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidationParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidationParameters }
     * 
     * 
     */
    public List<ValidationParameters> getValidationParameters() {
        if (validationParameters == null) {
            validationParameters = new ArrayList<ValidationParameters>();
        }
        return this.validationParameters;
    }

    /**
     * ��ȡvalidationTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationTypeCode() {
        return validationTypeCode;
    }

    /**
     * ����validationTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationTypeCode(String value) {
        this.validationTypeCode = value;
    }

}
