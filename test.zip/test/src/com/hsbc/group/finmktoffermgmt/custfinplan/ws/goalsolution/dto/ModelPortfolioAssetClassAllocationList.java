
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>modelPortfolioAssetClassAllocationList complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="modelPortfolioAssetClassAllocationList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="defaultPortfolio" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="modelPortfolioAssetClassAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}modelPortfolioAssetClassAllocation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="portfolioTypeDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="selectedPortfolio" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "modelPortfolioAssetClassAllocationList", propOrder = {
    "defaultPortfolio",
    "modelPortfolioAssetClassAllocation",
    "portfolioTypeCode",
    "portfolioTypeDescription",
    "selectedPortfolio"
})
public class ModelPortfolioAssetClassAllocationList {

    protected boolean defaultPortfolio;
    @XmlElement(nillable = true)
    protected List<ModelPortfolioAssetClassAllocation> modelPortfolioAssetClassAllocation;
    protected String portfolioTypeCode;
    protected String portfolioTypeDescription;
    protected boolean selectedPortfolio;

    /**
     * ��ȡdefaultPortfolio���Ե�ֵ��
     * 
     */
    public boolean isDefaultPortfolio() {
        return defaultPortfolio;
    }

    /**
     * ����defaultPortfolio���Ե�ֵ��
     * 
     */
    public void setDefaultPortfolio(boolean value) {
        this.defaultPortfolio = value;
    }

    /**
     * Gets the value of the modelPortfolioAssetClassAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modelPortfolioAssetClassAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModelPortfolioAssetClassAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModelPortfolioAssetClassAllocation }
     * 
     * 
     */
    public List<ModelPortfolioAssetClassAllocation> getModelPortfolioAssetClassAllocation() {
        if (modelPortfolioAssetClassAllocation == null) {
            modelPortfolioAssetClassAllocation = new ArrayList<ModelPortfolioAssetClassAllocation>();
        }
        return this.modelPortfolioAssetClassAllocation;
    }

    /**
     * ��ȡportfolioTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioTypeCode() {
        return portfolioTypeCode;
    }

    /**
     * ����portfolioTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioTypeCode(String value) {
        this.portfolioTypeCode = value;
    }

    /**
     * ��ȡportfolioTypeDescription���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioTypeDescription() {
        return portfolioTypeDescription;
    }

    /**
     * ����portfolioTypeDescription���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioTypeDescription(String value) {
        this.portfolioTypeDescription = value;
    }

    /**
     * ��ȡselectedPortfolio���Ե�ֵ��
     * 
     */
    public boolean isSelectedPortfolio() {
        return selectedPortfolio;
    }

    /**
     * ����selectedPortfolio���Ե�ֵ��
     * 
     */
    public void setSelectedPortfolio(boolean value) {
        this.selectedPortfolio = value;
    }

}
