
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>customer complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="customer"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="countryISOCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="customerAttribute" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customerAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="groupMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rolePlayerIdentificationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="sourceSystemRolePlayerCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "customer", propOrder = {
    "countryISOCode",
    "customerAttribute",
    "groupMemberCode",
    "rolePlayerIdentificationNumber",
    "sourceSystemRolePlayerCode"
})
public class Customer {

    protected String countryISOCode;
    @XmlElement(nillable = true)
    protected List<CustomerAttribute> customerAttribute;
    protected String groupMemberCode;
    protected String rolePlayerIdentificationNumber;
    protected String sourceSystemRolePlayerCode;

    /**
     * ��ȡcountryISOCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryISOCode() {
        return countryISOCode;
    }

    /**
     * ����countryISOCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryISOCode(String value) {
        this.countryISOCode = value;
    }

    /**
     * Gets the value of the customerAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customerAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomerAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomerAttribute }
     * 
     * 
     */
    public List<CustomerAttribute> getCustomerAttribute() {
        if (customerAttribute == null) {
            customerAttribute = new ArrayList<CustomerAttribute>();
        }
        return this.customerAttribute;
    }

    /**
     * ��ȡgroupMemberCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupMemberCode() {
        return groupMemberCode;
    }

    /**
     * ����groupMemberCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupMemberCode(String value) {
        this.groupMemberCode = value;
    }

    /**
     * ��ȡrolePlayerIdentificationNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRolePlayerIdentificationNumber() {
        return rolePlayerIdentificationNumber;
    }

    /**
     * ����rolePlayerIdentificationNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRolePlayerIdentificationNumber(String value) {
        this.rolePlayerIdentificationNumber = value;
    }

    /**
     * ��ȡsourceSystemRolePlayerCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSystemRolePlayerCode() {
        return sourceSystemRolePlayerCode;
    }

    /**
     * ����sourceSystemRolePlayerCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSystemRolePlayerCode(String value) {
        this.sourceSystemRolePlayerCode = value;
    }

}
