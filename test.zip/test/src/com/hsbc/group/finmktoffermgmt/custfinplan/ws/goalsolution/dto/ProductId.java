
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>productId complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productId"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="countryProductTradableCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productAlternativeNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productCodeAlternativeClassificationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productId", propOrder = {
    "countryProductTradableCode",
    "productAlternativeNumber",
    "productCodeAlternativeClassificationCode",
    "productTypeCode"
})
public class ProductId {

    protected String countryProductTradableCode;
    protected String productAlternativeNumber;
    protected String productCodeAlternativeClassificationCode;
    protected String productTypeCode;

    /**
     * ��ȡcountryProductTradableCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryProductTradableCode() {
        return countryProductTradableCode;
    }

    /**
     * ����countryProductTradableCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryProductTradableCode(String value) {
        this.countryProductTradableCode = value;
    }

    /**
     * ��ȡproductAlternativeNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductAlternativeNumber() {
        return productAlternativeNumber;
    }

    /**
     * ����productAlternativeNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductAlternativeNumber(String value) {
        this.productAlternativeNumber = value;
    }

    /**
     * ��ȡproductCodeAlternativeClassificationCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCodeAlternativeClassificationCode() {
        return productCodeAlternativeClassificationCode;
    }

    /**
     * ����productCodeAlternativeClassificationCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCodeAlternativeClassificationCode(String value) {
        this.productCodeAlternativeClassificationCode = value;
    }

    /**
     * ��ȡproductTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTypeCode() {
        return productTypeCode;
    }

    /**
     * ����productTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTypeCode(String value) {
        this.productTypeCode = value;
    }

}
