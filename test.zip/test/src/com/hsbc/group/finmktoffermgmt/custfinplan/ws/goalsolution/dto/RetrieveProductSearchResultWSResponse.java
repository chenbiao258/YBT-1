
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductCountResult;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductSearchResult;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductSubtypeResult;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.WrapperDetail;


/**
 * <p>retrieveProductSearchResultWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveProductSearchResultWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSelectionWSResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="productSearchResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSearchResult" minOccurs="0"/&gt;
 *         &lt;element name="productSubtypeResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSubtypeResult" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productCountResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productCountResult" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="wrapperDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperDetail" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveProductSearchResultWSResponse", propOrder = {
    "productSearchResult",
    "productSubtypeResult",
    "productCountResult",
    "wrapperDetail"
})
public class RetrieveProductSearchResultWSResponse
    extends ProductSelectionWSResponse
{

    protected ProductSearchResult productSearchResult;
    @XmlElement(nillable = true)
    protected List<ProductSubtypeResult> productSubtypeResult;
    @XmlElement(nillable = true)
    protected List<ProductCountResult> productCountResult;
    @XmlElement(nillable = true)
    protected List<WrapperDetail> wrapperDetail;

    /**
     * ��ȡproductSearchResult���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ProductSearchResult }
     *     
     */
    public ProductSearchResult getProductSearchResult() {
        return productSearchResult;
    }

    /**
     * ����productSearchResult���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSearchResult }
     *     
     */
    public void setProductSearchResult(ProductSearchResult value) {
        this.productSearchResult = value;
    }

    /**
     * Gets the value of the productSubtypeResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productSubtypeResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductSubtypeResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductSubtypeResult }
     * 
     * 
     */
    public List<ProductSubtypeResult> getProductSubtypeResult() {
        if (productSubtypeResult == null) {
            productSubtypeResult = new ArrayList<ProductSubtypeResult>();
        }
        return this.productSubtypeResult;
    }

    /**
     * Gets the value of the productCountResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productCountResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductCountResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductCountResult }
     * 
     * 
     */
    public List<ProductCountResult> getProductCountResult() {
        if (productCountResult == null) {
            productCountResult = new ArrayList<ProductCountResult>();
        }
        return this.productCountResult;
    }

    /**
     * Gets the value of the wrapperDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperDetail }
     * 
     * 
     */
    public List<WrapperDetail> getWrapperDetail() {
        if (wrapperDetail == null) {
            wrapperDetail = new ArrayList<WrapperDetail>();
        }
        return this.wrapperDetail;
    }

}
