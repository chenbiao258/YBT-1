
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CalculateAggregateAffordabilityRatio_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateAggregateAffordabilityRatio");
    private final static QName _CalculateAggregateAffordabilityRatioResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateAggregateAffordabilityRatioResponse");
    private final static QName _CalculateGoalPortfolio_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateGoalPortfolio");
    private final static QName _CalculateGoalPortfolioResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateGoalPortfolioResponse");
    private final static QName _CalculateRiskCapacity_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateRiskCapacity");
    private final static QName _CalculateRiskCapacityResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateRiskCapacityResponse");
    private final static QName _RecordActivityAuditLog_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordActivityAuditLog");
    private final static QName _RecordActivityAuditLogResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordActivityAuditLogResponse");
    private final static QName _RecordGoalPlannerInfo_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordGoalPlannerInfo");
    private final static QName _RecordGoalPlannerInfoResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordGoalPlannerInfoResponse");
    private final static QName _RecordGoalSolutionDetail_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordGoalSolutionDetail");
    private final static QName _RecordGoalSolutionDetailResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordGoalSolutionDetailResponse");
    private final static QName _RetrieveGoalPlannerInfoWebService_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalPlannerInfoWebService");
    private final static QName _RetrieveGoalPlannerInfoWebServiceResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalPlannerInfoWebServiceResponse");
    private final static QName _RetrieveGoalSolutionDetail_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalSolutionDetail");
    private final static QName _RetrieveGoalSolutionDetailResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalSolutionDetailResponse");
    private final static QName _RetrieveGoalSummaryList_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalSummaryList");
    private final static QName _RetrieveGoalSummaryListByLeadId_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalSummaryListByLeadId");
    private final static QName _RetrieveGoalSummaryListByLeadIdResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalSummaryListByLeadIdResponse");
    private final static QName _RetrieveGoalSummaryListResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveGoalSummaryListResponse");
    private final static QName _RetrieveManagedSolutionDetail_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveManagedSolutionDetail");
    private final static QName _RetrieveManagedSolutionDetailResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveManagedSolutionDetailResponse");
    private final static QName _RetrieveProductSearchResult_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveProductSearchResult");
    private final static QName _RetrieveProductSearchResultResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveProductSearchResultResponse");
    private final static QName _ReviewInvestments_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "reviewInvestments");
    private final static QName _ReviewInvestmentsResponse_QNAME = new QName("http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "reviewInvestmentsResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ValidationResult }
     * 
     */
    public ValidationResult createValidationResult() {
        return new ValidationResult();
    }

    /**
     * Create an instance of {@link ValidationResult.Attributes }
     * 
     */
    public ValidationResult.Attributes createValidationResultAttributes() {
        return new ValidationResult.Attributes();
    }

    /**
     * Create an instance of {@link CalculateAggregateAffordabilityRatio }
     * 
     */
    public CalculateAggregateAffordabilityRatio createCalculateAggregateAffordabilityRatio() {
        return new CalculateAggregateAffordabilityRatio();
    }

    /**
     * Create an instance of {@link CalculateAggregateAffordabilityRatioResponse }
     * 
     */
    public CalculateAggregateAffordabilityRatioResponse createCalculateAggregateAffordabilityRatioResponse() {
        return new CalculateAggregateAffordabilityRatioResponse();
    }

    /**
     * Create an instance of {@link CalculateGoalPortfolio }
     * 
     */
    public CalculateGoalPortfolio createCalculateGoalPortfolio() {
        return new CalculateGoalPortfolio();
    }

    /**
     * Create an instance of {@link CalculateGoalPortfolioResponse }
     * 
     */
    public CalculateGoalPortfolioResponse createCalculateGoalPortfolioResponse() {
        return new CalculateGoalPortfolioResponse();
    }

    /**
     * Create an instance of {@link CalculateRiskCapacity }
     * 
     */
    public CalculateRiskCapacity createCalculateRiskCapacity() {
        return new CalculateRiskCapacity();
    }

    /**
     * Create an instance of {@link CalculateRiskCapacityResponse }
     * 
     */
    public CalculateRiskCapacityResponse createCalculateRiskCapacityResponse() {
        return new CalculateRiskCapacityResponse();
    }

    /**
     * Create an instance of {@link RecordActivityAuditLog }
     * 
     */
    public RecordActivityAuditLog createRecordActivityAuditLog() {
        return new RecordActivityAuditLog();
    }

    /**
     * Create an instance of {@link RecordActivityAuditLogResponse }
     * 
     */
    public RecordActivityAuditLogResponse createRecordActivityAuditLogResponse() {
        return new RecordActivityAuditLogResponse();
    }

    /**
     * Create an instance of {@link RecordGoalPlannerInfo }
     * 
     */
    public RecordGoalPlannerInfo createRecordGoalPlannerInfo() {
        return new RecordGoalPlannerInfo();
    }

    /**
     * Create an instance of {@link RecordGoalPlannerInfoResponse }
     * 
     */
    public RecordGoalPlannerInfoResponse createRecordGoalPlannerInfoResponse() {
        return new RecordGoalPlannerInfoResponse();
    }

    /**
     * Create an instance of {@link RecordGoalSolutionDetail }
     * 
     */
    public RecordGoalSolutionDetail createRecordGoalSolutionDetail() {
        return new RecordGoalSolutionDetail();
    }

    /**
     * Create an instance of {@link RecordGoalSolutionDetailResponse }
     * 
     */
    public RecordGoalSolutionDetailResponse createRecordGoalSolutionDetailResponse() {
        return new RecordGoalSolutionDetailResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalPlannerInfoWebService }
     * 
     */
    public RetrieveGoalPlannerInfoWebService createRetrieveGoalPlannerInfoWebService() {
        return new RetrieveGoalPlannerInfoWebService();
    }

    /**
     * Create an instance of {@link RetrieveGoalPlannerInfoWebServiceResponse }
     * 
     */
    public RetrieveGoalPlannerInfoWebServiceResponse createRetrieveGoalPlannerInfoWebServiceResponse() {
        return new RetrieveGoalPlannerInfoWebServiceResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalSolutionDetail }
     * 
     */
    public RetrieveGoalSolutionDetail createRetrieveGoalSolutionDetail() {
        return new RetrieveGoalSolutionDetail();
    }

    /**
     * Create an instance of {@link RetrieveGoalSolutionDetailResponse }
     * 
     */
    public RetrieveGoalSolutionDetailResponse createRetrieveGoalSolutionDetailResponse() {
        return new RetrieveGoalSolutionDetailResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryList }
     * 
     */
    public RetrieveGoalSummaryList createRetrieveGoalSummaryList() {
        return new RetrieveGoalSummaryList();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListByLeadId }
     * 
     */
    public RetrieveGoalSummaryListByLeadId createRetrieveGoalSummaryListByLeadId() {
        return new RetrieveGoalSummaryListByLeadId();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListByLeadIdResponse }
     * 
     */
    public RetrieveGoalSummaryListByLeadIdResponse createRetrieveGoalSummaryListByLeadIdResponse() {
        return new RetrieveGoalSummaryListByLeadIdResponse();
    }

    /**
     * Create an instance of {@link RetrieveGoalSummaryListResponse }
     * 
     */
    public RetrieveGoalSummaryListResponse createRetrieveGoalSummaryListResponse() {
        return new RetrieveGoalSummaryListResponse();
    }

    /**
     * Create an instance of {@link RetrieveManagedSolutionDetail }
     * 
     */
    public RetrieveManagedSolutionDetail createRetrieveManagedSolutionDetail() {
        return new RetrieveManagedSolutionDetail();
    }

    /**
     * Create an instance of {@link RetrieveManagedSolutionDetailResponse }
     * 
     */
    public RetrieveManagedSolutionDetailResponse createRetrieveManagedSolutionDetailResponse() {
        return new RetrieveManagedSolutionDetailResponse();
    }

    /**
     * Create an instance of {@link RetrieveProductSearchResult }
     * 
     */
    public RetrieveProductSearchResult createRetrieveProductSearchResult() {
        return new RetrieveProductSearchResult();
    }

    /**
     * Create an instance of {@link RetrieveProductSearchResultResponse }
     * 
     */
    public RetrieveProductSearchResultResponse createRetrieveProductSearchResultResponse() {
        return new RetrieveProductSearchResultResponse();
    }

    /**
     * Create an instance of {@link ReviewInvestments }
     * 
     */
    public ReviewInvestments createReviewInvestments() {
        return new ReviewInvestments();
    }

    /**
     * Create an instance of {@link ReviewInvestmentsResponse }
     * 
     */
    public ReviewInvestmentsResponse createReviewInvestmentsResponse() {
        return new ReviewInvestmentsResponse();
    }

    /**
     * Create an instance of {@link ProductSelectionWSRequest }
     * 
     */
    public ProductSelectionWSRequest createProductSelectionWSRequest() {
        return new ProductSelectionWSRequest();
    }

    /**
     * Create an instance of {@link ProductSelectionWSResponse }
     * 
     */
    public ProductSelectionWSResponse createProductSelectionWSResponse() {
        return new ProductSelectionWSResponse();
    }

    /**
     * Create an instance of {@link GoalLocalFields }
     * 
     */
    public GoalLocalFields createGoalLocalFields() {
        return new GoalLocalFields();
    }

    /**
     * Create an instance of {@link MultipleAdviceStyleAmountDetail }
     * 
     */
    public MultipleAdviceStyleAmountDetail createMultipleAdviceStyleAmountDetail() {
        return new MultipleAdviceStyleAmountDetail();
    }

    /**
     * Create an instance of {@link MultipleAdviceStyleHoldingDetails }
     * 
     */
    public MultipleAdviceStyleHoldingDetails createMultipleAdviceStyleHoldingDetails() {
        return new MultipleAdviceStyleHoldingDetails();
    }

    /**
     * Create an instance of {@link CoreReserveArea }
     * 
     */
    public CoreReserveArea createCoreReserveArea() {
        return new CoreReserveArea();
    }

    /**
     * Create an instance of {@link LocalFieldsArea }
     * 
     */
    public LocalFieldsArea createLocalFieldsArea() {
        return new LocalFieldsArea();
    }

    /**
     * Create an instance of {@link Validation }
     * 
     */
    public Validation createValidation() {
        return new Validation();
    }

    /**
     * Create an instance of {@link ValidationParameters }
     * 
     */
    public ValidationParameters createValidationParameters() {
        return new ValidationParameters();
    }

    /**
     * Create an instance of {@link ValidationResult.Attributes.Entry }
     * 
     */
    public ValidationResult.Attributes.Entry createValidationResultAttributesEntry() {
        return new ValidationResult.Attributes.Entry();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateAggregateAffordabilityRatio }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateAggregateAffordabilityRatio")
    public JAXBElement<CalculateAggregateAffordabilityRatio> createCalculateAggregateAffordabilityRatio(CalculateAggregateAffordabilityRatio value) {
        return new JAXBElement<CalculateAggregateAffordabilityRatio>(_CalculateAggregateAffordabilityRatio_QNAME, CalculateAggregateAffordabilityRatio.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateAggregateAffordabilityRatioResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateAggregateAffordabilityRatioResponse")
    public JAXBElement<CalculateAggregateAffordabilityRatioResponse> createCalculateAggregateAffordabilityRatioResponse(CalculateAggregateAffordabilityRatioResponse value) {
        return new JAXBElement<CalculateAggregateAffordabilityRatioResponse>(_CalculateAggregateAffordabilityRatioResponse_QNAME, CalculateAggregateAffordabilityRatioResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateGoalPortfolio }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateGoalPortfolio")
    public JAXBElement<CalculateGoalPortfolio> createCalculateGoalPortfolio(CalculateGoalPortfolio value) {
        return new JAXBElement<CalculateGoalPortfolio>(_CalculateGoalPortfolio_QNAME, CalculateGoalPortfolio.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateGoalPortfolioResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateGoalPortfolioResponse")
    public JAXBElement<CalculateGoalPortfolioResponse> createCalculateGoalPortfolioResponse(CalculateGoalPortfolioResponse value) {
        return new JAXBElement<CalculateGoalPortfolioResponse>(_CalculateGoalPortfolioResponse_QNAME, CalculateGoalPortfolioResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateRiskCapacity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateRiskCapacity")
    public JAXBElement<CalculateRiskCapacity> createCalculateRiskCapacity(CalculateRiskCapacity value) {
        return new JAXBElement<CalculateRiskCapacity>(_CalculateRiskCapacity_QNAME, CalculateRiskCapacity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateRiskCapacityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateRiskCapacityResponse")
    public JAXBElement<CalculateRiskCapacityResponse> createCalculateRiskCapacityResponse(CalculateRiskCapacityResponse value) {
        return new JAXBElement<CalculateRiskCapacityResponse>(_CalculateRiskCapacityResponse_QNAME, CalculateRiskCapacityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordActivityAuditLog }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordActivityAuditLog")
    public JAXBElement<RecordActivityAuditLog> createRecordActivityAuditLog(RecordActivityAuditLog value) {
        return new JAXBElement<RecordActivityAuditLog>(_RecordActivityAuditLog_QNAME, RecordActivityAuditLog.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordActivityAuditLogResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordActivityAuditLogResponse")
    public JAXBElement<RecordActivityAuditLogResponse> createRecordActivityAuditLogResponse(RecordActivityAuditLogResponse value) {
        return new JAXBElement<RecordActivityAuditLogResponse>(_RecordActivityAuditLogResponse_QNAME, RecordActivityAuditLogResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordGoalPlannerInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordGoalPlannerInfo")
    public JAXBElement<RecordGoalPlannerInfo> createRecordGoalPlannerInfo(RecordGoalPlannerInfo value) {
        return new JAXBElement<RecordGoalPlannerInfo>(_RecordGoalPlannerInfo_QNAME, RecordGoalPlannerInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordGoalPlannerInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordGoalPlannerInfoResponse")
    public JAXBElement<RecordGoalPlannerInfoResponse> createRecordGoalPlannerInfoResponse(RecordGoalPlannerInfoResponse value) {
        return new JAXBElement<RecordGoalPlannerInfoResponse>(_RecordGoalPlannerInfoResponse_QNAME, RecordGoalPlannerInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordGoalSolutionDetail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordGoalSolutionDetail")
    public JAXBElement<RecordGoalSolutionDetail> createRecordGoalSolutionDetail(RecordGoalSolutionDetail value) {
        return new JAXBElement<RecordGoalSolutionDetail>(_RecordGoalSolutionDetail_QNAME, RecordGoalSolutionDetail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordGoalSolutionDetailResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordGoalSolutionDetailResponse")
    public JAXBElement<RecordGoalSolutionDetailResponse> createRecordGoalSolutionDetailResponse(RecordGoalSolutionDetailResponse value) {
        return new JAXBElement<RecordGoalSolutionDetailResponse>(_RecordGoalSolutionDetailResponse_QNAME, RecordGoalSolutionDetailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalPlannerInfoWebService }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalPlannerInfoWebService")
    public JAXBElement<RetrieveGoalPlannerInfoWebService> createRetrieveGoalPlannerInfoWebService(RetrieveGoalPlannerInfoWebService value) {
        return new JAXBElement<RetrieveGoalPlannerInfoWebService>(_RetrieveGoalPlannerInfoWebService_QNAME, RetrieveGoalPlannerInfoWebService.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalPlannerInfoWebServiceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalPlannerInfoWebServiceResponse")
    public JAXBElement<RetrieveGoalPlannerInfoWebServiceResponse> createRetrieveGoalPlannerInfoWebServiceResponse(RetrieveGoalPlannerInfoWebServiceResponse value) {
        return new JAXBElement<RetrieveGoalPlannerInfoWebServiceResponse>(_RetrieveGoalPlannerInfoWebServiceResponse_QNAME, RetrieveGoalPlannerInfoWebServiceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalSolutionDetail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalSolutionDetail")
    public JAXBElement<RetrieveGoalSolutionDetail> createRetrieveGoalSolutionDetail(RetrieveGoalSolutionDetail value) {
        return new JAXBElement<RetrieveGoalSolutionDetail>(_RetrieveGoalSolutionDetail_QNAME, RetrieveGoalSolutionDetail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalSolutionDetailResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalSolutionDetailResponse")
    public JAXBElement<RetrieveGoalSolutionDetailResponse> createRetrieveGoalSolutionDetailResponse(RetrieveGoalSolutionDetailResponse value) {
        return new JAXBElement<RetrieveGoalSolutionDetailResponse>(_RetrieveGoalSolutionDetailResponse_QNAME, RetrieveGoalSolutionDetailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalSummaryList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalSummaryList")
    public JAXBElement<RetrieveGoalSummaryList> createRetrieveGoalSummaryList(RetrieveGoalSummaryList value) {
        return new JAXBElement<RetrieveGoalSummaryList>(_RetrieveGoalSummaryList_QNAME, RetrieveGoalSummaryList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalSummaryListByLeadId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalSummaryListByLeadId")
    public JAXBElement<RetrieveGoalSummaryListByLeadId> createRetrieveGoalSummaryListByLeadId(RetrieveGoalSummaryListByLeadId value) {
        return new JAXBElement<RetrieveGoalSummaryListByLeadId>(_RetrieveGoalSummaryListByLeadId_QNAME, RetrieveGoalSummaryListByLeadId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalSummaryListByLeadIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalSummaryListByLeadIdResponse")
    public JAXBElement<RetrieveGoalSummaryListByLeadIdResponse> createRetrieveGoalSummaryListByLeadIdResponse(RetrieveGoalSummaryListByLeadIdResponse value) {
        return new JAXBElement<RetrieveGoalSummaryListByLeadIdResponse>(_RetrieveGoalSummaryListByLeadIdResponse_QNAME, RetrieveGoalSummaryListByLeadIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveGoalSummaryListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveGoalSummaryListResponse")
    public JAXBElement<RetrieveGoalSummaryListResponse> createRetrieveGoalSummaryListResponse(RetrieveGoalSummaryListResponse value) {
        return new JAXBElement<RetrieveGoalSummaryListResponse>(_RetrieveGoalSummaryListResponse_QNAME, RetrieveGoalSummaryListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveManagedSolutionDetail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveManagedSolutionDetail")
    public JAXBElement<RetrieveManagedSolutionDetail> createRetrieveManagedSolutionDetail(RetrieveManagedSolutionDetail value) {
        return new JAXBElement<RetrieveManagedSolutionDetail>(_RetrieveManagedSolutionDetail_QNAME, RetrieveManagedSolutionDetail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveManagedSolutionDetailResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveManagedSolutionDetailResponse")
    public JAXBElement<RetrieveManagedSolutionDetailResponse> createRetrieveManagedSolutionDetailResponse(RetrieveManagedSolutionDetailResponse value) {
        return new JAXBElement<RetrieveManagedSolutionDetailResponse>(_RetrieveManagedSolutionDetailResponse_QNAME, RetrieveManagedSolutionDetailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveProductSearchResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveProductSearchResult")
    public JAXBElement<RetrieveProductSearchResult> createRetrieveProductSearchResult(RetrieveProductSearchResult value) {
        return new JAXBElement<RetrieveProductSearchResult>(_RetrieveProductSearchResult_QNAME, RetrieveProductSearchResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveProductSearchResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveProductSearchResultResponse")
    public JAXBElement<RetrieveProductSearchResultResponse> createRetrieveProductSearchResultResponse(RetrieveProductSearchResultResponse value) {
        return new JAXBElement<RetrieveProductSearchResultResponse>(_RetrieveProductSearchResultResponse_QNAME, RetrieveProductSearchResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReviewInvestments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "reviewInvestments")
    public JAXBElement<ReviewInvestments> createReviewInvestments(ReviewInvestments value) {
        return new JAXBElement<ReviewInvestments>(_ReviewInvestments_QNAME, ReviewInvestments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReviewInvestmentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "reviewInvestmentsResponse")
    public JAXBElement<ReviewInvestmentsResponse> createReviewInvestmentsResponse(ReviewInvestmentsResponse value) {
        return new JAXBElement<ReviewInvestmentsResponse>(_ReviewInvestmentsResponse_QNAME, ReviewInvestmentsResponse.class, null, value);
    }

}
