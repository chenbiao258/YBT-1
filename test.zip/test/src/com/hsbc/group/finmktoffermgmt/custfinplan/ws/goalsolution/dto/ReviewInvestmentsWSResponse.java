
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.dto.ValidationDetail;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>reviewInvestmentsWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="reviewInvestmentsWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="validationDetails" type="{http://dto.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}validationDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="accountAllocationSummarys" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}accountAllocationSummary" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioAssetAllocationSummarys" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioAssetAllocationSummary" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="additionalItems" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalItem" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="cacheDataToken" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reviewInvestmentsWSResponse", propOrder = {
    "validationDetails",
    "accountAllocationSummarys",
    "portfolioAssetAllocationSummarys",
    "additionalItems",
    "cacheDataToken"
})
public class ReviewInvestmentsWSResponse
    extends WebServiceResponse
{

    @XmlElement(nillable = true)
    protected List<ValidationDetail> validationDetails;
    @XmlElement(nillable = true)
    protected List<AccountAllocationSummary> accountAllocationSummarys;
    @XmlElement(nillable = true)
    protected List<PortfolioAssetAllocationSummary> portfolioAssetAllocationSummarys;
    @XmlElement(nillable = true)
    protected List<AdditionalItem> additionalItems;
    @XmlElement(nillable = true)
    protected List<String> cacheDataToken;

    /**
     * Gets the value of the validationDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validationDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidationDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidationDetail }
     * 
     * 
     */
    public List<ValidationDetail> getValidationDetails() {
        if (validationDetails == null) {
            validationDetails = new ArrayList<ValidationDetail>();
        }
        return this.validationDetails;
    }

    /**
     * Gets the value of the accountAllocationSummarys property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accountAllocationSummarys property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccountAllocationSummarys().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccountAllocationSummary }
     * 
     * 
     */
    public List<AccountAllocationSummary> getAccountAllocationSummarys() {
        if (accountAllocationSummarys == null) {
            accountAllocationSummarys = new ArrayList<AccountAllocationSummary>();
        }
        return this.accountAllocationSummarys;
    }

    /**
     * Gets the value of the portfolioAssetAllocationSummarys property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the portfolioAssetAllocationSummarys property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPortfolioAssetAllocationSummarys().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PortfolioAssetAllocationSummary }
     * 
     * 
     */
    public List<PortfolioAssetAllocationSummary> getPortfolioAssetAllocationSummarys() {
        if (portfolioAssetAllocationSummarys == null) {
            portfolioAssetAllocationSummarys = new ArrayList<PortfolioAssetAllocationSummary>();
        }
        return this.portfolioAssetAllocationSummarys;
    }

    /**
     * Gets the value of the additionalItems property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalItems property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalItems().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalItem }
     * 
     * 
     */
    public List<AdditionalItem> getAdditionalItems() {
        if (additionalItems == null) {
            additionalItems = new ArrayList<AdditionalItem>();
        }
        return this.additionalItems;
    }

    /**
     * Gets the value of the cacheDataToken property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cacheDataToken property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCacheDataToken().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCacheDataToken() {
        if (cacheDataToken == null) {
            cacheDataToken = new ArrayList<String>();
        }
        return this.cacheDataToken;
    }

}
