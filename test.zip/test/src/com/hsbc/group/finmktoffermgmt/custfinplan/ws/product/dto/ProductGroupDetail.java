
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>productGroupDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productGroupDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="productCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="productExternalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productGroupDetail", propOrder = {
    "productCount",
    "productExternalTypeCode"
})
public class ProductGroupDetail {

    protected int productCount;
    protected String productExternalTypeCode;

    /**
     * ��ȡproductCount���Ե�ֵ��
     * 
     */
    public int getProductCount() {
        return productCount;
    }

    /**
     * ����productCount���Ե�ֵ��
     * 
     */
    public void setProductCount(int value) {
        this.productCount = value;
    }

    /**
     * ��ȡproductExternalTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductExternalTypeCode() {
        return productExternalTypeCode;
    }

    /**
     * ����productExternalTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductExternalTypeCode(String value) {
        this.productExternalTypeCode = value;
    }

}
