
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>portfolioAssetAllocationSummary complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="portfolioAssetAllocationSummary"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="portfolioAssetAllocations" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioAssetAllocation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "portfolioAssetAllocationSummary", propOrder = {
    "portfolioAssetAllocations",
    "portfolioLevelCode"
})
public class PortfolioAssetAllocationSummary {

    @XmlElement(nillable = true)
    protected List<PortfolioAssetAllocation> portfolioAssetAllocations;
    protected String portfolioLevelCode;

    /**
     * Gets the value of the portfolioAssetAllocations property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the portfolioAssetAllocations property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPortfolioAssetAllocations().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PortfolioAssetAllocation }
     * 
     * 
     */
    public List<PortfolioAssetAllocation> getPortfolioAssetAllocations() {
        if (portfolioAssetAllocations == null) {
            portfolioAssetAllocations = new ArrayList<PortfolioAssetAllocation>();
        }
        return this.portfolioAssetAllocations;
    }

    /**
     * ��ȡportfolioLevelCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioLevelCode() {
        return portfolioLevelCode;
    }

    /**
     * ����portfolioLevelCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioLevelCode(String value) {
        this.portfolioLevelCode = value;
    }

}
