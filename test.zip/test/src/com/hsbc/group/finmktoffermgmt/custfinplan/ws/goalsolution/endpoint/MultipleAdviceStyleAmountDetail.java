
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>multipleAdviceStyleAmountDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="multipleAdviceStyleAmountDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="lumpSumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="lumpSumCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="monthlyInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="monthlyInvestmentCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="totalAllocatedAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalAllocatedCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "multipleAdviceStyleAmountDetail", propOrder = {
    "lumpSumAmount",
    "lumpSumCurrencyCode",
    "monthlyInvestmentAmount",
    "monthlyInvestmentCurrencyCode",
    "totalAllocatedAmount",
    "totalAllocatedCurrencyCode"
})
public class MultipleAdviceStyleAmountDetail {

    protected BigDecimal lumpSumAmount;
    protected String lumpSumCurrencyCode;
    protected BigDecimal monthlyInvestmentAmount;
    protected String monthlyInvestmentCurrencyCode;
    protected BigDecimal totalAllocatedAmount;
    protected String totalAllocatedCurrencyCode;

    /**
     * ��ȡlumpSumAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLumpSumAmount() {
        return lumpSumAmount;
    }

    /**
     * ����lumpSumAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLumpSumAmount(BigDecimal value) {
        this.lumpSumAmount = value;
    }

    /**
     * ��ȡlumpSumCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLumpSumCurrencyCode() {
        return lumpSumCurrencyCode;
    }

    /**
     * ����lumpSumCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLumpSumCurrencyCode(String value) {
        this.lumpSumCurrencyCode = value;
    }

    /**
     * ��ȡmonthlyInvestmentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMonthlyInvestmentAmount() {
        return monthlyInvestmentAmount;
    }

    /**
     * ����monthlyInvestmentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMonthlyInvestmentAmount(BigDecimal value) {
        this.monthlyInvestmentAmount = value;
    }

    /**
     * ��ȡmonthlyInvestmentCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonthlyInvestmentCurrencyCode() {
        return monthlyInvestmentCurrencyCode;
    }

    /**
     * ����monthlyInvestmentCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonthlyInvestmentCurrencyCode(String value) {
        this.monthlyInvestmentCurrencyCode = value;
    }

    /**
     * ��ȡtotalAllocatedAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAllocatedAmount() {
        return totalAllocatedAmount;
    }

    /**
     * ����totalAllocatedAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAllocatedAmount(BigDecimal value) {
        this.totalAllocatedAmount = value;
    }

    /**
     * ��ȡtotalAllocatedCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalAllocatedCurrencyCode() {
        return totalAllocatedCurrencyCode;
    }

    /**
     * ����totalAllocatedCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalAllocatedCurrencyCode(String value) {
        this.totalAllocatedCurrencyCode = value;
    }

}
