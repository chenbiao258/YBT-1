
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CurrencyAmount }
     * 
     */
    public CurrencyAmount createCurrencyAmount() {
        return new CurrencyAmount();
    }

    /**
     * Create an instance of {@link ConcentrationRisk }
     * 
     */
    public ConcentrationRisk createConcentrationRisk() {
        return new ConcentrationRisk();
    }

    /**
     * Create an instance of {@link PaginationDetail }
     * 
     */
    public PaginationDetail createPaginationDetail() {
        return new PaginationDetail();
    }

    /**
     * Create an instance of {@link ProductSearchCriteria }
     * 
     */
    public ProductSearchCriteria createProductSearchCriteria() {
        return new ProductSearchCriteria();
    }

    /**
     * Create an instance of {@link FilterCriteriaFormula }
     * 
     */
    public FilterCriteriaFormula createFilterCriteriaFormula() {
        return new FilterCriteriaFormula();
    }

    /**
     * Create an instance of {@link KeyValueCriteriaWithIndex }
     * 
     */
    public KeyValueCriteriaWithIndex createKeyValueCriteriaWithIndex() {
        return new KeyValueCriteriaWithIndex();
    }

    /**
     * Create an instance of {@link KeyValueWithIndex }
     * 
     */
    public KeyValueWithIndex createKeyValueWithIndex() {
        return new KeyValueWithIndex();
    }

    /**
     * Create an instance of {@link Value }
     * 
     */
    public Value createValue() {
        return new Value();
    }

    /**
     * Create an instance of {@link SearchCriteria }
     * 
     */
    public SearchCriteria createSearchCriteria() {
        return new SearchCriteria();
    }

    /**
     * Create an instance of {@link SortingCriteria }
     * 
     */
    public SortingCriteria createSortingCriteria() {
        return new SortingCriteria();
    }

    /**
     * Create an instance of {@link ProductSearchResult }
     * 
     */
    public ProductSearchResult createProductSearchResult() {
        return new ProductSearchResult();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link ComboUnderlyingProduct }
     * 
     */
    public ComboUnderlyingProduct createComboUnderlyingProduct() {
        return new ComboUnderlyingProduct();
    }

    /**
     * Create an instance of {@link EligibilityResult }
     * 
     */
    public EligibilityResult createEligibilityResult() {
        return new EligibilityResult();
    }

    /**
     * Create an instance of {@link EligibleWrapper }
     * 
     */
    public EligibleWrapper createEligibleWrapper() {
        return new EligibleWrapper();
    }

    /**
     * Create an instance of {@link InvestProductFeature }
     * 
     */
    public InvestProductFeature createInvestProductFeature() {
        return new InvestProductFeature();
    }

    /**
     * Create an instance of {@link ProductAttribute }
     * 
     */
    public ProductAttribute createProductAttribute() {
        return new ProductAttribute();
    }

    /**
     * Create an instance of {@link ProductKey }
     * 
     */
    public ProductKey createProductKey() {
        return new ProductKey();
    }

    /**
     * Create an instance of {@link ProductAssetAllocation }
     * 
     */
    public ProductAssetAllocation createProductAssetAllocation() {
        return new ProductAssetAllocation();
    }

    /**
     * Create an instance of {@link QuoteDetail }
     * 
     */
    public QuoteDetail createQuoteDetail() {
        return new QuoteDetail();
    }

    /**
     * Create an instance of {@link GoalSolutionRiderInformation }
     * 
     */
    public GoalSolutionRiderInformation createGoalSolutionRiderInformation() {
        return new GoalSolutionRiderInformation();
    }

    /**
     * Create an instance of {@link GoalSolutionRiderAttribute }
     * 
     */
    public GoalSolutionRiderAttribute createGoalSolutionRiderAttribute() {
        return new GoalSolutionRiderAttribute();
    }

    /**
     * Create an instance of {@link QuotationAttribute }
     * 
     */
    public QuotationAttribute createQuotationAttribute() {
        return new QuotationAttribute();
    }

    /**
     * Create an instance of {@link ProductSubtypeResult }
     * 
     */
    public ProductSubtypeResult createProductSubtypeResult() {
        return new ProductSubtypeResult();
    }

    /**
     * Create an instance of {@link ProductCountResult }
     * 
     */
    public ProductCountResult createProductCountResult() {
        return new ProductCountResult();
    }

    /**
     * Create an instance of {@link ProductGroupDetail }
     * 
     */
    public ProductGroupDetail createProductGroupDetail() {
        return new ProductGroupDetail();
    }

    /**
     * Create an instance of {@link WrapperDetail }
     * 
     */
    public WrapperDetail createWrapperDetail() {
        return new WrapperDetail();
    }

    /**
     * Create an instance of {@link ProductAccordion }
     * 
     */
    public ProductAccordion createProductAccordion() {
        return new ProductAccordion();
    }

    /**
     * Create an instance of {@link CacheIndicator }
     * 
     */
    public CacheIndicator createCacheIndicator() {
        return new CacheIndicator();
    }

    /**
     * Create an instance of {@link CalculationResultDetail }
     * 
     */
    public CalculationResultDetail createCalculationResultDetail() {
        return new CalculationResultDetail();
    }

    /**
     * Create an instance of {@link RiskProfile }
     * 
     */
    public RiskProfile createRiskProfile() {
        return new RiskProfile();
    }

    /**
     * Create an instance of {@link AlternativeProductAttribute }
     * 
     */
    public AlternativeProductAttribute createAlternativeProductAttribute() {
        return new AlternativeProductAttribute();
    }

    /**
     * Create an instance of {@link PackageKey }
     * 
     */
    public PackageKey createPackageKey() {
        return new PackageKey();
    }

    /**
     * Create an instance of {@link SelectedProduct }
     * 
     */
    public SelectedProduct createSelectedProduct() {
        return new SelectedProduct();
    }

}
