
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.InvestorIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.Comment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.CoreReserveArea;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.LocalFieldsArea;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto.InvestmentAppropriateness;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CacheIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.simulator.dto.Status;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>retrieveGoalSolutionDetailWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalSolutionDetailWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="context"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="entry" maxOccurs="999" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
 *                             &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="goalSummary" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalSummary" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="eligibleForControlAdvice" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibleForControlAdvice" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="affordability" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordability" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="affordabilityValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordabilityValidation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assetConcentration" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentration" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assetConcentrationValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentrationValidation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="piqQuestAndAnsDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}piqQuestAndAnsDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="piqAnswerValidationInfo" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}piqAnswerValidationInfo" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investmentAppropriateness" type="{http://dto.preference.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investmentAppropriateness" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="needEvaluation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}needEvaluation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="purposeBuyingProduct" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}purposeBuyingProduct" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="notes" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}notes" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="comment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="status" type="{http://dto.simulator.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}status" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="selectionDetail" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}selectionDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productList" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productList" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productTable" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productTable" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="existingHolding" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}existingHolding" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="actualPortfolioAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}actualPortfolioAllocation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="currentPortfolioAllocationList" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currentPortfolioAllocationList" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="modelPortfolioAssetClassAllocationList" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}modelPortfolioAssetClassAllocationList" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioCalculationResult" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioCalculationResult" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="controlAdviceJourney" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}controlAdviceJourney" minOccurs="0"/&gt;
 *         &lt;element name="alternativeProduct" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}alternativeProduct" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="declaration" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}declaration" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investorIndicator" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investorIndicator" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="cacheIndicator" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}cacheIndicator" minOccurs="0"/&gt;
 *         &lt;element name="coreReserveArea" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}coreReserveArea" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="localFieldsArea" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}localFieldsArea" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="amountDeviationPercentage" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}amountDeviationPercentage" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalSolutionDetailWSResponse", propOrder = {
    "context",
    "goalSummary",
    "eligibleForControlAdvice",
    "affordability",
    "affordabilityValidation",
    "assetConcentration",
    "assetConcentrationValidation",
    "piqQuestAndAnsDetails",
    "piqAnswerValidationInfo",
    "investmentAppropriateness",
    "needEvaluation",
    "purposeBuyingProduct",
    "notes",
    "comment",
    "status",
    "selectionDetail",
    "productList",
    "productTable",
    "existingHolding",
    "actualPortfolioAllocation",
    "currentPortfolioAllocationList",
    "modelPortfolioAssetClassAllocationList",
    "portfolioCalculationResult",
    "controlAdviceJourney",
    "alternativeProduct",
    "declaration",
    "investorIndicator",
    "cacheIndicator",
    "coreReserveArea",
    "localFieldsArea",
    "amountDeviationPercentage"
})
public class RetrieveGoalSolutionDetailWSResponse
    extends WebServiceResponse
{

    @XmlElement(required = true)
    protected RetrieveGoalSolutionDetailWSResponse.Context context;
    @XmlElement(nillable = true)
    protected List<GoalSummary> goalSummary;
    @XmlElement(nillable = true)
    protected List<EligibleForControlAdvice> eligibleForControlAdvice;
    @XmlElement(nillable = true)
    protected List<Affordability> affordability;
    @XmlElement(nillable = true)
    protected List<AffordabilityValidation> affordabilityValidation;
    @XmlElement(nillable = true)
    protected List<AssetConcentration> assetConcentration;
    @XmlElement(nillable = true)
    protected List<AssetConcentrationValidation> assetConcentrationValidation;
    @XmlElement(nillable = true)
    protected List<PiqQuestAndAnsDetails> piqQuestAndAnsDetails;
    @XmlElement(nillable = true)
    protected List<PiqAnswerValidationInfo> piqAnswerValidationInfo;
    @XmlElement(nillable = true)
    protected List<InvestmentAppropriateness> investmentAppropriateness;
    @XmlElement(nillable = true)
    protected List<NeedEvaluation> needEvaluation;
    @XmlElement(nillable = true)
    protected List<PurposeBuyingProduct> purposeBuyingProduct;
    @XmlElement(nillable = true)
    protected List<Notes> notes;
    @XmlElement(nillable = true)
    protected List<Comment> comment;
    @XmlElement(nillable = true)
    protected List<Status> status;
    @XmlElement(nillable = true)
    protected List<SelectionDetail> selectionDetail;
    @XmlElement(nillable = true)
    protected List<ProductList> productList;
    @XmlElement(nillable = true)
    protected List<ProductTable> productTable;
    @XmlElement(nillable = true)
    protected List<ExistingHolding> existingHolding;
    @XmlElement(nillable = true)
    protected List<ActualPortfolioAllocation> actualPortfolioAllocation;
    @XmlElement(nillable = true)
    protected List<CurrentPortfolioAllocationList> currentPortfolioAllocationList;
    @XmlElement(nillable = true)
    protected List<ModelPortfolioAssetClassAllocationList> modelPortfolioAssetClassAllocationList;
    @XmlElement(nillable = true)
    protected List<PortfolioCalculationResult> portfolioCalculationResult;
    protected ControlAdviceJourney controlAdviceJourney;
    @XmlElement(nillable = true)
    protected List<AlternativeProduct> alternativeProduct;
    @XmlElement(nillable = true)
    protected List<Declaration> declaration;
    @XmlElement(nillable = true)
    protected List<InvestorIndicator> investorIndicator;
    protected CacheIndicator cacheIndicator;
    @XmlElement(nillable = true)
    protected List<CoreReserveArea> coreReserveArea;
    @XmlElement(nillable = true)
    protected List<LocalFieldsArea> localFieldsArea;
    @XmlElement(nillable = true)
    protected List<AmountDeviationPercentage> amountDeviationPercentage;

    /**
     * ��ȡcontext���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link RetrieveGoalSolutionDetailWSResponse.Context }
     *     
     */
    public RetrieveGoalSolutionDetailWSResponse.Context getContext() {
        return context;
    }

    /**
     * ����context���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveGoalSolutionDetailWSResponse.Context }
     *     
     */
    public void setContext(RetrieveGoalSolutionDetailWSResponse.Context value) {
        this.context = value;
    }

    /**
     * Gets the value of the goalSummary property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalSummary property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalSummary().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalSummary }
     * 
     * 
     */
    public List<GoalSummary> getGoalSummary() {
        if (goalSummary == null) {
            goalSummary = new ArrayList<GoalSummary>();
        }
        return this.goalSummary;
    }

    /**
     * Gets the value of the eligibleForControlAdvice property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibleForControlAdvice property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibleForControlAdvice().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibleForControlAdvice }
     * 
     * 
     */
    public List<EligibleForControlAdvice> getEligibleForControlAdvice() {
        if (eligibleForControlAdvice == null) {
            eligibleForControlAdvice = new ArrayList<EligibleForControlAdvice>();
        }
        return this.eligibleForControlAdvice;
    }

    /**
     * Gets the value of the affordability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Affordability }
     * 
     * 
     */
    public List<Affordability> getAffordability() {
        if (affordability == null) {
            affordability = new ArrayList<Affordability>();
        }
        return this.affordability;
    }

    /**
     * Gets the value of the affordabilityValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordabilityValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordabilityValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AffordabilityValidation }
     * 
     * 
     */
    public List<AffordabilityValidation> getAffordabilityValidation() {
        if (affordabilityValidation == null) {
            affordabilityValidation = new ArrayList<AffordabilityValidation>();
        }
        return this.affordabilityValidation;
    }

    /**
     * Gets the value of the assetConcentration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentration }
     * 
     * 
     */
    public List<AssetConcentration> getAssetConcentration() {
        if (assetConcentration == null) {
            assetConcentration = new ArrayList<AssetConcentration>();
        }
        return this.assetConcentration;
    }

    /**
     * Gets the value of the assetConcentrationValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentrationValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentrationValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentrationValidation }
     * 
     * 
     */
    public List<AssetConcentrationValidation> getAssetConcentrationValidation() {
        if (assetConcentrationValidation == null) {
            assetConcentrationValidation = new ArrayList<AssetConcentrationValidation>();
        }
        return this.assetConcentrationValidation;
    }

    /**
     * Gets the value of the piqQuestAndAnsDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the piqQuestAndAnsDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPiqQuestAndAnsDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PiqQuestAndAnsDetails }
     * 
     * 
     */
    public List<PiqQuestAndAnsDetails> getPiqQuestAndAnsDetails() {
        if (piqQuestAndAnsDetails == null) {
            piqQuestAndAnsDetails = new ArrayList<PiqQuestAndAnsDetails>();
        }
        return this.piqQuestAndAnsDetails;
    }

    /**
     * Gets the value of the piqAnswerValidationInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the piqAnswerValidationInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPiqAnswerValidationInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PiqAnswerValidationInfo }
     * 
     * 
     */
    public List<PiqAnswerValidationInfo> getPiqAnswerValidationInfo() {
        if (piqAnswerValidationInfo == null) {
            piqAnswerValidationInfo = new ArrayList<PiqAnswerValidationInfo>();
        }
        return this.piqAnswerValidationInfo;
    }

    /**
     * Gets the value of the investmentAppropriateness property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investmentAppropriateness property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestmentAppropriateness().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestmentAppropriateness }
     * 
     * 
     */
    public List<InvestmentAppropriateness> getInvestmentAppropriateness() {
        if (investmentAppropriateness == null) {
            investmentAppropriateness = new ArrayList<InvestmentAppropriateness>();
        }
        return this.investmentAppropriateness;
    }

    /**
     * Gets the value of the needEvaluation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the needEvaluation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNeedEvaluation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NeedEvaluation }
     * 
     * 
     */
    public List<NeedEvaluation> getNeedEvaluation() {
        if (needEvaluation == null) {
            needEvaluation = new ArrayList<NeedEvaluation>();
        }
        return this.needEvaluation;
    }

    /**
     * Gets the value of the purposeBuyingProduct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the purposeBuyingProduct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPurposeBuyingProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PurposeBuyingProduct }
     * 
     * 
     */
    public List<PurposeBuyingProduct> getPurposeBuyingProduct() {
        if (purposeBuyingProduct == null) {
            purposeBuyingProduct = new ArrayList<PurposeBuyingProduct>();
        }
        return this.purposeBuyingProduct;
    }

    /**
     * Gets the value of the notes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the notes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNotes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Notes }
     * 
     * 
     */
    public List<Notes> getNotes() {
        if (notes == null) {
            notes = new ArrayList<Notes>();
        }
        return this.notes;
    }

    /**
     * Gets the value of the comment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<Comment>();
        }
        return this.comment;
    }

    /**
     * Gets the value of the status property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the status property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Status }
     * 
     * 
     */
    public List<Status> getStatus() {
        if (status == null) {
            status = new ArrayList<Status>();
        }
        return this.status;
    }

    /**
     * Gets the value of the selectionDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the selectionDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSelectionDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SelectionDetail }
     * 
     * 
     */
    public List<SelectionDetail> getSelectionDetail() {
        if (selectionDetail == null) {
            selectionDetail = new ArrayList<SelectionDetail>();
        }
        return this.selectionDetail;
    }

    /**
     * Gets the value of the productList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductList }
     * 
     * 
     */
    public List<ProductList> getProductList() {
        if (productList == null) {
            productList = new ArrayList<ProductList>();
        }
        return this.productList;
    }

    /**
     * Gets the value of the productTable property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productTable property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductTable().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductTable }
     * 
     * 
     */
    public List<ProductTable> getProductTable() {
        if (productTable == null) {
            productTable = new ArrayList<ProductTable>();
        }
        return this.productTable;
    }

    /**
     * Gets the value of the existingHolding property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the existingHolding property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExistingHolding().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExistingHolding }
     * 
     * 
     */
    public List<ExistingHolding> getExistingHolding() {
        if (existingHolding == null) {
            existingHolding = new ArrayList<ExistingHolding>();
        }
        return this.existingHolding;
    }

    /**
     * Gets the value of the actualPortfolioAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actualPortfolioAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActualPortfolioAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActualPortfolioAllocation }
     * 
     * 
     */
    public List<ActualPortfolioAllocation> getActualPortfolioAllocation() {
        if (actualPortfolioAllocation == null) {
            actualPortfolioAllocation = new ArrayList<ActualPortfolioAllocation>();
        }
        return this.actualPortfolioAllocation;
    }

    /**
     * Gets the value of the currentPortfolioAllocationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the currentPortfolioAllocationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCurrentPortfolioAllocationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentPortfolioAllocationList }
     * 
     * 
     */
    public List<CurrentPortfolioAllocationList> getCurrentPortfolioAllocationList() {
        if (currentPortfolioAllocationList == null) {
            currentPortfolioAllocationList = new ArrayList<CurrentPortfolioAllocationList>();
        }
        return this.currentPortfolioAllocationList;
    }

    /**
     * Gets the value of the modelPortfolioAssetClassAllocationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modelPortfolioAssetClassAllocationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModelPortfolioAssetClassAllocationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModelPortfolioAssetClassAllocationList }
     * 
     * 
     */
    public List<ModelPortfolioAssetClassAllocationList> getModelPortfolioAssetClassAllocationList() {
        if (modelPortfolioAssetClassAllocationList == null) {
            modelPortfolioAssetClassAllocationList = new ArrayList<ModelPortfolioAssetClassAllocationList>();
        }
        return this.modelPortfolioAssetClassAllocationList;
    }

    /**
     * Gets the value of the portfolioCalculationResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the portfolioCalculationResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPortfolioCalculationResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PortfolioCalculationResult }
     * 
     * 
     */
    public List<PortfolioCalculationResult> getPortfolioCalculationResult() {
        if (portfolioCalculationResult == null) {
            portfolioCalculationResult = new ArrayList<PortfolioCalculationResult>();
        }
        return this.portfolioCalculationResult;
    }

    /**
     * ��ȡcontrolAdviceJourney���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ControlAdviceJourney }
     *     
     */
    public ControlAdviceJourney getControlAdviceJourney() {
        return controlAdviceJourney;
    }

    /**
     * ����controlAdviceJourney���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ControlAdviceJourney }
     *     
     */
    public void setControlAdviceJourney(ControlAdviceJourney value) {
        this.controlAdviceJourney = value;
    }

    /**
     * Gets the value of the alternativeProduct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternativeProduct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternativeProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AlternativeProduct }
     * 
     * 
     */
    public List<AlternativeProduct> getAlternativeProduct() {
        if (alternativeProduct == null) {
            alternativeProduct = new ArrayList<AlternativeProduct>();
        }
        return this.alternativeProduct;
    }

    /**
     * Gets the value of the declaration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the declaration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeclaration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Declaration }
     * 
     * 
     */
    public List<Declaration> getDeclaration() {
        if (declaration == null) {
            declaration = new ArrayList<Declaration>();
        }
        return this.declaration;
    }

    /**
     * Gets the value of the investorIndicator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investorIndicator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestorIndicator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestorIndicator }
     * 
     * 
     */
    public List<InvestorIndicator> getInvestorIndicator() {
        if (investorIndicator == null) {
            investorIndicator = new ArrayList<InvestorIndicator>();
        }
        return this.investorIndicator;
    }

    /**
     * ��ȡcacheIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CacheIndicator }
     *     
     */
    public CacheIndicator getCacheIndicator() {
        return cacheIndicator;
    }

    /**
     * ����cacheIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CacheIndicator }
     *     
     */
    public void setCacheIndicator(CacheIndicator value) {
        this.cacheIndicator = value;
    }

    /**
     * Gets the value of the coreReserveArea property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coreReserveArea property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoreReserveArea().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoreReserveArea }
     * 
     * 
     */
    public List<CoreReserveArea> getCoreReserveArea() {
        if (coreReserveArea == null) {
            coreReserveArea = new ArrayList<CoreReserveArea>();
        }
        return this.coreReserveArea;
    }

    /**
     * Gets the value of the localFieldsArea property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the localFieldsArea property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocalFieldsArea().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LocalFieldsArea }
     * 
     * 
     */
    public List<LocalFieldsArea> getLocalFieldsArea() {
        if (localFieldsArea == null) {
            localFieldsArea = new ArrayList<LocalFieldsArea>();
        }
        return this.localFieldsArea;
    }

    /**
     * Gets the value of the amountDeviationPercentage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the amountDeviationPercentage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAmountDeviationPercentage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AmountDeviationPercentage }
     * 
     * 
     */
    public List<AmountDeviationPercentage> getAmountDeviationPercentage() {
        if (amountDeviationPercentage == null) {
            amountDeviationPercentage = new ArrayList<AmountDeviationPercentage>();
        }
        return this.amountDeviationPercentage;
    }


    /**
     * <p>anonymous complex type�� Java �ࡣ
     * 
     * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="entry" maxOccurs="999" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
     *                   &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "entry"
    })
    public static class Context {

        protected List<RetrieveGoalSolutionDetailWSResponse.Context.Entry> entry;

        /**
         * Gets the value of the entry property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the entry property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEntry().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RetrieveGoalSolutionDetailWSResponse.Context.Entry }
         * 
         * 
         */
        public List<RetrieveGoalSolutionDetailWSResponse.Context.Entry> getEntry() {
            if (entry == null) {
                entry = new ArrayList<RetrieveGoalSolutionDetailWSResponse.Context.Entry>();
            }
            return this.entry;
        }


        /**
         * <p>anonymous complex type�� Java �ࡣ
         * 
         * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
         *         &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "key",
            "value"
        })
        public static class Entry {

            protected Object key;
            protected Object value;

            /**
             * ��ȡkey���Ե�ֵ��
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getKey() {
                return key;
            }

            /**
             * ����key���Ե�ֵ��
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setKey(Object value) {
                this.key = value;
            }

            /**
             * ��ȡvalue���Ե�ֵ��
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getValue() {
                return value;
            }

            /**
             * ����value���Ե�ֵ��
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setValue(Object value) {
                this.value = value;
            }

        }

    }

}
