
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>investmentProductList complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="investmentProductList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="allocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="currencyAssetAllocationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyinvestmentMonthlyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="investmentInitialAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="investmentMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="productId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productId" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "investmentProductList", propOrder = {
    "allocationSequenceNumber",
    "currencyAssetAllocationCode",
    "currencyinvestmentMonthlyCode",
    "investmentInitialAmount",
    "investmentMonthlyAmount",
    "productId"
})
public class InvestmentProductList {

    protected long allocationSequenceNumber;
    protected String currencyAssetAllocationCode;
    protected String currencyinvestmentMonthlyCode;
    protected BigDecimal investmentInitialAmount;
    protected BigDecimal investmentMonthlyAmount;
    protected ProductId productId;

    /**
     * ��ȡallocationSequenceNumber���Ե�ֵ��
     * 
     */
    public long getAllocationSequenceNumber() {
        return allocationSequenceNumber;
    }

    /**
     * ����allocationSequenceNumber���Ե�ֵ��
     * 
     */
    public void setAllocationSequenceNumber(long value) {
        this.allocationSequenceNumber = value;
    }

    /**
     * ��ȡcurrencyAssetAllocationCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAssetAllocationCode() {
        return currencyAssetAllocationCode;
    }

    /**
     * ����currencyAssetAllocationCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAssetAllocationCode(String value) {
        this.currencyAssetAllocationCode = value;
    }

    /**
     * ��ȡcurrencyinvestmentMonthlyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyinvestmentMonthlyCode() {
        return currencyinvestmentMonthlyCode;
    }

    /**
     * ����currencyinvestmentMonthlyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyinvestmentMonthlyCode(String value) {
        this.currencyinvestmentMonthlyCode = value;
    }

    /**
     * ��ȡinvestmentInitialAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentInitialAmount() {
        return investmentInitialAmount;
    }

    /**
     * ����investmentInitialAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentInitialAmount(BigDecimal value) {
        this.investmentInitialAmount = value;
    }

    /**
     * ��ȡinvestmentMonthlyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentMonthlyAmount() {
        return investmentMonthlyAmount;
    }

    /**
     * ����investmentMonthlyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentMonthlyAmount(BigDecimal value) {
        this.investmentMonthlyAmount = value;
    }

    /**
     * ��ȡproductId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ProductId }
     *     
     */
    public ProductId getProductId() {
        return productId;
    }

    /**
     * ����productId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ProductId }
     *     
     */
    public void setProductId(ProductId value) {
        this.productId = value;
    }

}
