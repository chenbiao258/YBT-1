
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.dto.FilteringCriteria;
import com.hsbc.swp.common.ws.dto.LocaleCode;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>retrieveGoalSummaryListWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalSummaryListWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="filteringCriteria" type="{http://dto.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}filteringCriteria" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="localeCode" type="{http://dto.ws.common.swp.hsbc.com/}localeCode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalSummaryListWSRequest", propOrder = {
    "customers",
    "filteringCriteria",
    "jointCustomer",
    "localeCode"
})
public class RetrieveGoalSummaryListWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<FilteringCriteria> filteringCriteria;
    protected Customer jointCustomer;
    protected LocaleCode localeCode;

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the filteringCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the filteringCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFilteringCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FilteringCriteria }
     * 
     * 
     */
    public List<FilteringCriteria> getFilteringCriteria() {
        if (filteringCriteria == null) {
            filteringCriteria = new ArrayList<FilteringCriteria>();
        }
        return this.filteringCriteria;
    }

    /**
     * ��ȡjointCustomer���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * ����jointCustomer���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * ��ȡlocaleCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link LocaleCode }
     *     
     */
    public LocaleCode getLocaleCode() {
        return localeCode;
    }

    /**
     * ����localeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link LocaleCode }
     *     
     */
    public void setLocaleCode(LocaleCode value) {
        this.localeCode = value;
    }

}
