
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>quotationAttribute complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="quotationAttribute"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="proReturnAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="proReturnCcy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="projectDef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="quotationIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="targetAge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="targetYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "quotationAttribute", propOrder = {
    "proReturnAmount",
    "proReturnCcy",
    "projectDef",
    "quotationIndicator",
    "targetAge",
    "targetYear"
})
public class QuotationAttribute {

    protected BigDecimal proReturnAmount;
    protected String proReturnCcy;
    protected String projectDef;
    protected String quotationIndicator;
    protected String targetAge;
    protected String targetYear;

    /**
     * ��ȡproReturnAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getProReturnAmount() {
        return proReturnAmount;
    }

    /**
     * ����proReturnAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setProReturnAmount(BigDecimal value) {
        this.proReturnAmount = value;
    }

    /**
     * ��ȡproReturnCcy���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProReturnCcy() {
        return proReturnCcy;
    }

    /**
     * ����proReturnCcy���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProReturnCcy(String value) {
        this.proReturnCcy = value;
    }

    /**
     * ��ȡprojectDef���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProjectDef() {
        return projectDef;
    }

    /**
     * ����projectDef���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProjectDef(String value) {
        this.projectDef = value;
    }

    /**
     * ��ȡquotationIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationIndicator() {
        return quotationIndicator;
    }

    /**
     * ����quotationIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationIndicator(String value) {
        this.quotationIndicator = value;
    }

    /**
     * ��ȡtargetAge���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetAge() {
        return targetAge;
    }

    /**
     * ����targetAge���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetAge(String value) {
        this.targetAge = value;
    }

    /**
     * ��ȡtargetYear���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetYear() {
        return targetYear;
    }

    /**
     * ����targetYear���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetYear(String value) {
        this.targetYear = value;
    }

}
