
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto.InvestmentAppropriateness;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto.InvestmentPreference;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.PaginationDetail;


/**
 * <p>retrieveProductSearchResultWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveProductSearchResultWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSelectionWSRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="investmentAppropriateness" type="{http://dto.preference.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investmentAppropriateness" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investmentPreference" type="{http://dto.preference.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investmentPreference" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="paginationDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}paginationDetail" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveProductSearchResultWSRequest", propOrder = {
    "investmentAppropriateness",
    "investmentPreference",
    "paginationDetail"
})
public class RetrieveProductSearchResultWSRequest
    extends ProductSelectionWSRequest
{

    @XmlElement(nillable = true)
    protected List<InvestmentAppropriateness> investmentAppropriateness;
    @XmlElement(nillable = true)
    protected List<InvestmentPreference> investmentPreference;
    protected PaginationDetail paginationDetail;

    /**
     * Gets the value of the investmentAppropriateness property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investmentAppropriateness property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestmentAppropriateness().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestmentAppropriateness }
     * 
     * 
     */
    public List<InvestmentAppropriateness> getInvestmentAppropriateness() {
        if (investmentAppropriateness == null) {
            investmentAppropriateness = new ArrayList<InvestmentAppropriateness>();
        }
        return this.investmentAppropriateness;
    }

    /**
     * Gets the value of the investmentPreference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investmentPreference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestmentPreference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestmentPreference }
     * 
     * 
     */
    public List<InvestmentPreference> getInvestmentPreference() {
        if (investmentPreference == null) {
            investmentPreference = new ArrayList<InvestmentPreference>();
        }
        return this.investmentPreference;
    }

    /**
     * ��ȡpaginationDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PaginationDetail }
     *     
     */
    public PaginationDetail getPaginationDetail() {
        return paginationDetail;
    }

    /**
     * ����paginationDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PaginationDetail }
     *     
     */
    public void setPaginationDetail(PaginationDetail value) {
        this.paginationDetail = value;
    }

}
