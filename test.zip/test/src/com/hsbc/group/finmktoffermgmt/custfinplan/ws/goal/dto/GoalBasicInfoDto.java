
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>goalBasicInfoDto complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="goalBasicInfoDto"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="arrangementIdentifierFinancialPlanning" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="goalCompleteDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalObjectiveTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productIdDto" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productIdDto" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="reopenCount" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="reportLastPrintDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalBasicInfoDto", propOrder = {
    "arrangementIdentifierFinancialPlanning",
    "goalCompleteDate",
    "goalObjectiveTypeCode",
    "goalSequenceNumber",
    "goalTypeCode",
    "needTypeCode",
    "productIdDto",
    "reopenCount",
    "reportLastPrintDate",
    "status"
})
public class GoalBasicInfoDto {

    protected Long arrangementIdentifierFinancialPlanning;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalCompleteDate;
    protected String goalObjectiveTypeCode;
    protected Long goalSequenceNumber;
    protected String goalTypeCode;
    protected String needTypeCode;
    @XmlElement(nillable = true)
    protected List<ProductIdDto> productIdDto;
    protected Long reopenCount;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reportLastPrintDate;
    protected String status;

    /**
     * ��ȡarrangementIdentifierFinancialPlanning���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArrangementIdentifierFinancialPlanning() {
        return arrangementIdentifierFinancialPlanning;
    }

    /**
     * ����arrangementIdentifierFinancialPlanning���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArrangementIdentifierFinancialPlanning(Long value) {
        this.arrangementIdentifierFinancialPlanning = value;
    }

    /**
     * ��ȡgoalCompleteDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalCompleteDate() {
        return goalCompleteDate;
    }

    /**
     * ����goalCompleteDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalCompleteDate(XMLGregorianCalendar value) {
        this.goalCompleteDate = value;
    }

    /**
     * ��ȡgoalObjectiveTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalObjectiveTypeCode() {
        return goalObjectiveTypeCode;
    }

    /**
     * ����goalObjectiveTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalObjectiveTypeCode(String value) {
        this.goalObjectiveTypeCode = value;
    }

    /**
     * ��ȡgoalSequenceNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getGoalSequenceNumber() {
        return goalSequenceNumber;
    }

    /**
     * ����goalSequenceNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setGoalSequenceNumber(Long value) {
        this.goalSequenceNumber = value;
    }

    /**
     * ��ȡgoalTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * ����goalTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * ��ȡneedTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * ����needTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

    /**
     * Gets the value of the productIdDto property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productIdDto property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductIdDto().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductIdDto }
     * 
     * 
     */
    public List<ProductIdDto> getProductIdDto() {
        if (productIdDto == null) {
            productIdDto = new ArrayList<ProductIdDto>();
        }
        return this.productIdDto;
    }

    /**
     * ��ȡreopenCount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getReopenCount() {
        return reopenCount;
    }

    /**
     * ����reopenCount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setReopenCount(Long value) {
        this.reopenCount = value;
    }

    /**
     * ��ȡreportLastPrintDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReportLastPrintDate() {
        return reportLastPrintDate;
    }

    /**
     * ����reportLastPrintDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReportLastPrintDate(XMLGregorianCalendar value) {
        this.reportLastPrintDate = value;
    }

    /**
     * ��ȡstatus���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * ����status���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
