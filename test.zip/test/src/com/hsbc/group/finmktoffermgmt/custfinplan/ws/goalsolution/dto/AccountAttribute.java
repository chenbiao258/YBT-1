
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>accountAttribute complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="accountAttribute"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountNickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountProductTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="countryAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dashboardAccountSubGroupIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="groupMemberAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="restrictWrapperFromSwitchingIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="wrapperManagementStyle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "accountAttribute", propOrder = {
    "accountNickName",
    "accountNumber",
    "accountProductTypeCode",
    "accountTypeCode",
    "countryAccountCode",
    "currencyAccountCode",
    "dashboardAccountSubGroupIdentifier",
    "groupMemberAccountCode",
    "restrictWrapperFromSwitchingIndicator",
    "wrapperManagementStyle"
})
public class AccountAttribute {

    protected String accountNickName;
    protected String accountNumber;
    protected String accountProductTypeCode;
    protected String accountTypeCode;
    protected String countryAccountCode;
    protected String currencyAccountCode;
    protected String dashboardAccountSubGroupIdentifier;
    protected String groupMemberAccountCode;
    protected Boolean restrictWrapperFromSwitchingIndicator;
    protected String wrapperManagementStyle;

    /**
     * ��ȡaccountNickName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNickName() {
        return accountNickName;
    }

    /**
     * ����accountNickName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNickName(String value) {
        this.accountNickName = value;
    }

    /**
     * ��ȡaccountNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * ����accountNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * ��ȡaccountProductTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountProductTypeCode() {
        return accountProductTypeCode;
    }

    /**
     * ����accountProductTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountProductTypeCode(String value) {
        this.accountProductTypeCode = value;
    }

    /**
     * ��ȡaccountTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    /**
     * ����accountTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeCode(String value) {
        this.accountTypeCode = value;
    }

    /**
     * ��ȡcountryAccountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryAccountCode() {
        return countryAccountCode;
    }

    /**
     * ����countryAccountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryAccountCode(String value) {
        this.countryAccountCode = value;
    }

    /**
     * ��ȡcurrencyAccountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAccountCode() {
        return currencyAccountCode;
    }

    /**
     * ����currencyAccountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAccountCode(String value) {
        this.currencyAccountCode = value;
    }

    /**
     * ��ȡdashboardAccountSubGroupIdentifier���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDashboardAccountSubGroupIdentifier() {
        return dashboardAccountSubGroupIdentifier;
    }

    /**
     * ����dashboardAccountSubGroupIdentifier���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDashboardAccountSubGroupIdentifier(String value) {
        this.dashboardAccountSubGroupIdentifier = value;
    }

    /**
     * ��ȡgroupMemberAccountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupMemberAccountCode() {
        return groupMemberAccountCode;
    }

    /**
     * ����groupMemberAccountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupMemberAccountCode(String value) {
        this.groupMemberAccountCode = value;
    }

    /**
     * ��ȡrestrictWrapperFromSwitchingIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRestrictWrapperFromSwitchingIndicator() {
        return restrictWrapperFromSwitchingIndicator;
    }

    /**
     * ����restrictWrapperFromSwitchingIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRestrictWrapperFromSwitchingIndicator(Boolean value) {
        this.restrictWrapperFromSwitchingIndicator = value;
    }

    /**
     * ��ȡwrapperManagementStyle���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrapperManagementStyle() {
        return wrapperManagementStyle;
    }

    /**
     * ����wrapperManagementStyle���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrapperManagementStyle(String value) {
        this.wrapperManagementStyle = value;
    }

}
