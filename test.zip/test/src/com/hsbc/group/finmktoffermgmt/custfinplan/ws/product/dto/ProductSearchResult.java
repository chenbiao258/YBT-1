
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>productSearchResult complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productSearchResult"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="paginationDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}paginationDetail" minOccurs="0"/&gt;
 *         &lt;element name="product" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}product" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productSearchResult", propOrder = {
    "paginationDetail",
    "product",
    "productSelectionMethodCode"
})
public class ProductSearchResult {

    protected PaginationDetail paginationDetail;
    @XmlElement(nillable = true)
    protected List<Product> product;
    protected String productSelectionMethodCode;

    /**
     * ��ȡpaginationDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PaginationDetail }
     *     
     */
    public PaginationDetail getPaginationDetail() {
        return paginationDetail;
    }

    /**
     * ����paginationDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PaginationDetail }
     *     
     */
    public void setPaginationDetail(PaginationDetail value) {
        this.paginationDetail = value;
    }

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Product }
     * 
     * 
     */
    public List<Product> getProduct() {
        if (product == null) {
            product = new ArrayList<Product>();
        }
        return this.product;
    }

    /**
     * ��ȡproductSelectionMethodCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * ����productSelectionMethodCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

}
