
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>calculateRiskCapacityCriteria complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacityCriteria"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="riskCustomerToleranceLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacityCriteria", propOrder = {
    "riskCustomerToleranceLevelNumber"
})
public class CalculateRiskCapacityCriteria {

    protected int riskCustomerToleranceLevelNumber;

    /**
     * ��ȡriskCustomerToleranceLevelNumber���Ե�ֵ��
     * 
     */
    public int getRiskCustomerToleranceLevelNumber() {
        return riskCustomerToleranceLevelNumber;
    }

    /**
     * ����riskCustomerToleranceLevelNumber���Ե�ֵ��
     * 
     */
    public void setRiskCustomerToleranceLevelNumber(int value) {
        this.riskCustomerToleranceLevelNumber = value;
    }

}
