
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>quoteDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="quoteDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="coverageInsuranceAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="coverageTerm" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="coverageTermPeriodicityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyCoverageInsuranceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyPremiumInsuranceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalSolutionRiderInformationList" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalSolutionRiderInformation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="insuranceQuotationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="paymentTermBeyondRetirement" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="periodicityPaymentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="premiumInsuranceAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="quotationAttrubuteList" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quotationAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="quotationDataWiringInformation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="quotationPaymentTermMismatchIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="quoteExpired" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "quoteDetail", propOrder = {
    "coverageInsuranceAmount",
    "coverageTerm",
    "coverageTermPeriodicityCode",
    "currencyCoverageInsuranceCode",
    "currencyPremiumInsuranceCode",
    "goalSolutionRiderInformationList",
    "insuranceQuotationSequenceNumber",
    "paymentTermBeyondRetirement",
    "periodicityPaymentCode",
    "premiumInsuranceAmount",
    "quotationAttrubuteList",
    "quotationDataWiringInformation",
    "quotationPaymentTermMismatchIndicator",
    "quoteExpired"
})
public class QuoteDetail {

    protected BigDecimal coverageInsuranceAmount;
    protected BigDecimal coverageTerm;
    protected String coverageTermPeriodicityCode;
    protected String currencyCoverageInsuranceCode;
    protected String currencyPremiumInsuranceCode;
    @XmlElement(nillable = true)
    protected List<GoalSolutionRiderInformation> goalSolutionRiderInformationList;
    protected long insuranceQuotationSequenceNumber;
    protected BigDecimal paymentTermBeyondRetirement;
    protected String periodicityPaymentCode;
    protected BigDecimal premiumInsuranceAmount;
    @XmlElement(nillable = true)
    protected List<QuotationAttribute> quotationAttrubuteList;
    protected String quotationDataWiringInformation;
    protected String quotationPaymentTermMismatchIndicator;
    protected String quoteExpired;

    /**
     * ��ȡcoverageInsuranceAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCoverageInsuranceAmount() {
        return coverageInsuranceAmount;
    }

    /**
     * ����coverageInsuranceAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCoverageInsuranceAmount(BigDecimal value) {
        this.coverageInsuranceAmount = value;
    }

    /**
     * ��ȡcoverageTerm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCoverageTerm() {
        return coverageTerm;
    }

    /**
     * ����coverageTerm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCoverageTerm(BigDecimal value) {
        this.coverageTerm = value;
    }

    /**
     * ��ȡcoverageTermPeriodicityCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoverageTermPeriodicityCode() {
        return coverageTermPeriodicityCode;
    }

    /**
     * ����coverageTermPeriodicityCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoverageTermPeriodicityCode(String value) {
        this.coverageTermPeriodicityCode = value;
    }

    /**
     * ��ȡcurrencyCoverageInsuranceCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCoverageInsuranceCode() {
        return currencyCoverageInsuranceCode;
    }

    /**
     * ����currencyCoverageInsuranceCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCoverageInsuranceCode(String value) {
        this.currencyCoverageInsuranceCode = value;
    }

    /**
     * ��ȡcurrencyPremiumInsuranceCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyPremiumInsuranceCode() {
        return currencyPremiumInsuranceCode;
    }

    /**
     * ����currencyPremiumInsuranceCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyPremiumInsuranceCode(String value) {
        this.currencyPremiumInsuranceCode = value;
    }

    /**
     * Gets the value of the goalSolutionRiderInformationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalSolutionRiderInformationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalSolutionRiderInformationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalSolutionRiderInformation }
     * 
     * 
     */
    public List<GoalSolutionRiderInformation> getGoalSolutionRiderInformationList() {
        if (goalSolutionRiderInformationList == null) {
            goalSolutionRiderInformationList = new ArrayList<GoalSolutionRiderInformation>();
        }
        return this.goalSolutionRiderInformationList;
    }

    /**
     * ��ȡinsuranceQuotationSequenceNumber���Ե�ֵ��
     * 
     */
    public long getInsuranceQuotationSequenceNumber() {
        return insuranceQuotationSequenceNumber;
    }

    /**
     * ����insuranceQuotationSequenceNumber���Ե�ֵ��
     * 
     */
    public void setInsuranceQuotationSequenceNumber(long value) {
        this.insuranceQuotationSequenceNumber = value;
    }

    /**
     * ��ȡpaymentTermBeyondRetirement���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPaymentTermBeyondRetirement() {
        return paymentTermBeyondRetirement;
    }

    /**
     * ����paymentTermBeyondRetirement���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPaymentTermBeyondRetirement(BigDecimal value) {
        this.paymentTermBeyondRetirement = value;
    }

    /**
     * ��ȡperiodicityPaymentCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicityPaymentCode() {
        return periodicityPaymentCode;
    }

    /**
     * ����periodicityPaymentCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicityPaymentCode(String value) {
        this.periodicityPaymentCode = value;
    }

    /**
     * ��ȡpremiumInsuranceAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPremiumInsuranceAmount() {
        return premiumInsuranceAmount;
    }

    /**
     * ����premiumInsuranceAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPremiumInsuranceAmount(BigDecimal value) {
        this.premiumInsuranceAmount = value;
    }

    /**
     * Gets the value of the quotationAttrubuteList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the quotationAttrubuteList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuotationAttrubuteList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuotationAttribute }
     * 
     * 
     */
    public List<QuotationAttribute> getQuotationAttrubuteList() {
        if (quotationAttrubuteList == null) {
            quotationAttrubuteList = new ArrayList<QuotationAttribute>();
        }
        return this.quotationAttrubuteList;
    }

    /**
     * ��ȡquotationDataWiringInformation���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationDataWiringInformation() {
        return quotationDataWiringInformation;
    }

    /**
     * ����quotationDataWiringInformation���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationDataWiringInformation(String value) {
        this.quotationDataWiringInformation = value;
    }

    /**
     * ��ȡquotationPaymentTermMismatchIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationPaymentTermMismatchIndicator() {
        return quotationPaymentTermMismatchIndicator;
    }

    /**
     * ����quotationPaymentTermMismatchIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationPaymentTermMismatchIndicator(String value) {
        this.quotationPaymentTermMismatchIndicator = value;
    }

    /**
     * ��ȡquoteExpired���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuoteExpired() {
        return quoteExpired;
    }

    /**
     * ����quoteExpired���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuoteExpired(String value) {
        this.quoteExpired = value;
    }

}
