
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.MultipleAdviceStyleAmountDetail;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.MultipleAdviceStyleHoldingDetails;


/**
 * <p>multipleAdviceStyleDetails complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="multipleAdviceStyleDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="eligible" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="multipleAdviceStyleAmountDetail" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}multipleAdviceStyleAmountDetail" minOccurs="0"/&gt;
 *         &lt;element name="multipleAdviceStyleHoldingDetails" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}multipleAdviceStyleHoldingDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="preferred" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="selected" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "multipleAdviceStyleDetails", propOrder = {
    "eligible",
    "multipleAdviceStyleAmountDetail",
    "multipleAdviceStyleHoldingDetails",
    "preferred",
    "productSelectionMethodCode",
    "selected",
    "status"
})
public class MultipleAdviceStyleDetails {

    protected String eligible;
    protected MultipleAdviceStyleAmountDetail multipleAdviceStyleAmountDetail;
    @XmlElement(nillable = true)
    protected List<MultipleAdviceStyleHoldingDetails> multipleAdviceStyleHoldingDetails;
    protected String preferred;
    protected String productSelectionMethodCode;
    protected String selected;
    protected String status;

    /**
     * ��ȡeligible���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligible() {
        return eligible;
    }

    /**
     * ����eligible���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligible(String value) {
        this.eligible = value;
    }

    /**
     * ��ȡmultipleAdviceStyleAmountDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link MultipleAdviceStyleAmountDetail }
     *     
     */
    public MultipleAdviceStyleAmountDetail getMultipleAdviceStyleAmountDetail() {
        return multipleAdviceStyleAmountDetail;
    }

    /**
     * ����multipleAdviceStyleAmountDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link MultipleAdviceStyleAmountDetail }
     *     
     */
    public void setMultipleAdviceStyleAmountDetail(MultipleAdviceStyleAmountDetail value) {
        this.multipleAdviceStyleAmountDetail = value;
    }

    /**
     * Gets the value of the multipleAdviceStyleHoldingDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the multipleAdviceStyleHoldingDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMultipleAdviceStyleHoldingDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MultipleAdviceStyleHoldingDetails }
     * 
     * 
     */
    public List<MultipleAdviceStyleHoldingDetails> getMultipleAdviceStyleHoldingDetails() {
        if (multipleAdviceStyleHoldingDetails == null) {
            multipleAdviceStyleHoldingDetails = new ArrayList<MultipleAdviceStyleHoldingDetails>();
        }
        return this.multipleAdviceStyleHoldingDetails;
    }

    /**
     * ��ȡpreferred���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferred() {
        return preferred;
    }

    /**
     * ����preferred���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferred(String value) {
        this.preferred = value;
    }

    /**
     * ��ȡproductSelectionMethodCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * ����productSelectionMethodCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * ��ȡselected���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelected() {
        return selected;
    }

    /**
     * ����selected���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelected(String value) {
        this.selected = value;
    }

    /**
     * ��ȡstatus���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * ����status���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
