
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>productAssetAllocation complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productAssetAllocation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="adjustmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="adjustmentAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="assetAllocationCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="constrainedAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="constrainedCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="currentAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="targetLumpSumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="targetLumpSumAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="targetMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="targetMonthlyAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="unconstrainedNewMoneyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="unconstrainedNewMoneyAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productAssetAllocation", propOrder = {
    "adjustmentAmount",
    "adjustmentAmountCurrencyCode",
    "allocationInvestmentPercent",
    "allocationSequenceNumber",
    "assetAllocationCurrencyCode",
    "constrainedAmount",
    "constrainedCurrencyCode",
    "currentAmount",
    "currentAmountCurrencyCode",
    "targetLumpSumAmount",
    "targetLumpSumAmountCurrencyCode",
    "targetMonthlyAmount",
    "targetMonthlyAmountCurrencyCode",
    "unconstrainedNewMoneyAmount",
    "unconstrainedNewMoneyAmountCurrencyCode"
})
public class ProductAssetAllocation {

    protected BigDecimal adjustmentAmount;
    protected String adjustmentAmountCurrencyCode;
    protected BigDecimal allocationInvestmentPercent;
    protected Long allocationSequenceNumber;
    protected String assetAllocationCurrencyCode;
    protected BigDecimal constrainedAmount;
    protected String constrainedCurrencyCode;
    protected BigDecimal currentAmount;
    protected String currentAmountCurrencyCode;
    protected BigDecimal targetLumpSumAmount;
    protected String targetLumpSumAmountCurrencyCode;
    protected BigDecimal targetMonthlyAmount;
    protected String targetMonthlyAmountCurrencyCode;
    protected BigDecimal unconstrainedNewMoneyAmount;
    protected String unconstrainedNewMoneyAmountCurrencyCode;

    /**
     * ��ȡadjustmentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAdjustmentAmount() {
        return adjustmentAmount;
    }

    /**
     * ����adjustmentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAdjustmentAmount(BigDecimal value) {
        this.adjustmentAmount = value;
    }

    /**
     * ��ȡadjustmentAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdjustmentAmountCurrencyCode() {
        return adjustmentAmountCurrencyCode;
    }

    /**
     * ����adjustmentAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdjustmentAmountCurrencyCode(String value) {
        this.adjustmentAmountCurrencyCode = value;
    }

    /**
     * ��ȡallocationInvestmentPercent���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPercent() {
        return allocationInvestmentPercent;
    }

    /**
     * ����allocationInvestmentPercent���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPercent(BigDecimal value) {
        this.allocationInvestmentPercent = value;
    }

    /**
     * ��ȡallocationSequenceNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAllocationSequenceNumber() {
        return allocationSequenceNumber;
    }

    /**
     * ����allocationSequenceNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAllocationSequenceNumber(Long value) {
        this.allocationSequenceNumber = value;
    }

    /**
     * ��ȡassetAllocationCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetAllocationCurrencyCode() {
        return assetAllocationCurrencyCode;
    }

    /**
     * ����assetAllocationCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetAllocationCurrencyCode(String value) {
        this.assetAllocationCurrencyCode = value;
    }

    /**
     * ��ȡconstrainedAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getConstrainedAmount() {
        return constrainedAmount;
    }

    /**
     * ����constrainedAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setConstrainedAmount(BigDecimal value) {
        this.constrainedAmount = value;
    }

    /**
     * ��ȡconstrainedCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConstrainedCurrencyCode() {
        return constrainedCurrencyCode;
    }

    /**
     * ����constrainedCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConstrainedCurrencyCode(String value) {
        this.constrainedCurrencyCode = value;
    }

    /**
     * ��ȡcurrentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentAmount() {
        return currentAmount;
    }

    /**
     * ����currentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentAmount(BigDecimal value) {
        this.currentAmount = value;
    }

    /**
     * ��ȡcurrentAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentAmountCurrencyCode() {
        return currentAmountCurrencyCode;
    }

    /**
     * ����currentAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentAmountCurrencyCode(String value) {
        this.currentAmountCurrencyCode = value;
    }

    /**
     * ��ȡtargetLumpSumAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTargetLumpSumAmount() {
        return targetLumpSumAmount;
    }

    /**
     * ����targetLumpSumAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTargetLumpSumAmount(BigDecimal value) {
        this.targetLumpSumAmount = value;
    }

    /**
     * ��ȡtargetLumpSumAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetLumpSumAmountCurrencyCode() {
        return targetLumpSumAmountCurrencyCode;
    }

    /**
     * ����targetLumpSumAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetLumpSumAmountCurrencyCode(String value) {
        this.targetLumpSumAmountCurrencyCode = value;
    }

    /**
     * ��ȡtargetMonthlyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTargetMonthlyAmount() {
        return targetMonthlyAmount;
    }

    /**
     * ����targetMonthlyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTargetMonthlyAmount(BigDecimal value) {
        this.targetMonthlyAmount = value;
    }

    /**
     * ��ȡtargetMonthlyAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetMonthlyAmountCurrencyCode() {
        return targetMonthlyAmountCurrencyCode;
    }

    /**
     * ����targetMonthlyAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetMonthlyAmountCurrencyCode(String value) {
        this.targetMonthlyAmountCurrencyCode = value;
    }

    /**
     * ��ȡunconstrainedNewMoneyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUnconstrainedNewMoneyAmount() {
        return unconstrainedNewMoneyAmount;
    }

    /**
     * ����unconstrainedNewMoneyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUnconstrainedNewMoneyAmount(BigDecimal value) {
        this.unconstrainedNewMoneyAmount = value;
    }

    /**
     * ��ȡunconstrainedNewMoneyAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnconstrainedNewMoneyAmountCurrencyCode() {
        return unconstrainedNewMoneyAmountCurrencyCode;
    }

    /**
     * ����unconstrainedNewMoneyAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnconstrainedNewMoneyAmountCurrencyCode(String value) {
        this.unconstrainedNewMoneyAmountCurrencyCode = value;
    }

}
