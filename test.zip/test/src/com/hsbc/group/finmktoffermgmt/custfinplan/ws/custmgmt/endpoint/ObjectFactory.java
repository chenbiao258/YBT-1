
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.endpoint;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.endpoint package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveCustomerFinancialInfo_QNAME = new QName("http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveCustomerFinancialInfo");
    private final static QName _RetrieveCustomerFinancialInfoResponse_QNAME = new QName("http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveCustomerFinancialInfoResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.endpoint
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RetrieveCustomerFinancialInfo }
     * 
     */
    public RetrieveCustomerFinancialInfo createRetrieveCustomerFinancialInfo() {
        return new RetrieveCustomerFinancialInfo();
    }

    /**
     * Create an instance of {@link RetrieveCustomerFinancialInfoResponse }
     * 
     */
    public RetrieveCustomerFinancialInfoResponse createRetrieveCustomerFinancialInfoResponse() {
        return new RetrieveCustomerFinancialInfoResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveCustomerFinancialInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveCustomerFinancialInfo")
    public JAXBElement<RetrieveCustomerFinancialInfo> createRetrieveCustomerFinancialInfo(RetrieveCustomerFinancialInfo value) {
        return new JAXBElement<RetrieveCustomerFinancialInfo>(_RetrieveCustomerFinancialInfo_QNAME, RetrieveCustomerFinancialInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveCustomerFinancialInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveCustomerFinancialInfoResponse")
    public JAXBElement<RetrieveCustomerFinancialInfoResponse> createRetrieveCustomerFinancialInfoResponse(RetrieveCustomerFinancialInfoResponse value) {
        return new JAXBElement<RetrieveCustomerFinancialInfoResponse>(_RetrieveCustomerFinancialInfoResponse_QNAME, RetrieveCustomerFinancialInfoResponse.class, null, value);
    }

}
