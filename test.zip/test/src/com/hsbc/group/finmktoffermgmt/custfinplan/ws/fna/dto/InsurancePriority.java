
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>insurancePriority complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="insurancePriority"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="insurancePriorityDetail" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}insurancePriorityDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="insurancePriorityId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="insurancePriorityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="insurancePriorityType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "insurancePriority", propOrder = {
    "insurancePriorityDetail",
    "insurancePriorityId",
    "insurancePriorityName",
    "insurancePriorityType"
})
public class InsurancePriority {

    @XmlElement(nillable = true)
    protected List<InsurancePriorityDetail> insurancePriorityDetail;
    protected Long insurancePriorityId;
    protected String insurancePriorityName;
    protected String insurancePriorityType;

    /**
     * Gets the value of the insurancePriorityDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the insurancePriorityDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInsurancePriorityDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InsurancePriorityDetail }
     * 
     * 
     */
    public List<InsurancePriorityDetail> getInsurancePriorityDetail() {
        if (insurancePriorityDetail == null) {
            insurancePriorityDetail = new ArrayList<InsurancePriorityDetail>();
        }
        return this.insurancePriorityDetail;
    }

    /**
     * ��ȡinsurancePriorityId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getInsurancePriorityId() {
        return insurancePriorityId;
    }

    /**
     * ����insurancePriorityId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setInsurancePriorityId(Long value) {
        this.insurancePriorityId = value;
    }

    /**
     * ��ȡinsurancePriorityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsurancePriorityName() {
        return insurancePriorityName;
    }

    /**
     * ����insurancePriorityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsurancePriorityName(String value) {
        this.insurancePriorityName = value;
    }

    /**
     * ��ȡinsurancePriorityType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsurancePriorityType() {
        return insurancePriorityType;
    }

    /**
     * ����insurancePriorityType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsurancePriorityType(String value) {
        this.insurancePriorityType = value;
    }

}
