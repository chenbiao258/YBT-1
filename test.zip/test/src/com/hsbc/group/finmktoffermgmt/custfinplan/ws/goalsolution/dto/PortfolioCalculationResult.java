
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>portfolioCalculationResult complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="portfolioCalculationResult"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="portfolioRickLevelValidationIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="riskLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "portfolioCalculationResult", propOrder = {
    "portfolioRickLevelValidationIndicator",
    "riskLevelNumber"
})
public class PortfolioCalculationResult {

    protected String portfolioRickLevelValidationIndicator;
    protected int riskLevelNumber;

    /**
     * ��ȡportfolioRickLevelValidationIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioRickLevelValidationIndicator() {
        return portfolioRickLevelValidationIndicator;
    }

    /**
     * ����portfolioRickLevelValidationIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioRickLevelValidationIndicator(String value) {
        this.portfolioRickLevelValidationIndicator = value;
    }

    /**
     * ��ȡriskLevelNumber���Ե�ֵ��
     * 
     */
    public int getRiskLevelNumber() {
        return riskLevelNumber;
    }

    /**
     * ����riskLevelNumber���Ե�ֵ��
     * 
     */
    public void setRiskLevelNumber(int value) {
        this.riskLevelNumber = value;
    }

}
