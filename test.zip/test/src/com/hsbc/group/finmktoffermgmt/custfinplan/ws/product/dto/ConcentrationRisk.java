
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>concentrationRisk complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="concentrationRisk"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="concentrationRiskRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="concentrationRiskSuitabilityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="exceedThresholdIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="thresholdValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "concentrationRisk", propOrder = {
    "concentrationRiskRate",
    "concentrationRiskSuitabilityIndicator",
    "exceedThresholdIndicator",
    "thresholdValue"
})
public class ConcentrationRisk {

    protected BigDecimal concentrationRiskRate;
    protected String concentrationRiskSuitabilityIndicator;
    protected String exceedThresholdIndicator;
    protected BigDecimal thresholdValue;

    /**
     * ��ȡconcentrationRiskRate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getConcentrationRiskRate() {
        return concentrationRiskRate;
    }

    /**
     * ����concentrationRiskRate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setConcentrationRiskRate(BigDecimal value) {
        this.concentrationRiskRate = value;
    }

    /**
     * ��ȡconcentrationRiskSuitabilityIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConcentrationRiskSuitabilityIndicator() {
        return concentrationRiskSuitabilityIndicator;
    }

    /**
     * ����concentrationRiskSuitabilityIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConcentrationRiskSuitabilityIndicator(String value) {
        this.concentrationRiskSuitabilityIndicator = value;
    }

    /**
     * ��ȡexceedThresholdIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceedThresholdIndicator() {
        return exceedThresholdIndicator;
    }

    /**
     * ����exceedThresholdIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceedThresholdIndicator(String value) {
        this.exceedThresholdIndicator = value;
    }

    /**
     * ��ȡthresholdValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getThresholdValue() {
        return thresholdValue;
    }

    /**
     * ����thresholdValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setThresholdValue(BigDecimal value) {
        this.thresholdValue = value;
    }

}
