
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>quoteId complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="quoteId"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="applicationReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="quotationInternalReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "quoteId", propOrder = {
    "applicationReferenceNumber",
    "quotationInternalReferenceNumber"
})
public class QuoteId {

    protected String applicationReferenceNumber;
    protected String quotationInternalReferenceNumber;

    /**
     * ��ȡapplicationReferenceNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationReferenceNumber() {
        return applicationReferenceNumber;
    }

    /**
     * ����applicationReferenceNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationReferenceNumber(String value) {
        this.applicationReferenceNumber = value;
    }

    /**
     * ��ȡquotationInternalReferenceNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotationInternalReferenceNumber() {
        return quotationInternalReferenceNumber;
    }

    /**
     * ����quotationInternalReferenceNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotationInternalReferenceNumber(String value) {
        this.quotationInternalReferenceNumber = value;
    }

}
