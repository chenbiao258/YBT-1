
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CurrencyAmount;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.PaginationDetail;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.ProductAccordion;


/**
 * <p>retrieveManagedSolutionDetailWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveManagedSolutionDetailWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSelectionWSResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="engagementStyleAmount" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currencyAmount" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="engagementStyleAttribute" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}attribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productAccordion" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAccordion" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="paginationDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}paginationDetail" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveManagedSolutionDetailWSResponse", propOrder = {
    "engagementStyleAmount",
    "engagementStyleAttribute",
    "productAccordion",
    "paginationDetail"
})
public class RetrieveManagedSolutionDetailWSResponse
    extends ProductSelectionWSResponse
{

    @XmlElement(nillable = true)
    protected List<CurrencyAmount> engagementStyleAmount;
    @XmlElement(nillable = true)
    protected List<Attribute> engagementStyleAttribute;
    @XmlElement(nillable = true)
    protected List<ProductAccordion> productAccordion;
    protected PaginationDetail paginationDetail;

    /**
     * Gets the value of the engagementStyleAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the engagementStyleAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEngagementStyleAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAmount }
     * 
     * 
     */
    public List<CurrencyAmount> getEngagementStyleAmount() {
        if (engagementStyleAmount == null) {
            engagementStyleAmount = new ArrayList<CurrencyAmount>();
        }
        return this.engagementStyleAmount;
    }

    /**
     * Gets the value of the engagementStyleAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the engagementStyleAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEngagementStyleAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Attribute }
     * 
     * 
     */
    public List<Attribute> getEngagementStyleAttribute() {
        if (engagementStyleAttribute == null) {
            engagementStyleAttribute = new ArrayList<Attribute>();
        }
        return this.engagementStyleAttribute;
    }

    /**
     * Gets the value of the productAccordion property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAccordion property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAccordion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAccordion }
     * 
     * 
     */
    public List<ProductAccordion> getProductAccordion() {
        if (productAccordion == null) {
            productAccordion = new ArrayList<ProductAccordion>();
        }
        return this.productAccordion;
    }

    /**
     * ��ȡpaginationDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PaginationDetail }
     *     
     */
    public PaginationDetail getPaginationDetail() {
        return paginationDetail;
    }

    /**
     * ����paginationDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PaginationDetail }
     *     
     */
    public void setPaginationDetail(PaginationDetail value) {
        this.paginationDetail = value;
    }

}
