
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>riskProfile complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="riskProfile"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="riskCapacityAssignDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="riskCapacityLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="riskCapacityRecommendLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="riskToleranceLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "riskProfile", propOrder = {
    "riskCapacityAssignDate",
    "riskCapacityLevelNumber",
    "riskCapacityRecommendLevelNumber",
    "riskToleranceLevelNumber"
})
public class RiskProfile {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar riskCapacityAssignDate;
    protected Integer riskCapacityLevelNumber;
    protected Integer riskCapacityRecommendLevelNumber;
    protected Integer riskToleranceLevelNumber;

    /**
     * ��ȡriskCapacityAssignDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRiskCapacityAssignDate() {
        return riskCapacityAssignDate;
    }

    /**
     * ����riskCapacityAssignDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRiskCapacityAssignDate(XMLGregorianCalendar value) {
        this.riskCapacityAssignDate = value;
    }

    /**
     * ��ȡriskCapacityLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityLevelNumber() {
        return riskCapacityLevelNumber;
    }

    /**
     * ����riskCapacityLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityLevelNumber(Integer value) {
        this.riskCapacityLevelNumber = value;
    }

    /**
     * ��ȡriskCapacityRecommendLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityRecommendLevelNumber() {
        return riskCapacityRecommendLevelNumber;
    }

    /**
     * ����riskCapacityRecommendLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityRecommendLevelNumber(Integer value) {
        this.riskCapacityRecommendLevelNumber = value;
    }

    /**
     * ��ȡriskToleranceLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskToleranceLevelNumber() {
        return riskToleranceLevelNumber;
    }

    /**
     * ����riskToleranceLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskToleranceLevelNumber(Integer value) {
        this.riskToleranceLevelNumber = value;
    }

}
