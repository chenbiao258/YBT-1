package com;


/***
 * �?有�?�讯 功能类的父接�?
 * @author CDK
 *
 */
public interface SinoCommunicate {

	
}
