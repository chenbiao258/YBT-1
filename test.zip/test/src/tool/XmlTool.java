package tool;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.CustomerAttribute;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.RetrieveFinancialSituationDataWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.RequestComment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.RequestInvestorIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.SubserviceId;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CacheIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto.LocaleCode;
import com.hsbc.swp.common.ws.dto.SessionInfo;

public class XmlTool {
	private List<Map<String,Object>> list =new ArrayList<Map<String,Object>>();
	
	/**
	 * 方法描述：用递归法 得到XML报文中所有的节点与值并存入map中
	 *  @param node 节点
	 */
	public void getNodes(Element node){ 
		Map<String,Object> map1 =new HashMap<String, Object>();
		if(node.getName().equals("attributeKey")){
			List attrList = node.attributes();
			if(attrList==null||attrList.size()==0){
				map1.put("attributeKey",null);
			}else{
			    Attribute item = (Attribute)attrList.get(0);
				map1.put("attributeKey",item==null?null:item.getValue());
			}			
		}else if(node.getName().equals("attributeValue")){
			List attrList = node.attributes();
			if(attrList==null||attrList.size()==06){
				map1.put("attributeValue",null);
			}else{
			    Attribute item = (Attribute)attrList.get(0);
				map1.put("attributeValue",item==null?null:item.getValue());
			}				
		}else{
			 map1.put(node.getName(), node.getTextTrim());
		}        
         System.out.println(node.getName()+"-----"+ node.getTextTrim());
         list.add(map1);
         
 	    //递归遍历当前节点所有的子节点  
 	    List<Element> listElement=node.elements();//所有一级子节点的list  
 	    if(listElement.size()>0){
 	    	 for(Element e:listElement){//遍历所有一级子节点  
 	 	        this.getNodes(e);//递归  
 	 	    }  	
 	    }
 	       
 	}  
	/**
	 * 方法描述：得到XML根节点
	 * @param path 文件路径
	 * @throws Exception
	 */
	 private void getRoot(String path) throws Exception{  
	        SAXReader sax=new SAXReader();//创建一个SAXReader对象  
	        File xmlFile=new File(path);//根据指定的路径创建file对象  
	        Document document=sax.read(xmlFile);//获取document对象,如果文档无节点，则会抛出Exception提前结束  
	        Element root=document.getRootElement();//获取根节点  
	        this.getNodes(root);//从根节点开始遍历所有节点  	      	            
      }	
	 
	 /**
	  * 方法描述：根据报文值组装请求参数( retrieveGoalSolutionDetail请求的参数)
	  * @param path 文件路径
	  * @return RetrieveGoalSolutionDetailWSRequest 自定义请求参数
	  * @throws Exception
	  */
	 public RetrieveGoalSolutionDetailWSRequest getGoalIdXml(String path) throws Exception{
		 this.getRoot(path);
		 RetrieveGoalSolutionDetailWSRequest retrieveGoalSolutionDetailWSRequest = new  RetrieveGoalSolutionDetailWSRequest();
		 List countryISOCodes = new ArrayList();
		 List attributeKeys = new ArrayList();
		 List attributeValues = new ArrayList();
		 List groupMemberCodes = new ArrayList();
		 List rolePlayerIdentificationNumbers = new ArrayList();
		 List sourceSystemRolePlayerCodes = new ArrayList();
		 List commentTypes = new ArrayList(); 
		 List maxHistoryNumbers = new ArrayList();
		 List indicatorKeys = new ArrayList();
		 List functionOutputCodes = new ArrayList();
		 
		 SessionInfo sessionInfo = new SessionInfo();
		 GoalKey goalKey =new GoalKey();
		 CacheIndicator cacheIndicator = new CacheIndicator();
		 LocaleCode localeCode =new LocaleCode();
		 
		 
		 for (Map<String, Object> map : list) {
			 //sessionInfo
			 if(map.get("businessLine")!=null){
				 sessionInfo.setBusinessLine(map.get("businessLine").toString()); 
			 }
			 if(map.get("channelId")!=null){
				 sessionInfo.setChannelId(map.get("channelId").toString());
			 }
			 if(map.get("countryCode")!=null){
				 sessionInfo.setCountryCode(map.get("countryCode").toString());
			 }
			 if(map.get("employeeUserId")!=null){
				 sessionInfo.setEmployeeUserId(map.get("employeeUserId").toString());
			 }
			 if(map.get("groupMember")!=null){
				 sessionInfo.setGroupMember(map.get("groupMember").toString());
			 }
			 if(map.get("hubUserId")!=null){
				 sessionInfo.setHubUserId(map.get("hubUserId").toString());
			 }
			 if(map.get("hubWorkstationId")!=null){
				 sessionInfo.setHubWorkstationId(map.get("hubWorkstationId").toString());
			 }
			 
			 //Customer
			 if(map.containsKey("countryISOCode")){
				 countryISOCodes.add(map.get("countryISOCode"));
			 }
			 if(map.containsKey("attributeKey")){
				 attributeKeys.add(map.get("attributeKey"));
			 }
			 if(map.containsKey("attributeValue")){
				 attributeValues.add(map.get("attributeValue"));
			 }
			 if(map.containsKey("groupMemberCode")){
				 groupMemberCodes.add(map.get("groupMemberCode"));
			 }
			 if(map.containsKey("rolePlayerIdentificationNumber")){
				 rolePlayerIdentificationNumbers.add(map.get("rolePlayerIdentificationNumber"));
			 }
			 if(map.containsKey("sourceSystemRolePlayerCode")){
				 sourceSystemRolePlayerCodes.add(map.get("sourceSystemRolePlayerCode"));
			 }
			 // GoalKey
			 if(map.get("arrangementIdentifierFinancialPlanning")!=null){
				 goalKey.setArrangementIdentifierFinancialPlanning(Long.parseLong(map.get("arrangementIdentifierFinancialPlanning").toString()));
			 }
			 if(map.get("goalSequenceNumber")!=null){
				 goalKey.setGoalSequenceNumber(Long.parseLong(map.get("goalSequenceNumber").toString()));
			 }
			 
			 // CacheIndicator
			 if(map.get("requestIdentificationNumber")!=null){
				 cacheIndicator.setRequestIdentificationNumber(map.get("requestIdentificationNumber").toString());
			 }
			 
			 //LocaleCode
			 if(map.get("localeCode")!=null){
				 localeCode.setLocaleCode(map.get("localeCode").toString());
			 }
			 
			 // RequestComment
			 if(map.containsKey("commentType")){
				 commentTypes.add(map.get("commentType"));
			 }
			 if(map.containsKey("maxHistoryNumber")){
				 maxHistoryNumbers.add(map.get("maxHistoryNumber"));
			 }
			 
			 if(map.get("requestDataType")!=null){
			 retrieveGoalSolutionDetailWSRequest.setRequestDataType(map.get("requestDataType").toString()); 
			 }
			 
			 //RequestInvestorIndicator
			 if(map.containsKey("indicatorKey")){
				 indicatorKeys.add(map.get("indicatorKey"));
			 }
			 
			 //SubserviceId
			 if(map.containsKey("functionOutputCode")){
				 functionOutputCodes.add(map.get("functionOutputCode"));
			 }
		}
		 
		
		 for (int i = 0; i < countryISOCodes.size(); i++) {
			 Customer customer = new Customer();
			 if(countryISOCodes.get(i)!=null){
				 customer.setCountryISOCode(countryISOCodes.get(i).toString());
			 }
			
			 if(attributeKeys.get(i)!=null||attributeValues.get(i)!=null){
				 CustomerAttribute customerAttribute = new CustomerAttribute();
				 customerAttribute.setAttributeKey(attributeKeys.get(i)==null?null:attributeKeys.get(i).toString());
				 customerAttribute.setAttributeValue(attributeValues.get(i)==null?null:attributeValues.get(i).toString());
				 customer.getCustomerAttribute().add(customerAttribute);
			 }
			if(groupMemberCodes.get(i)!=null){
				customer.setGroupMemberCode(groupMemberCodes.get(i).toString());
			} 
			if(rolePlayerIdentificationNumbers.get(i)!=null){
				customer.setRolePlayerIdentificationNumber(rolePlayerIdentificationNumbers.get(i).toString());
			}
			if(sourceSystemRolePlayerCodes.get(i)!=null){
				customer.setRolePlayerIdentificationNumber(sourceSystemRolePlayerCodes.get(i).toString());
			}
			retrieveGoalSolutionDetailWSRequest.getCustomers().add(customer);
		}		 
		 
		 for (int i = 0; i < commentTypes.size(); i++) {
			 RequestComment requestComment = new RequestComment();
			 if(commentTypes.get(i)!=null){
				 requestComment.setCommentType(commentTypes.get(i).toString());
			 }
			 if(maxHistoryNumbers.get(i)!=null){
				 requestComment.setMaxHistoryNumber(Integer.valueOf(maxHistoryNumbers.get(i).toString()));
			 }
			 retrieveGoalSolutionDetailWSRequest.getRequestComment().add(requestComment);
		}
		 for (int i = 0; i < indicatorKeys.size(); i++) {
			 RequestInvestorIndicator requestInvestorIndicator =new RequestInvestorIndicator();
			if(indicatorKeys.get(i)!=null){
				requestInvestorIndicator.setIndicatorKey(indicatorKeys.get(i).toString());
			}
		}
		 for (int i = 0; i < functionOutputCodes.size(); i++) {
			 SubserviceId subserviceId = new SubserviceId();
			 if(functionOutputCodes.get(i)!=null){
				 subserviceId.setFunctionOutputCode(functionOutputCodes.get(i).toString());
			 }
			 retrieveGoalSolutionDetailWSRequest.getSubserviceId().add(subserviceId);
		}
		 retrieveGoalSolutionDetailWSRequest.setSessionInfo(sessionInfo);
		 retrieveGoalSolutionDetailWSRequest.setGoalKey(goalKey);
		 retrieveGoalSolutionDetailWSRequest.setLocaleCode(localeCode);		   			
		 System.out.println(retrieveGoalSolutionDetailWSRequest.getSubserviceId().get(0).getFunctionOutputCode());
		
		 return retrieveGoalSolutionDetailWSRequest;		 
   }	
	 
	 /**
	  * 方法描述：根据报文值组装请求参数( retrieveFinancialSituationData请求的参数)
	  * @param path 文件路径
	  * @return RetrieveGoalSolutionDetailWSRequest 自定义请求参数
	  * @throws Exception
	  */
	  public RetrieveFinancialSituationDataWSRequest getIncom(String path) throws Exception{
		  this.getRoot(path);
		  RetrieveFinancialSituationDataWSRequest retrieveFinancialSituationDataWSRequest =new RetrieveFinancialSituationDataWSRequest();
		  SessionInfo sessionInfo = new SessionInfo();
		return null;
		}
	  public static void main(String[] args) {
		  XmlTool xmlTool = new XmlTool();
		  try {
			xmlTool.getGoalIdXml("D:/ziliao/retrieveGoalSolutionDetail_sample_request.xml");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
