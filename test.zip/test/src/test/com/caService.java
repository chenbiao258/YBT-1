package test.com;
import org.apache.soap.util.xml.*;  
import org.apache.soap.*;  
import org.apache.soap.rpc.*;  
  
import java.io.*;  
import java.net.*;  
import java.util.Vector;  
  
public class caService {  
    public static String getService(String user) {  
        URL url = null;  
        try {  
            url = new URL("http://192.168.8.107:8080/YBT_webService/services/WMSService");  
        } catch (MalformedURLException mue) {  
            return mue.getMessage();  
        }   
        Call soapCall = new Call();  
        soapCall.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);   
        soapCall.setTargetObjectURI("http://192.168.8.107:8080/YBT_webService/services/WMSService");  
        soapCall.setMethodName("getValue");  
        Vector soapParams = new Vector();  
  
        // name, type, value, encoding style  
        Parameter isbnParam = new Parameter("arg0", String.class, user,  
                null);  
        soapParams.addElement(isbnParam);  
        soapCall.setParams(soapParams);  
        try {  
            Response soapResponse = soapCall.invoke(url, "");   
            if (soapResponse.generatedFault()) {  
                Fault fault = soapResponse.getFault();  
                String f = fault.getFaultString();  
                return f;  
            } else {  
 
                Parameter soapResult = soapResponse.getReturnValue();  

                return soapResult.getValue().toString();  
            }  
        } catch (SOAPException se) {  
            return se.getMessage();  
        }  
    }  
    
    public static void main(String[] args) {
    	System.out.println(caService.getService("111"));
	}
}  