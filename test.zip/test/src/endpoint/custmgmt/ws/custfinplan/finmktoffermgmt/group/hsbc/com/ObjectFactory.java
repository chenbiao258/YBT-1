
package endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveCustomerFinancialInfo_QNAME = new QName("http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveCustomerFinancialInfo");
    private final static QName _RetrieveCustomerFinancialInfoResponse_QNAME = new QName("http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveCustomerFinancialInfoResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SessionInfo }
     * 
     */
    public SessionInfo createSessionInfo() {
        return new SessionInfo();
    }

    /**
     * Create an instance of {@link ReasonCode }
     * 
     */
    public ReasonCode createReasonCode() {
        return new ReasonCode();
    }

    /**
     * Create an instance of {@link ResponseDetails }
     * 
     */
    public ResponseDetails createResponseDetails() {
        return new ResponseDetails();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link CustomerAttribute }
     * 
     */
    public CustomerAttribute createCustomerAttribute() {
        return new CustomerAttribute();
    }

    /**
     * Create an instance of {@link RetrieveCustomerFinancialInfoWSRequest }
     * 
     */
    public RetrieveCustomerFinancialInfoWSRequest createRetrieveCustomerFinancialInfoWSRequest() {
        return new RetrieveCustomerFinancialInfoWSRequest();
    }

    /**
     * Create an instance of {@link AdditionalInformation }
     * 
     */
    public AdditionalInformation createAdditionalInformation() {
        return new AdditionalInformation();
    }

    /**
     * Create an instance of {@link RetrieveCustomerFinancialInfo }
     * 
     */
    public RetrieveCustomerFinancialInfo createRetrieveCustomerFinancialInfo() {
        return new RetrieveCustomerFinancialInfo();
    }

    /**
     * Create an instance of {@link RetrieveCustomerFinancialInfoResponse }
     * 
     */
    public RetrieveCustomerFinancialInfoResponse createRetrieveCustomerFinancialInfoResponse() {
        return new RetrieveCustomerFinancialInfoResponse();
    }

    /**
     * Create an instance of {@link RetrieveCustomerFinancialInfoWSResponse }
     * 
     */
    public RetrieveCustomerFinancialInfoWSResponse createRetrieveCustomerFinancialInfoWSResponse() {
        return new RetrieveCustomerFinancialInfoWSResponse();
    }

    /**
     * Create an instance of {@link ResponseBankNeedDetail }
     * 
     */
    public ResponseBankNeedDetail createResponseBankNeedDetail() {
        return new ResponseBankNeedDetail();
    }

    /**
     * Create an instance of {@link ResponseGoalsNoteDetail }
     * 
     */
    public ResponseGoalsNoteDetail createResponseGoalsNoteDetail() {
        return new ResponseGoalsNoteDetail();
    }

    /**
     * Create an instance of {@link PlanInfo }
     * 
     */
    public PlanInfo createPlanInfo() {
        return new PlanInfo();
    }

    /**
     * Create an instance of {@link EmergencyFund }
     * 
     */
    public EmergencyFund createEmergencyFund() {
        return new EmergencyFund();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveCustomerFinancialInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveCustomerFinancialInfo")
    public JAXBElement<RetrieveCustomerFinancialInfo> createRetrieveCustomerFinancialInfo(RetrieveCustomerFinancialInfo value) {
        return new JAXBElement<RetrieveCustomerFinancialInfo>(_RetrieveCustomerFinancialInfo_QNAME, RetrieveCustomerFinancialInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveCustomerFinancialInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveCustomerFinancialInfoResponse")
    public JAXBElement<RetrieveCustomerFinancialInfoResponse> createRetrieveCustomerFinancialInfoResponse(RetrieveCustomerFinancialInfoResponse value) {
        return new JAXBElement<RetrieveCustomerFinancialInfoResponse>(_RetrieveCustomerFinancialInfoResponse_QNAME, RetrieveCustomerFinancialInfoResponse.class, null, value);
    }

}
