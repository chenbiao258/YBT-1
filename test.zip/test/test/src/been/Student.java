package been;

public class Student {
	public String name;
	public String age;
	public ClassRoom classRoom;
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public String getAge() {
	return age;
	}
	public void setAge(String age) {
	this.age = age;
	}
	public ClassRoom getClassRoom() {
	return classRoom;
	}
	public void setClassRoom(ClassRoom classRoom) {
	this.classRoom = classRoom;

}
}