package tool;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.xpath.DefaultXPath;

public class WebServiceParseXML {

	
	public static void main(String[] args) {
//		parse();
		test();
	}
	
	public static void parse(){
		SAXReader  sax = new SAXReader();
		try {
			Document doc = sax.read("D:/webservice.xml");
			Element rootElt = doc.getRootElement();
			System.out.println("根节点：" + rootElt.getName()); // 拿到根节点的名称
//			
//		Iterator body = rootElt.elementIterator("Body"); 
			Element element = rootElt.element("Body");
			System.out.println(element.getName());
			Element element2 = element.element("retrieveGoalSolutionDetailResponse");
			System.out.println(element2.getName());
			SAXReader  sax2 = new SAXReader();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void test(){
		String b = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">"+
						"<env:Header xmlns:env=\"http://www.w3.org/2003/05/soap-envelope\"/>"+
						"<soap:Body>"+
						"<ns2:retrieveGoalSolutionDetailResponse xmlns:ns2=\"http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/\">"+
					 
							"<return>"+
				           "<responseDetails>"+
				              "<responseCode>0</responseCode>"+
				           "</responseDetails>"+
				              
							"<goalSummary>"+
				               "<additionalAmount>"+
				                  "<amountCode>FUND_ALLOC_AMT</amountCode>"+
				                  "<financialAmount>0</financialAmount>"+
				                  "<financialCurrencyCode>CNY</financialCurrencyCode>"+
				               "</additionalAmount>"+
				               "<additionalAmount>"+
				                  "<amountCode>rrrr</amountCode>"+
				                  "<financialAmount>1</financialAmount>"+
				                  "<financialCurrencyCode>gsb</financialCurrencyCode>"+
				               "</additionalAmount>"+
				                  
               					"<additionalInformation>"+
				                  "<additionalCode>INVERSTMENT_PERIOD</additionalCode>"+
				                  "<additionalValue>60</additionalValue>"+
				               "</additionalInformation>"+
				               "<additionalInformation>"+
				                  "<additionalCode>GYW_OVER_YEAR</additionalCode>"+
				                  "<additionalValue>60</additionalValue>"+
				               "</additionalInformation>"+
				                  
 								"<calculationResultDetail>"+
				                  "<returnShortfallCurrencyCode>CNY</returnShortfallCurrencyCode>"+
				                  "<simulateSegmentIndicator>I</simulateSegmentIndicator>"+
				               "</calculationResultDetail>"+
			               
								"<financialGoal>"+
				                  "<goalDescription>投资增�?_test Tenor consistency</goalDescription>"+
				                  "<goalMonthCount>720</goalMonthCount>"+
				                  "<goalObjectiveTypeCode>WEAL_ACCUM</goalObjectiveTypeCode>"+
				                  "<goalTargetAmount>423</goalTargetAmount>"+
				                  "<goalTargetCurrencyCode>CNY</goalTargetCurrencyCode>"+
				                  "<goalTypeCode>GROW_WLTH</goalTypeCode>"+
				                  "<needTypeCode>GRO_WEAL</needTypeCode>"+
				                  "<periodicityGoalCode>ANNL</periodicityGoalCode>"+
				                  "<recordCreateDateTime>2017-10-06T09:47:22.298Z</recordCreateDateTime>"+
				                  "<recordUpdateDateTime>2017-10-11T10:54:20.344Z</recordUpdateDateTime>"+
				                  "<skipRiskProfilingIndicator>N</skipRiskProfilingIndicator>"+
				               "</financialGoal>"+
				               "<fundingDetails>"+
				                  "<fundAmount>4323</fundAmount>"+
				                  "<fundCurrencyCode>CNY</fundCurrencyCode>"+
				                  "<fundMonthlyAmount>0</fundMonthlyAmount>"+
				                  "<fundMonthlyCurrencyCode>CNY</fundMonthlyCurrencyCode>"+
				              "</fundingDetails>"+
				               "<goalLocalFields>"+
				                  "<localFieldNameCode>INS_MUL_PURCH_ACK_MARK</localFieldNameCode>"+
				                  "<localFieldValue>N</localFieldValue>"+
				               "</goalLocalFields>"+
				               "<riskProfile>"+
				                  "<riskCapacityLevelNumber>5</riskCapacityLevelNumber>"+
				                  "<riskCapacityRecommendLevelNumber>5</riskCapacityRecommendLevelNumber>"+
				                  "<riskToleranceLevelNumber>5</riskToleranceLevelNumber>"+
				               "</riskProfile>"+
				               "<suitability>"+
				                  "<suitabilityIndicator>Y</suitabilityIndicator>"+
				               "</suitability>"+
			               "</goalSummary>"+
				         "</return>"+
		 
			"</ns2:retrieveGoalSolutionDetailResponse>"+
		   "</soap:Body>"+
		   "</soap:Envelope>";
		 try {
			   Document doc = DocumentHelper.parseText(b);
			   DefaultXPath xpath = new DefaultXPath("//return");
			   xpath.setNamespaceURIs(Collections.singletonMap("ns2","http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")); 
//			   xpath.setNamespaceURIs(Collections.singletonMap("ns1","http://bank.services.applications.dykj.com")); 
			   @SuppressWarnings("unchecked")
			   List<Element> list = xpath.selectNodes(doc); 
			   if(list.size()>0){
				   for(Element ele:list){
					   Element responseCode = ele.element("responseDetails").element("responseCode");
					   System.out.println(responseCode.getName()+  "  "+responseCode.getText());
					   Element goalSummary = ele.element("goalSummary");
					   
					   @SuppressWarnings("unchecked")
					   List<Element> additionalAmounts = goalSummary.elements("additionalAmount");
					   for(Element ele2:additionalAmounts){
						   Element amountCode = ele2.element("amountCode");
						   System.out.println(amountCode.getText());
						   String financialAmount = ele2.elementText("financialAmount");
						   System.out.println(financialAmount);
						   String financialCurrencyCode = ele2.elementText("financialCurrencyCode");
						   System.out.println(financialCurrencyCode);
					   }
					   @SuppressWarnings("unchecked")
					   List<Element> additionalInformations = goalSummary.elements("additionalInformation");
					   for(Element ele3:additionalInformations){
						   String additionalCode = ele3.elementText("additionalCode");
						   System.out.println(additionalCode);
						   String additionalValue = ele3.elementText("additionalValue");
						   System.out.println(additionalValue);
					   }
					   
					   String returnShortfallCurrencyCode = goalSummary.element("calculationResultDetail").elementText("returnShortfallCurrencyCode");
					   System.out.println(returnShortfallCurrencyCode);
					   String simulateSegmentIndicator = goalSummary.element("calculationResultDetail").elementText("simulateSegmentIndicator");
					   System.out.println(simulateSegmentIndicator);
					   
//					   financialGoal
					   Element financialGoal = goalSummary.element("financialGoal");
					   String goalDescription = financialGoal.elementText("goalDescription");
					   System.out.println(goalDescription);
					   
					   String goalMonthCount = financialGoal.elementText("goalMonthCount");
					   System.out.println(goalMonthCount);
					   
					   String goalObjectiveTypeCode = financialGoal.elementText("goalObjectiveTypeCode");
					   System.out.println(goalObjectiveTypeCode);
					   
					   String goalTargetAmount = financialGoal.elementText("goalTargetAmount");
					   System.out.println(goalTargetAmount);
					   
					   String goalTargetCurrencyCode = financialGoal.elementText("goalTargetCurrencyCode");
					   System.out.println(goalTargetCurrencyCode);
					   
					   String goalTypeCode = financialGoal.elementText("goalTypeCode");
					   System.out.println(goalTypeCode);
					   
					   String needTypeCode = financialGoal.elementText("needTypeCode");
					   System.out.println(needTypeCode);
					   
					   String periodicityGoalCode = financialGoal.elementText("periodicityGoalCode");
					   System.out.println(periodicityGoalCode);
					   
					   String recordCreateDateTime = financialGoal.elementText("recordCreateDateTime");
					   System.out.println(recordCreateDateTime);
					   
					   String recordUpdateDateTime = financialGoal.elementText("recordUpdateDateTime");
					   System.out.println(recordUpdateDateTime);
					   
					   String skipRiskProfilingIndicator = financialGoal.elementText("skipRiskProfilingIndicator");
					   System.out.println(skipRiskProfilingIndicator);
					   
//					   fundingDetails
					   Element fundingDetails = goalSummary.element("fundingDetails");
					  
					   String fundAmount = fundingDetails.elementText("fundAmount");
					   System.out.println(fundAmount);
					   
					   String fundCurrencyCode = fundingDetails.elementText("fundCurrencyCode");
					   System.out.println(fundCurrencyCode);
					   
					   String fundMonthlyAmount = fundingDetails.elementText("fundMonthlyAmount");
					   System.out.println(fundMonthlyAmount);
					   
					   String fundMonthlyCurrencyCode = fundingDetails.elementText("fundMonthlyCurrencyCode");
					   System.out.println(fundMonthlyCurrencyCode);
					   
					   
					   //goalLocalFields
					   Element goalLocalFields = goalSummary.element("goalLocalFields");
					   
					   String localFieldNameCode = goalLocalFields.elementText("localFieldNameCode");
					   System.out.println(localFieldNameCode);
					   
					   String localFieldValue = goalLocalFields.elementText("localFieldValue");
					   System.out.println(localFieldValue);
					   
//					   riskProfile
					   Element riskProfile = goalSummary.element("riskProfile");
					   
					   String riskCapacityLevelNumber = riskProfile.elementText("riskCapacityLevelNumber");
					   System.out.println(riskCapacityLevelNumber);
					   
					   String riskCapacityRecommendLevelNumber = riskProfile.elementText("riskCapacityRecommendLevelNumber");
					   System.out.println(riskCapacityRecommendLevelNumber);
					   
					   String riskToleranceLevelNumber = riskProfile.elementText("riskToleranceLevelNumber");
					   System.out.println(riskToleranceLevelNumber);
					   
//					   suitability
					   Element suitability = goalSummary.element("suitability");
					   String suitabilityIndicator = suitability.elementText("suitabilityIndicator");
					   System.out.println(suitabilityIndicator);
					   
					   
					   
				   }
			   }
			   
			  } catch (Exception e) {
			   e.printStackTrace();
			  }
	}

}
