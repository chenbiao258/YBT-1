package tool;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.dom4j.tree.DefaultAttribute;

import been.ClassRoom;
import been.Note;
import been.Student;

import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RecordGoalSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalPlannerInfoWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSRequest;
import com.hsbc.swp.common.ws.dto.SessionInfo;
import com.sun.xml.internal.txw2.output.XmlSerializer;


public class XmlUtil {

    public static String xmlChangeString(String filename){
        try {
            SAXReader saxReader = new SAXReader();
           Document tempDocument = saxReader.read(XmlUtil.class.getClassLoader().getResourceAsStream(filename));//锟斤拷锟斤拷一锟斤拷锟侥硷拷
            return tempDocument.asXML();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        return null;
    }
   
    /**   
     * xml字符串转换成bean对象   
     *    
     * @param xmlStr xml字符串   
     * @param clazzMap 待转换的class包括对象属性的class   
     * @return 转换后的对象   
     */    
    public static Object xmlStrToBean(String xmlStr,Map<String,Class>  clazzMap) {    
        Object obj = null;    
        try {    
            // 将xml格式的数据转换成Map对象    
  
               Map<String, Object> map = new HashMap<String, Object>();    
               //将xml格式的字符串转换成Document对象    
               Document doc = DocumentHelper.parseText(xmlStr);   
               Element root = doc.getRootElement();    
               System.out.println(root.getName()); 
              //将map对象的数据转换成Bean对象    
               obj = mapToBean(root, clazzMap);    
        } catch(Exception e) {    
            e.printStackTrace();    
        }    
        return obj;    
    }    
        
  
     
      
        
    /**   
     * 将Map对象通过反射机制转换成Bean对象   
     *    
     * @param clazzMap 待转换的class包括对象属性的class   
     * @return 转换后的Bean对象   
     * @throws Exception 异常   
     */    
    public static Object mapToBean( Element root,Map<String,Class> clazzMap) throws Exception {   
         //获取根节点下的所有元素    
        List children = root.elements();  
        List<DefaultAttribute> attrs= root.attributes();  
        
         Map<String, Object> map = new HashMap<String, Object>();   
           if(children != null && children.size() > 0) {    
               for(int i = 0; i < children.size(); i++) {                  
                  Element child = (Element)children.get(i);              
                  if(!child.isTextOnly()){                      
                     Object ob= mapToBean(child,clazzMap);  
                     map.put(child.getName(),ob);  
                  }else{  
                   map.put(child.getName(), child.getTextTrim());    
                  }  
                    
               }    
           }             
           for(DefaultAttribute att:attrs){  
               map.put(att.getName(),att.getText());    
           }  
             
        Class clazz=clazzMap.get(root.getName());     
        Object obj = clazz.newInstance();    
        if(map != null && map.size() > 0) {    
            for(Map.Entry<String, Object> entry : map.entrySet()) {    
                String propertyName = entry.getKey();    
                Object value = entry.getValue();    
                String setMethodName = "set"    
                        + propertyName.substring(0, 1).toUpperCase()    
                        + propertyName.substring(1);    
                Field field = getClassField(clazz, propertyName);    
                Class fieldTypeClass = field.getType();    
                value = convertValType(value, fieldTypeClass);    
                clazz.getMethod(setMethodName, field.getType()).invoke(obj, value);    
            }    
        }    
        return obj;    
    }    
        
    /**   
     * 将Object类型的值，转换成bean对象属性里对应的类型值   
     *    
     * @param value Object对象值   
     * @param fieldTypeClass 属性的类型   
     * @return 转换后的值   
     */    
    private static Object convertValType(Object value, Class fieldTypeClass) {    
        Object retVal = null;    
        if(Long.class.getName().equals(fieldTypeClass.getName())    
                || long.class.getName().equals(fieldTypeClass.getName())) {    
            retVal = Long.parseLong(value.toString());    
        } else if(Integer.class.getName().equals(fieldTypeClass.getName())    
                || int.class.getName().equals(fieldTypeClass.getName())) {    
            retVal = Integer.parseInt(value.toString());    
        } else if(Float.class.getName().equals(fieldTypeClass.getName())    
                || float.class.getName().equals(fieldTypeClass.getName())) {    
            retVal = Float.parseFloat(value.toString());    
        } else if(Double.class.getName().equals(fieldTypeClass.getName())    
                || double.class.getName().equals(fieldTypeClass.getName())) {    
            retVal = Double.parseDouble(value.toString());    
        } else {    
            retVal = value;    
        }    
        return retVal;    
    }    
    
    /**   
     * 获取指定字段名称查找在class中的对应的Field对象(包括查找父类)   
     *    
     * @param clazz 指定的class   
     * @param fieldName 字段名称   
     * @return Field对象   
     */    
    private static Field getClassField(Class clazz, String fieldName) {    
        if( Object.class.getName().equals(clazz.getName())) {    
            return null;    
        }    
        Field []declaredFields = clazz.getDeclaredFields();    
        for (Field field : declaredFields) {    
            if (field.getName().equals(fieldName)) {    
                return field;    
            }    
        }    
    
        Class superClass = clazz.getSuperclass();    
        if(superClass != null) {// 简单的递归一下    
            return getClassField(superClass, fieldName);    
        }    
        return null;    
    }      
    
       public void testGetRoot(String path) throws Exception{  
        SAXReader sax=new SAXReader();//创建一个SAXReader对象  
        File xmlFile=new File(path);//根据指定的路径创建file对象  
        Document document=sax.read(xmlFile);//获取document对象,如果文档无节点，则会抛出Exception提前结束  
        Element root=document.getRootElement();//获取根节点  
        this.getNodes(root);//从根节点开始遍历所有节点  
      
      }
   
    	public void getNodes(Element node){  
    	    System.out.println("--------------------");    	      
    	    //当前节点的名称、文本内容和属性  
    	    System.out.println("当前节点名称："+node.getName());//当前节点名称  
    	    System.out.println("当前节点的内容："+node.getTextTrim());//当前节点名称  
    	    List<Attribute> listAttr=node.attributes();//当前节点的所有属性的list  
    	    for(Attribute attr:listAttr){//遍历当前节点的所有属性  
    	        String name=attr.getName();//属性名称  
    	        String value=attr.getValue();//属性的值  
    	        System.out.println("属性名称："+name+"属性值："+value);  
    	    }     	      
    	    //递归遍历当前节点所有的子节点  
    	    List<Element> listElement=node.elements();//所有一级子节点的list  
    	    for(Element e:listElement){//遍历所有一级子节点  
    	        this.getNodes(e);//递归  
    	    }  
    	}  
		
    
    public static void main(String[] args) {        
//       String xml= XmlUtil.xmlChangeString("com/file/retrieveGoalSolutionDetail_sample_request.xml");
//       System.out.println(xml);
//    	 Map<String ,Class> mapClass=new HashMap<String,Class>();  	 
//    	 mapClass.put("arg0", RetrieveGoalSolutionDetailWSRequest.class); 
//         mapClass.put("sessionInfo", SessionInfo.class);  
//         mapClass.put("customers", Customer.class);  
////         mapClass.put("classRoom", ClassRoom.class);   
//         RetrieveGoalSolutionDetailWSRequest rs =( RetrieveGoalSolutionDetailWSRequest )xmlStrToBean(xml,mapClass);
         XmlUtil xmlUtil =new XmlUtil();
         try {
			xmlUtil.testGetRoot("D:/ziliao/retrieveGoalSolutionDetail_sample_request.xml");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


