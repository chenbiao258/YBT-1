package tool;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.RetrieveFinancialSituationDataWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.SubserviceId;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CacheIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto.LocaleCode;
import com.hsbc.swp.common.ws.dto.SessionInfo;

public class XmlTool {
	private List<Map<String,Object>> list =new ArrayList<Map<String,Object>>();
	/**
	 * 方法描述：用递归法 得到XML报文中所有的节点与值并存入map中
	 *  @param node 节点
	 */
	public void getNodes(Element node){ 
		Map<String,Object> map1 =new HashMap<String, Object>();
         map1.put(node.getName(), node.getTextTrim());
         list.add(map1);
         System.out.println(list.size());
 	    //递归遍历当前节点所有的子节点  
 	    List<Element> listElement=node.elements();//所有一级子节点的list  
 	    for(Element e:listElement){//遍历所有一级子节点  
 	        this.getNodes(e);//递归  
 	    }  	    
 	}  
	/**
	 * 方法描述：得到XML根节点
	 * @param path 文件路径
	 * @throws Exception
	 */
	 private void getRoot(String path) throws Exception{  
	        SAXReader sax=new SAXReader();//创建一个SAXReader对象  
	        File xmlFile=new File(path);//根据指定的路径创建file对象  
	        Document document=sax.read(xmlFile);//获取document对象,如果文档无节点，则会抛出Exception提前结束  
	        Element root=document.getRootElement();//获取根节点  
	        this.getNodes(root);//从根节点开始遍历所有节点  	      	            
      }	
	 
	 /**
	  * 方法描述：根据报文值组装请求参数( retrieveGoalSolutionDetail请求的参数)
	  * @param path 文件路径
	  * @return RetrieveGoalSolutionDetailWSRequest 自定义请求参数
	  * @throws Exception
	  */
	 public RetrieveGoalSolutionDetailWSRequest getGoalIdXml(String path) throws Exception{
		 this.getRoot(path);
		 RetrieveGoalSolutionDetailWSRequest retrieveGoalSolutionDetailWSRequest = new  RetrieveGoalSolutionDetailWSRequest();
		     SessionInfo sessionInfo = new SessionInfo();
		 for (Map<String, Object> map : list) {
			 
			 if(map.get("businessLine")!=null){
				 sessionInfo.setBusinessLine(map.get("businessLine").toString()); 
			 }
			 if(map.get("channelId")!=null){
				 sessionInfo.setChannelId(map.get("channelId").toString());
			 }
			 if(map.get("countryCode")!=null){
				 sessionInfo.setCountryCode(map.get("countryCode").toString());
			 }
			 if(map.get("employeeUserId")!=null){
				 sessionInfo.setEmployeeUserId(map.get("employeeUserId").toString());
			 }
			 if(map.get("groupMember")!=null){
				 sessionInfo.setGroupMember(map.get("groupMember").toString());
			 }
			 if(map.get("hubUserId")!=null){
				 sessionInfo.setHubUserId(map.get("hubUserId").toString());
			 }
			 if(map.get("hubWorkstationId")!=null){
				 sessionInfo.setHubWorkstationId(map.get("hubWorkstationId").toString());
			 }
			 retrieveGoalSolutionDetailWSRequest.setSessionInfo(sessionInfo);	
			 
			 
			 Customer customer = new Customer();
			 if(map.get("countryISOCode")!=null){
				 customer.setCountryISOCode(map.get("countryISOCode").toString());
			 }
			 //TODO		 
			 if(map.get("groupMemberCode")!=null){
				 customer.setGroupMemberCode(map.get("groupMemberCode").toString());
			 }
			 if(map.get("rolePlayerIdentificationNumber")!=null){
				 customer.setRolePlayerIdentificationNumber(map.get("rolePlayerIdentificationNumber").toString());
			 }
			 if(map.get("sourceSystemRolePlayerCode")!=null){
				 customer.setSourceSystemRolePlayerCode(map.get("sourceSystemRolePlayerCode").toString());
			 }
			 retrieveGoalSolutionDetailWSRequest.setJointCustomer(customer);
			 CacheIndicator cacheIndicator = new CacheIndicator();
			 if(map.get("requestIdentificationNumber")!=null){
				 cacheIndicator.setRequestIdentificationNumber(map.get("requestIdentificationNumber").toString());
			 }
			 GoalKey goalKey =new GoalKey();
			 if(map.get("arrangementIdentifierFinancialPlanning")!=null){
				 goalKey.setArrangementIdentifierFinancialPlanning(Long.parseLong(map.get("arrangementIdentifierFinancialPlanning").toString()));
			 }
			 if(map.get("goalSequenceNumber")!=null){
				 goalKey.setGoalSequenceNumber(Long.parseLong(map.get("goalSequenceNumber").toString()));
			 }
			 retrieveGoalSolutionDetailWSRequest.setGoalKey(goalKey);
			 
			 LocaleCode localeCode =new LocaleCode();
			 if(map.get("localeCode")!=null){
				 localeCode.setLocaleCode(map.get("localeCode").toString());
			 }
			 retrieveGoalSolutionDetailWSRequest.setLocaleCode(localeCode);
			 
			 SubserviceId subserviceId = new SubserviceId();
			 if(map.get("functionOutputCode")!=null){
				 subserviceId.setFunctionOutputCode(map.get("functionOutputCode").toString());
			 }
			 retrieveGoalSolutionDetailWSRequest.getSubserviceId().add(subserviceId);
		}
		
		 System.out.println(retrieveGoalSolutionDetailWSRequest.getSubserviceId().get(0).getFunctionOutputCode());
		
		 return retrieveGoalSolutionDetailWSRequest;		 
   }	
	 
	 /**
	  * 方法描述：根据报文值组装请求参数( retrieveFinancialSituationData请求的参数)
	  * @param path 文件路径
	  * @return RetrieveGoalSolutionDetailWSRequest 自定义请求参数
	  * @throws Exception
	  */
	  public RetrieveFinancialSituationDataWSRequest getIncom(String path) throws Exception{
		  this.getRoot(path);
		  RetrieveFinancialSituationDataWSRequest retrieveFinancialSituationDataWSRequest =new RetrieveFinancialSituationDataWSRequest();
		  SessionInfo sessionInfo = new SessionInfo();
			 if(map.get("businessLine")!=null){
				 sessionInfo.setBusinessLine(map.get("businessLine").toString()); 
			 }
			 if(map.get("channelId")!=null){
				 sessionInfo.setChannelId(map.get("channelId").toString());
			 }
			 if(map.get("countryCode")!=null){
				 sessionInfo.setCountryCode(map.get("countryCode").toString());
			 }
			 if(map.get("employeeUserId")!=null){
				 sessionInfo.setEmployeeUserId(map.get("employeeUserId").toString());
			 }
			 if(map.get("groupMember")!=null){
				 sessionInfo.setGroupMember(map.get("groupMember").toString());
			 }
			 if(map.get("hubUserId")!=null){
				 sessionInfo.setHubUserId(map.get("hubUserId").toString());
			 }
			 if(map.get("hubWorkstationId")!=null){
				 sessionInfo.setHubWorkstationId(map.get("hubWorkstationId").toString());
			 }
			 retrieveFinancialSituationDataWSRequest.setSessionInfo(sessionInfo);
		  
		  Customer customer = new Customer();
		  if(map.get("")!=null){
			  customer.s
		  }		  		  
		return null;
		}
	  public static void main(String[] args) {
		  XmlTool xmlTool = new XmlTool();
		  try {
			xmlTool.getRoot("D:/ziliao/retrieveGoalSolutionDetail_sample_request.xml");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
