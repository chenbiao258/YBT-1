
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>calculatedRiskCapacity complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculatedRiskCapacity"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="riskCapacityLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculatedRiskCapacity", propOrder = {
    "riskCapacityLevelNumber"
})
public class CalculatedRiskCapacity {

    protected int riskCapacityLevelNumber;

    /**
     * ��ȡriskCapacityLevelNumber���Ե�ֵ��
     * 
     */
    public int getRiskCapacityLevelNumber() {
        return riskCapacityLevelNumber;
    }

    /**
     * ����riskCapacityLevelNumber���Ե�ֵ��
     * 
     */
    public void setRiskCapacityLevelNumber(int value) {
        this.riskCapacityLevelNumber = value;
    }

}
