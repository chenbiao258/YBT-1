
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>selectionDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="selectionDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="employeeAdviceIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="financialPlanningProductPackageName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="financialPlanningProductPackageSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productSelectionCompleteDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="riskLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="solutionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "selectionDetail", propOrder = {
    "employeeAdviceIndicator",
    "financialPlanningProductPackageName",
    "financialPlanningProductPackageSequenceNumber",
    "productSelectionCompleteDateTime",
    "productSelectionMethodCode",
    "riskLevelNumber",
    "solutionId"
})
public class SelectionDetail {

    protected String employeeAdviceIndicator;
    protected String financialPlanningProductPackageName;
    protected String financialPlanningProductPackageSequenceNumber;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar productSelectionCompleteDateTime;
    protected String productSelectionMethodCode;
    protected Integer riskLevelNumber;
    protected String solutionId;

    /**
     * ��ȡemployeeAdviceIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeAdviceIndicator() {
        return employeeAdviceIndicator;
    }

    /**
     * ����employeeAdviceIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeAdviceIndicator(String value) {
        this.employeeAdviceIndicator = value;
    }

    /**
     * ��ȡfinancialPlanningProductPackageName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialPlanningProductPackageName() {
        return financialPlanningProductPackageName;
    }

    /**
     * ����financialPlanningProductPackageName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialPlanningProductPackageName(String value) {
        this.financialPlanningProductPackageName = value;
    }

    /**
     * ��ȡfinancialPlanningProductPackageSequenceNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialPlanningProductPackageSequenceNumber() {
        return financialPlanningProductPackageSequenceNumber;
    }

    /**
     * ����financialPlanningProductPackageSequenceNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialPlanningProductPackageSequenceNumber(String value) {
        this.financialPlanningProductPackageSequenceNumber = value;
    }

    /**
     * ��ȡproductSelectionCompleteDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getProductSelectionCompleteDateTime() {
        return productSelectionCompleteDateTime;
    }

    /**
     * ����productSelectionCompleteDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setProductSelectionCompleteDateTime(XMLGregorianCalendar value) {
        this.productSelectionCompleteDateTime = value;
    }

    /**
     * ��ȡproductSelectionMethodCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * ����productSelectionMethodCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * ��ȡriskLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskLevelNumber() {
        return riskLevelNumber;
    }

    /**
     * ����riskLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskLevelNumber(Integer value) {
        this.riskLevelNumber = value;
    }

    /**
     * ��ȡsolutionId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolutionId() {
        return solutionId;
    }

    /**
     * ����solutionId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolutionId(String value) {
        this.solutionId = value;
    }

}
