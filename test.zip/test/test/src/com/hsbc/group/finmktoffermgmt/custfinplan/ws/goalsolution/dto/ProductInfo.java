
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>productInfo complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="allocationSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assetClassGroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyAssetAllocationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyCurrentInvestmentAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyInvestmentInitialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyInvestmentMonthlyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyTargetInvestmentAmountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="investmentInitialAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="investmentMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="overiddenEligibilityIntegrityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productSubtypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="riskLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="targetInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productInfo", propOrder = {
    "allocationSequenceNumber",
    "assetClassGroupCode",
    "assetClassGroupName",
    "currencyAssetAllocationCode",
    "currencyCurrentInvestmentAmountCode",
    "currencyInvestmentInitialCode",
    "currencyInvestmentMonthlyCode",
    "currencyProductCode",
    "currencyTargetInvestmentAmountCode",
    "currentInvestmentAmount",
    "investmentInitialAmount",
    "investmentMonthlyAmount",
    "overiddenEligibilityIntegrityIndicator",
    "productName",
    "productSelectionMethodCode",
    "productSubtypeCode",
    "riskLevelCode",
    "targetInvestmentAmount"
})
public class ProductInfo {

    protected long allocationSequenceNumber;
    protected String assetClassGroupCode;
    protected String assetClassGroupName;
    protected String currencyAssetAllocationCode;
    protected String currencyCurrentInvestmentAmountCode;
    protected String currencyInvestmentInitialCode;
    protected String currencyInvestmentMonthlyCode;
    protected String currencyProductCode;
    protected String currencyTargetInvestmentAmountCode;
    protected BigDecimal currentInvestmentAmount;
    protected BigDecimal investmentInitialAmount;
    protected BigDecimal investmentMonthlyAmount;
    protected String overiddenEligibilityIntegrityIndicator;
    protected String productName;
    protected String productSelectionMethodCode;
    protected String productSubtypeCode;
    protected String riskLevelCode;
    protected BigDecimal targetInvestmentAmount;

    /**
     * ��ȡallocationSequenceNumber���Ե�ֵ��
     * 
     */
    public long getAllocationSequenceNumber() {
        return allocationSequenceNumber;
    }

    /**
     * ����allocationSequenceNumber���Ե�ֵ��
     * 
     */
    public void setAllocationSequenceNumber(long value) {
        this.allocationSequenceNumber = value;
    }

    /**
     * ��ȡassetClassGroupCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * ����assetClassGroupCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * ��ȡassetClassGroupName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupName() {
        return assetClassGroupName;
    }

    /**
     * ����assetClassGroupName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupName(String value) {
        this.assetClassGroupName = value;
    }

    /**
     * ��ȡcurrencyAssetAllocationCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAssetAllocationCode() {
        return currencyAssetAllocationCode;
    }

    /**
     * ����currencyAssetAllocationCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAssetAllocationCode(String value) {
        this.currencyAssetAllocationCode = value;
    }

    /**
     * ��ȡcurrencyCurrentInvestmentAmountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentInvestmentAmountCode() {
        return currencyCurrentInvestmentAmountCode;
    }

    /**
     * ����currencyCurrentInvestmentAmountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentInvestmentAmountCode(String value) {
        this.currencyCurrentInvestmentAmountCode = value;
    }

    /**
     * ��ȡcurrencyInvestmentInitialCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentInitialCode() {
        return currencyInvestmentInitialCode;
    }

    /**
     * ����currencyInvestmentInitialCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentInitialCode(String value) {
        this.currencyInvestmentInitialCode = value;
    }

    /**
     * ��ȡcurrencyInvestmentMonthlyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyInvestmentMonthlyCode() {
        return currencyInvestmentMonthlyCode;
    }

    /**
     * ����currencyInvestmentMonthlyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyInvestmentMonthlyCode(String value) {
        this.currencyInvestmentMonthlyCode = value;
    }

    /**
     * ��ȡcurrencyProductCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyProductCode() {
        return currencyProductCode;
    }

    /**
     * ����currencyProductCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyProductCode(String value) {
        this.currencyProductCode = value;
    }

    /**
     * ��ȡcurrencyTargetInvestmentAmountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyTargetInvestmentAmountCode() {
        return currencyTargetInvestmentAmountCode;
    }

    /**
     * ����currencyTargetInvestmentAmountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyTargetInvestmentAmountCode(String value) {
        this.currencyTargetInvestmentAmountCode = value;
    }

    /**
     * ��ȡcurrentInvestmentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentInvestmentAmount() {
        return currentInvestmentAmount;
    }

    /**
     * ����currentInvestmentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentInvestmentAmount(BigDecimal value) {
        this.currentInvestmentAmount = value;
    }

    /**
     * ��ȡinvestmentInitialAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentInitialAmount() {
        return investmentInitialAmount;
    }

    /**
     * ����investmentInitialAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentInitialAmount(BigDecimal value) {
        this.investmentInitialAmount = value;
    }

    /**
     * ��ȡinvestmentMonthlyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentMonthlyAmount() {
        return investmentMonthlyAmount;
    }

    /**
     * ����investmentMonthlyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentMonthlyAmount(BigDecimal value) {
        this.investmentMonthlyAmount = value;
    }

    /**
     * ��ȡoveriddenEligibilityIntegrityIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOveriddenEligibilityIntegrityIndicator() {
        return overiddenEligibilityIntegrityIndicator;
    }

    /**
     * ����overiddenEligibilityIntegrityIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOveriddenEligibilityIntegrityIndicator(String value) {
        this.overiddenEligibilityIntegrityIndicator = value;
    }

    /**
     * ��ȡproductName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * ����productName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * ��ȡproductSelectionMethodCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * ����productSelectionMethodCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * ��ȡproductSubtypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSubtypeCode() {
        return productSubtypeCode;
    }

    /**
     * ����productSubtypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSubtypeCode(String value) {
        this.productSubtypeCode = value;
    }

    /**
     * ��ȡriskLevelCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiskLevelCode() {
        return riskLevelCode;
    }

    /**
     * ����riskLevelCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiskLevelCode(String value) {
        this.riskLevelCode = value;
    }

    /**
     * ��ȡtargetInvestmentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTargetInvestmentAmount() {
        return targetInvestmentAmount;
    }

    /**
     * ����targetInvestmentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTargetInvestmentAmount(BigDecimal value) {
        this.targetInvestmentAmount = value;
    }

}
