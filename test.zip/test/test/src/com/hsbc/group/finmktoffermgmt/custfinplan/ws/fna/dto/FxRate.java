
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>fxRate complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="fxRate"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fxRateCurrencyFrom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fxRateCurrencyTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fxRateValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fxRate", propOrder = {
    "fxRateCurrencyFrom",
    "fxRateCurrencyTo",
    "fxRateValue"
})
public class FxRate {

    protected String fxRateCurrencyFrom;
    protected String fxRateCurrencyTo;
    protected BigDecimal fxRateValue;

    /**
     * ��ȡfxRateCurrencyFrom���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxRateCurrencyFrom() {
        return fxRateCurrencyFrom;
    }

    /**
     * ����fxRateCurrencyFrom���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxRateCurrencyFrom(String value) {
        this.fxRateCurrencyFrom = value;
    }

    /**
     * ��ȡfxRateCurrencyTo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxRateCurrencyTo() {
        return fxRateCurrencyTo;
    }

    /**
     * ����fxRateCurrencyTo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxRateCurrencyTo(String value) {
        this.fxRateCurrencyTo = value;
    }

    /**
     * ��ȡfxRateValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFxRateValue() {
        return fxRateValue;
    }

    /**
     * ����fxRateValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFxRateValue(BigDecimal value) {
        this.fxRateValue = value;
    }

}
