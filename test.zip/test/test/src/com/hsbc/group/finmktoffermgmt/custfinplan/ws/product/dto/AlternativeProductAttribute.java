
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>alternativeProductAttribute complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="alternativeProductAttribute"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="alternativeProductAttributeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="alternativeProductAttributeValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "alternativeProductAttribute", propOrder = {
    "alternativeProductAttributeCode",
    "alternativeProductAttributeValue"
})
public class AlternativeProductAttribute {

    protected String alternativeProductAttributeCode;
    protected String alternativeProductAttributeValue;

    /**
     * ��ȡalternativeProductAttributeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternativeProductAttributeCode() {
        return alternativeProductAttributeCode;
    }

    /**
     * ����alternativeProductAttributeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternativeProductAttributeCode(String value) {
        this.alternativeProductAttributeCode = value;
    }

    /**
     * ��ȡalternativeProductAttributeValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternativeProductAttributeValue() {
        return alternativeProductAttributeValue;
    }

    /**
     * ����alternativeProductAttributeValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternativeProductAttributeValue(String value) {
        this.alternativeProductAttributeValue = value;
    }

}
