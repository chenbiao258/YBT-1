
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>piqAnswerValidationInfo complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="piqAnswerValidationInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="age" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="currencyCurrentTaxIncomeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyCurrentTotalWealthCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentTaxIncomeAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="currentTotalWealthAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="financialKnowledge" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="fiscalStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="highestMarginalTaxRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="investmentPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="investmentPreferenceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="investmentPreferenceTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="investmentTerm" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="isValid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="riskProfile" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="timeHorizon" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "piqAnswerValidationInfo", propOrder = {
    "age",
    "currencyCurrentTaxIncomeCode",
    "currencyCurrentTotalWealthCode",
    "currentTaxIncomeAmount",
    "currentTotalWealthAmount",
    "financialKnowledge",
    "fiscalStatus",
    "highestMarginalTaxRate",
    "investmentPercentage",
    "investmentPreferenceCode",
    "investmentPreferenceTypeCode",
    "investmentTerm",
    "isValid",
    "riskProfile",
    "timeHorizon"
})
public class PiqAnswerValidationInfo {

    protected Long age;
    protected String currencyCurrentTaxIncomeCode;
    protected String currencyCurrentTotalWealthCode;
    protected BigDecimal currentTaxIncomeAmount;
    protected BigDecimal currentTotalWealthAmount;
    protected Long financialKnowledge;
    protected String fiscalStatus;
    protected BigDecimal highestMarginalTaxRate;
    protected BigDecimal investmentPercentage;
    protected String investmentPreferenceCode;
    protected String investmentPreferenceTypeCode;
    protected BigDecimal investmentTerm;
    protected String isValid;
    protected Long riskProfile;
    protected BigDecimal timeHorizon;

    /**
     * ��ȡage���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAge() {
        return age;
    }

    /**
     * ����age���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAge(Long value) {
        this.age = value;
    }

    /**
     * ��ȡcurrencyCurrentTaxIncomeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentTaxIncomeCode() {
        return currencyCurrentTaxIncomeCode;
    }

    /**
     * ����currencyCurrentTaxIncomeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentTaxIncomeCode(String value) {
        this.currencyCurrentTaxIncomeCode = value;
    }

    /**
     * ��ȡcurrencyCurrentTotalWealthCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCurrentTotalWealthCode() {
        return currencyCurrentTotalWealthCode;
    }

    /**
     * ����currencyCurrentTotalWealthCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCurrentTotalWealthCode(String value) {
        this.currencyCurrentTotalWealthCode = value;
    }

    /**
     * ��ȡcurrentTaxIncomeAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentTaxIncomeAmount() {
        return currentTaxIncomeAmount;
    }

    /**
     * ����currentTaxIncomeAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentTaxIncomeAmount(BigDecimal value) {
        this.currentTaxIncomeAmount = value;
    }

    /**
     * ��ȡcurrentTotalWealthAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentTotalWealthAmount() {
        return currentTotalWealthAmount;
    }

    /**
     * ����currentTotalWealthAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentTotalWealthAmount(BigDecimal value) {
        this.currentTotalWealthAmount = value;
    }

    /**
     * ��ȡfinancialKnowledge���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getFinancialKnowledge() {
        return financialKnowledge;
    }

    /**
     * ����financialKnowledge���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setFinancialKnowledge(Long value) {
        this.financialKnowledge = value;
    }

    /**
     * ��ȡfiscalStatus���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFiscalStatus() {
        return fiscalStatus;
    }

    /**
     * ����fiscalStatus���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalStatus(String value) {
        this.fiscalStatus = value;
    }

    /**
     * ��ȡhighestMarginalTaxRate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHighestMarginalTaxRate() {
        return highestMarginalTaxRate;
    }

    /**
     * ����highestMarginalTaxRate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHighestMarginalTaxRate(BigDecimal value) {
        this.highestMarginalTaxRate = value;
    }

    /**
     * ��ȡinvestmentPercentage���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentPercentage() {
        return investmentPercentage;
    }

    /**
     * ����investmentPercentage���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentPercentage(BigDecimal value) {
        this.investmentPercentage = value;
    }

    /**
     * ��ȡinvestmentPreferenceCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceCode() {
        return investmentPreferenceCode;
    }

    /**
     * ����investmentPreferenceCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceCode(String value) {
        this.investmentPreferenceCode = value;
    }

    /**
     * ��ȡinvestmentPreferenceTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentPreferenceTypeCode() {
        return investmentPreferenceTypeCode;
    }

    /**
     * ����investmentPreferenceTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentPreferenceTypeCode(String value) {
        this.investmentPreferenceTypeCode = value;
    }

    /**
     * ��ȡinvestmentTerm���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentTerm() {
        return investmentTerm;
    }

    /**
     * ����investmentTerm���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentTerm(BigDecimal value) {
        this.investmentTerm = value;
    }

    /**
     * ��ȡisValid���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsValid() {
        return isValid;
    }

    /**
     * ����isValid���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsValid(String value) {
        this.isValid = value;
    }

    /**
     * ��ȡriskProfile���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRiskProfile() {
        return riskProfile;
    }

    /**
     * ����riskProfile���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRiskProfile(Long value) {
        this.riskProfile = value;
    }

    /**
     * ��ȡtimeHorizon���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTimeHorizon() {
        return timeHorizon;
    }

    /**
     * ����timeHorizon���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTimeHorizon(BigDecimal value) {
        this.timeHorizon = value;
    }

}
