
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>calculationResultDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculationResultDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fundContributeCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundContributeTotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetYearNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="returnRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="returnShortfallAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="returnShortfallCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="savingMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="savingMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="simulateSegmentIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wealthProjectedCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wealthProjectedTotalAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculationResultDetail", propOrder = {
    "fundContributeCurrencyCode",
    "fundContributeTotalAmount",
    "goalTargetAmount",
    "goalTargetCurrencyCode",
    "goalTargetYearNumber",
    "returnRate",
    "returnShortfallAmount",
    "returnShortfallCurrencyCode",
    "savingMonthlyAmount",
    "savingMonthlyCurrencyCode",
    "simulateSegmentIndicator",
    "wealthProjectedCurrencyCode",
    "wealthProjectedTotalAmount"
})
public class CalculationResultDetail {

    protected String fundContributeCurrencyCode;
    protected BigDecimal fundContributeTotalAmount;
    protected BigDecimal goalTargetAmount;
    protected String goalTargetCurrencyCode;
    protected String goalTargetYearNumber;
    protected BigDecimal returnRate;
    protected BigDecimal returnShortfallAmount;
    protected String returnShortfallCurrencyCode;
    protected BigDecimal savingMonthlyAmount;
    protected String savingMonthlyCurrencyCode;
    protected String simulateSegmentIndicator;
    protected String wealthProjectedCurrencyCode;
    protected BigDecimal wealthProjectedTotalAmount;

    /**
     * ��ȡfundContributeCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundContributeCurrencyCode() {
        return fundContributeCurrencyCode;
    }

    /**
     * ����fundContributeCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundContributeCurrencyCode(String value) {
        this.fundContributeCurrencyCode = value;
    }

    /**
     * ��ȡfundContributeTotalAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundContributeTotalAmount() {
        return fundContributeTotalAmount;
    }

    /**
     * ����fundContributeTotalAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundContributeTotalAmount(BigDecimal value) {
        this.fundContributeTotalAmount = value;
    }

    /**
     * ��ȡgoalTargetAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoalTargetAmount() {
        return goalTargetAmount;
    }

    /**
     * ����goalTargetAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoalTargetAmount(BigDecimal value) {
        this.goalTargetAmount = value;
    }

    /**
     * ��ȡgoalTargetCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetCurrencyCode() {
        return goalTargetCurrencyCode;
    }

    /**
     * ����goalTargetCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetCurrencyCode(String value) {
        this.goalTargetCurrencyCode = value;
    }

    /**
     * ��ȡgoalTargetYearNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetYearNumber() {
        return goalTargetYearNumber;
    }

    /**
     * ����goalTargetYearNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetYearNumber(String value) {
        this.goalTargetYearNumber = value;
    }

    /**
     * ��ȡreturnRate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getReturnRate() {
        return returnRate;
    }

    /**
     * ����returnRate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setReturnRate(BigDecimal value) {
        this.returnRate = value;
    }

    /**
     * ��ȡreturnShortfallAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getReturnShortfallAmount() {
        return returnShortfallAmount;
    }

    /**
     * ����returnShortfallAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setReturnShortfallAmount(BigDecimal value) {
        this.returnShortfallAmount = value;
    }

    /**
     * ��ȡreturnShortfallCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnShortfallCurrencyCode() {
        return returnShortfallCurrencyCode;
    }

    /**
     * ����returnShortfallCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnShortfallCurrencyCode(String value) {
        this.returnShortfallCurrencyCode = value;
    }

    /**
     * ��ȡsavingMonthlyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSavingMonthlyAmount() {
        return savingMonthlyAmount;
    }

    /**
     * ����savingMonthlyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSavingMonthlyAmount(BigDecimal value) {
        this.savingMonthlyAmount = value;
    }

    /**
     * ��ȡsavingMonthlyCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSavingMonthlyCurrencyCode() {
        return savingMonthlyCurrencyCode;
    }

    /**
     * ����savingMonthlyCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSavingMonthlyCurrencyCode(String value) {
        this.savingMonthlyCurrencyCode = value;
    }

    /**
     * ��ȡsimulateSegmentIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSimulateSegmentIndicator() {
        return simulateSegmentIndicator;
    }

    /**
     * ����simulateSegmentIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSimulateSegmentIndicator(String value) {
        this.simulateSegmentIndicator = value;
    }

    /**
     * ��ȡwealthProjectedCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWealthProjectedCurrencyCode() {
        return wealthProjectedCurrencyCode;
    }

    /**
     * ����wealthProjectedCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWealthProjectedCurrencyCode(String value) {
        this.wealthProjectedCurrencyCode = value;
    }

    /**
     * ��ȡwealthProjectedTotalAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWealthProjectedTotalAmount() {
        return wealthProjectedTotalAmount;
    }

    /**
     * ����wealthProjectedTotalAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWealthProjectedTotalAmount(BigDecimal value) {
        this.wealthProjectedTotalAmount = value;
    }

}
