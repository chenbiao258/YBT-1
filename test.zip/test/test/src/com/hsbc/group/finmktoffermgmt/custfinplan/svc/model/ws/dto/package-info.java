@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.ws.model.svc.custfinplan.finmktoffermgmt.group.hsbc.com/")
package com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto;
