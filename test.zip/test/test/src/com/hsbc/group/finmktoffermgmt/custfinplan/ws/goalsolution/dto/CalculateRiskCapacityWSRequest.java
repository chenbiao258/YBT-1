
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CalculateRiskCapacity;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>calculateRiskCapacityWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacityWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="calculateRiskCapacity" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateRiskCapacity" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacityWSRequest", propOrder = {
    "calculateRiskCapacity"
})
public class CalculateRiskCapacityWSRequest
    extends WebServiceRequest
{

    protected CalculateRiskCapacity calculateRiskCapacity;

    /**
     * ��ȡcalculateRiskCapacity���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CalculateRiskCapacity }
     *     
     */
    public CalculateRiskCapacity getCalculateRiskCapacity() {
        return calculateRiskCapacity;
    }

    /**
     * ����calculateRiskCapacity���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateRiskCapacity }
     *     
     */
    public void setCalculateRiskCapacity(CalculateRiskCapacity value) {
        this.calculateRiskCapacity = value;
    }

}
