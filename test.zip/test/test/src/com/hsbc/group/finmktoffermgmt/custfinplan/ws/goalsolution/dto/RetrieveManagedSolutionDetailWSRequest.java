
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ProductSelectionWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.PaginationDetail;


/**
 * <p>retrieveManagedSolutionDetailWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveManagedSolutionDetailWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productSelectionWSRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="paginationDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}paginationDetail" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveManagedSolutionDetailWSRequest", propOrder = {
    "paginationDetail"
})
public class RetrieveManagedSolutionDetailWSRequest
    extends ProductSelectionWSRequest
{

    protected PaginationDetail paginationDetail;

    /**
     * ��ȡpaginationDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PaginationDetail }
     *     
     */
    public PaginationDetail getPaginationDetail() {
        return paginationDetail;
    }

    /**
     * ����paginationDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PaginationDetail }
     *     
     */
    public void setPaginationDetail(PaginationDetail value) {
        this.paginationDetail = value;
    }

}
