
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>financialSituationDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="financialSituationDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="additionalSituation" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalSituation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assets" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assets" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="expense" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}expense" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="income" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}income" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investment" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="liability" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}liability" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="marginalIncomeTaxRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="numberOfDependents" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="reviewDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "financialSituationDetail", propOrder = {
    "additionalSituation",
    "assets",
    "expense",
    "income",
    "investment",
    "liability",
    "marginalIncomeTaxRate",
    "numberOfDependents",
    "reviewDateTime"
})
public class FinancialSituationDetail {

    @XmlElement(nillable = true)
    protected List<AdditionalSituation> additionalSituation;
    @XmlElement(nillable = true)
    protected List<Assets> assets;
    @XmlElement(nillable = true)
    protected List<Expense> expense;
    @XmlElement(nillable = true)
    protected List<Income> income;
    @XmlElement(nillable = true)
    protected List<Investment> investment;
    @XmlElement(nillable = true)
    protected List<Liability> liability;
    protected BigDecimal marginalIncomeTaxRate;
    protected Integer numberOfDependents;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reviewDateTime;

    /**
     * Gets the value of the additionalSituation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalSituation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalSituation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalSituation }
     * 
     * 
     */
    public List<AdditionalSituation> getAdditionalSituation() {
        if (additionalSituation == null) {
            additionalSituation = new ArrayList<AdditionalSituation>();
        }
        return this.additionalSituation;
    }

    /**
     * Gets the value of the assets property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assets property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssets().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Assets }
     * 
     * 
     */
    public List<Assets> getAssets() {
        if (assets == null) {
            assets = new ArrayList<Assets>();
        }
        return this.assets;
    }

    /**
     * Gets the value of the expense property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the expense property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExpense().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Expense }
     * 
     * 
     */
    public List<Expense> getExpense() {
        if (expense == null) {
            expense = new ArrayList<Expense>();
        }
        return this.expense;
    }

    /**
     * Gets the value of the income property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the income property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Income }
     * 
     * 
     */
    public List<Income> getIncome() {
        if (income == null) {
            income = new ArrayList<Income>();
        }
        return this.income;
    }

    /**
     * Gets the value of the investment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Investment }
     * 
     * 
     */
    public List<Investment> getInvestment() {
        if (investment == null) {
            investment = new ArrayList<Investment>();
        }
        return this.investment;
    }

    /**
     * Gets the value of the liability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the liability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLiability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Liability }
     * 
     * 
     */
    public List<Liability> getLiability() {
        if (liability == null) {
            liability = new ArrayList<Liability>();
        }
        return this.liability;
    }

    /**
     * ��ȡmarginalIncomeTaxRate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMarginalIncomeTaxRate() {
        return marginalIncomeTaxRate;
    }

    /**
     * ����marginalIncomeTaxRate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMarginalIncomeTaxRate(BigDecimal value) {
        this.marginalIncomeTaxRate = value;
    }

    /**
     * ��ȡnumberOfDependents���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfDependents() {
        return numberOfDependents;
    }

    /**
     * ����numberOfDependents���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfDependents(Integer value) {
        this.numberOfDependents = value;
    }

    /**
     * ��ȡreviewDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReviewDateTime() {
        return reviewDateTime;
    }

    /**
     * ����reviewDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReviewDateTime(XMLGregorianCalendar value) {
        this.reviewDateTime = value;
    }

}
