
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSummaryListWSResponse;


/**
 * <p>retrieveGoalSummaryListResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveGoalSummaryListResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="return" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}retrieveGoalSummaryListWSResponse" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveGoalSummaryListResponse", propOrder = {
    "_return"
})
public class RetrieveGoalSummaryListResponse {

    @XmlElement(name = "return")
    protected RetrieveGoalSummaryListWSResponse _return;

    /**
     * ��ȡreturn���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link RetrieveGoalSummaryListWSResponse }
     *     
     */
    public RetrieveGoalSummaryListWSResponse getReturn() {
        return _return;
    }

    /**
     * ����return���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveGoalSummaryListWSResponse }
     *     
     */
    public void setReturn(RetrieveGoalSummaryListWSResponse value) {
        this._return = value;
    }

}
