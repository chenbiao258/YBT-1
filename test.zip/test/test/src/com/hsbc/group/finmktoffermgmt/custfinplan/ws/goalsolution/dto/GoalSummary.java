
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto.FinancialGoal;
import com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto.FundingDetails;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.AdditionalAmount;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.AdditionalInformation;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.ProductAssetAllocationSnapshot;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.GoalLocalFields;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CalculationResultDetail;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.RiskProfile;


/**
 * <p>goalSummary complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="goalSummary"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="additionalAmount" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalAmount" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="additionalInformation" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalInformation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="calculationResultDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculationResultDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="financialGoal" type="{http://dto.ws.model.svc.custfinplan.finmktoffermgmt.group.hsbc.com/}financialGoal" minOccurs="0"/&gt;
 *         &lt;element name="fundingDetails" type="{http://dto.ws.model.svc.custfinplan.finmktoffermgmt.group.hsbc.com/}fundingDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalLocalFields" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalLocalFields" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="multipleAdviceStyleDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}multipleAdviceStyleDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productAssetAllocationSnapshot" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAssetAllocationSnapshot" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="riskProfile" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}riskProfile" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="suitability" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}suitability" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalSummary", propOrder = {
    "additionalAmount",
    "additionalInformation",
    "calculationResultDetail",
    "financialGoal",
    "fundingDetails",
    "goalLocalFields",
    "multipleAdviceStyleDetails",
    "productAssetAllocationSnapshot",
    "riskProfile",
    "suitability"
})
public class GoalSummary {

    @XmlElement(nillable = true)
    protected List<AdditionalAmount> additionalAmount;
    @XmlElement(nillable = true)
    protected List<AdditionalInformation> additionalInformation;
    @XmlElement(nillable = true)
    protected List<CalculationResultDetail> calculationResultDetail;
    protected FinancialGoal financialGoal;
    @XmlElement(nillable = true)
    protected List<FundingDetails> fundingDetails;
    @XmlElement(nillable = true)
    protected List<GoalLocalFields> goalLocalFields;
    @XmlElement(nillable = true)
    protected List<MultipleAdviceStyleDetails> multipleAdviceStyleDetails;
    @XmlElement(nillable = true)
    protected List<ProductAssetAllocationSnapshot> productAssetAllocationSnapshot;
    @XmlElement(nillable = true)
    protected List<RiskProfile> riskProfile;
    @XmlElement(nillable = true)
    protected List<Suitability> suitability;

    /**
     * Gets the value of the additionalAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmount }
     * 
     * 
     */
    public List<AdditionalAmount> getAdditionalAmount() {
        if (additionalAmount == null) {
            additionalAmount = new ArrayList<AdditionalAmount>();
        }
        return this.additionalAmount;
    }

    /**
     * Gets the value of the additionalInformation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInformation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInformation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInformation }
     * 
     * 
     */
    public List<AdditionalInformation> getAdditionalInformation() {
        if (additionalInformation == null) {
            additionalInformation = new ArrayList<AdditionalInformation>();
        }
        return this.additionalInformation;
    }

    /**
     * Gets the value of the calculationResultDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the calculationResultDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCalculationResultDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CalculationResultDetail }
     * 
     * 
     */
    public List<CalculationResultDetail> getCalculationResultDetail() {
        if (calculationResultDetail == null) {
            calculationResultDetail = new ArrayList<CalculationResultDetail>();
        }
        return this.calculationResultDetail;
    }

    /**
     * ��ȡfinancialGoal���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link FinancialGoal }
     *     
     */
    public FinancialGoal getFinancialGoal() {
        return financialGoal;
    }

    /**
     * ����financialGoal���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialGoal }
     *     
     */
    public void setFinancialGoal(FinancialGoal value) {
        this.financialGoal = value;
    }

    /**
     * Gets the value of the fundingDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fundingDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFundingDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FundingDetails }
     * 
     * 
     */
    public List<FundingDetails> getFundingDetails() {
        if (fundingDetails == null) {
            fundingDetails = new ArrayList<FundingDetails>();
        }
        return this.fundingDetails;
    }

    /**
     * Gets the value of the goalLocalFields property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLocalFields property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLocalFields().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalLocalFields }
     * 
     * 
     */
    public List<GoalLocalFields> getGoalLocalFields() {
        if (goalLocalFields == null) {
            goalLocalFields = new ArrayList<GoalLocalFields>();
        }
        return this.goalLocalFields;
    }

    /**
     * Gets the value of the multipleAdviceStyleDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the multipleAdviceStyleDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMultipleAdviceStyleDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MultipleAdviceStyleDetails }
     * 
     * 
     */
    public List<MultipleAdviceStyleDetails> getMultipleAdviceStyleDetails() {
        if (multipleAdviceStyleDetails == null) {
            multipleAdviceStyleDetails = new ArrayList<MultipleAdviceStyleDetails>();
        }
        return this.multipleAdviceStyleDetails;
    }

    /**
     * Gets the value of the productAssetAllocationSnapshot property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAssetAllocationSnapshot property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAssetAllocationSnapshot().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAssetAllocationSnapshot }
     * 
     * 
     */
    public List<ProductAssetAllocationSnapshot> getProductAssetAllocationSnapshot() {
        if (productAssetAllocationSnapshot == null) {
            productAssetAllocationSnapshot = new ArrayList<ProductAssetAllocationSnapshot>();
        }
        return this.productAssetAllocationSnapshot;
    }

    /**
     * Gets the value of the riskProfile property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the riskProfile property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRiskProfile().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RiskProfile }
     * 
     * 
     */
    public List<RiskProfile> getRiskProfile() {
        if (riskProfile == null) {
            riskProfile = new ArrayList<RiskProfile>();
        }
        return this.riskProfile;
    }

    /**
     * Gets the value of the suitability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the suitability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSuitability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Suitability }
     * 
     * 
     */
    public List<Suitability> getSuitability() {
        if (suitability == null) {
            suitability = new ArrayList<Suitability>();
        }
        return this.suitability;
    }

}
