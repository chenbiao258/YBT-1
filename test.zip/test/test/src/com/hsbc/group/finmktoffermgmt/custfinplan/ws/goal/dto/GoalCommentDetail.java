
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>goalCommentDetail complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="goalCommentDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/&gt;
 *         &lt;element name="goalLevelCommentActionList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}commentAction" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalLevelCommentList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalLevelReqCommentList" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}requestComment" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalCommentDetail", propOrder = {
    "goalKey",
    "goalLevelCommentActionList",
    "goalLevelCommentList",
    "goalLevelReqCommentList"
})
public class GoalCommentDetail {

    protected GoalKey goalKey;
    @XmlElement(nillable = true)
    protected List<CommentAction> goalLevelCommentActionList;
    @XmlElement(nillable = true)
    protected List<Comment> goalLevelCommentList;
    @XmlElement(nillable = true)
    protected List<RequestComment> goalLevelReqCommentList;

    /**
     * ��ȡgoalKey���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * ����goalKey���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the goalLevelCommentActionList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelCommentActionList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelCommentActionList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommentAction }
     * 
     * 
     */
    public List<CommentAction> getGoalLevelCommentActionList() {
        if (goalLevelCommentActionList == null) {
            goalLevelCommentActionList = new ArrayList<CommentAction>();
        }
        return this.goalLevelCommentActionList;
    }

    /**
     * Gets the value of the goalLevelCommentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelCommentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelCommentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getGoalLevelCommentList() {
        if (goalLevelCommentList == null) {
            goalLevelCommentList = new ArrayList<Comment>();
        }
        return this.goalLevelCommentList;
    }

    /**
     * Gets the value of the goalLevelReqCommentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLevelReqCommentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLevelReqCommentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestComment }
     * 
     * 
     */
    public List<RequestComment> getGoalLevelReqCommentList() {
        if (goalLevelReqCommentList == null) {
            goalLevelReqCommentList = new ArrayList<RequestComment>();
        }
        return this.goalLevelReqCommentList;
    }

}
