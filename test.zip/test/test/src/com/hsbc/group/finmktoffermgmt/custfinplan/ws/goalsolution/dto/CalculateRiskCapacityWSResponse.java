
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CalculatedRiskCapacity;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>calculateRiskCapacityWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacityWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="calculatedRiskCapacity" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculatedRiskCapacity" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacityWSResponse", propOrder = {
    "calculatedRiskCapacity"
})
public class CalculateRiskCapacityWSResponse
    extends WebServiceResponse
{

    protected CalculatedRiskCapacity calculatedRiskCapacity;

    /**
     * ��ȡcalculatedRiskCapacity���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CalculatedRiskCapacity }
     *     
     */
    public CalculatedRiskCapacity getCalculatedRiskCapacity() {
        return calculatedRiskCapacity;
    }

    /**
     * ����calculatedRiskCapacity���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CalculatedRiskCapacity }
     *     
     */
    public void setCalculatedRiskCapacity(CalculatedRiskCapacity value) {
        this.calculatedRiskCapacity = value;
    }

}
