
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>currentPortfolioAllocationList complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="currentPortfolioAllocationList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="currentPortfolioAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currentPortfolioAllocation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "currentPortfolioAllocationList", propOrder = {
    "currentPortfolioAllocation",
    "portfolioTypeCode"
})
public class CurrentPortfolioAllocationList {

    @XmlElement(nillable = true)
    protected List<CurrentPortfolioAllocation> currentPortfolioAllocation;
    protected String portfolioTypeCode;

    /**
     * Gets the value of the currentPortfolioAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the currentPortfolioAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCurrentPortfolioAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentPortfolioAllocation }
     * 
     * 
     */
    public List<CurrentPortfolioAllocation> getCurrentPortfolioAllocation() {
        if (currentPortfolioAllocation == null) {
            currentPortfolioAllocation = new ArrayList<CurrentPortfolioAllocation>();
        }
        return this.currentPortfolioAllocation;
    }

    /**
     * ��ȡportfolioTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioTypeCode() {
        return portfolioTypeCode;
    }

    /**
     * ����portfolioTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioTypeCode(String value) {
        this.portfolioTypeCode = value;
    }

}
