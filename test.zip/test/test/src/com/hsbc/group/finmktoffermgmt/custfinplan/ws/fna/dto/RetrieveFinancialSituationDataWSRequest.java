
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.RequestComment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.RequestInvestorIndicator;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>retrieveFinancialSituationDataWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveFinancialSituationDataWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="requestComment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}requestComment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="requestInvestorIndicator" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}requestInvestorIndicator" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveFinancialSituationDataWSRequest", propOrder = {
    "customers",
    "jointCustomer",
    "requestComment",
    "requestInvestorIndicator"
})
public class RetrieveFinancialSituationDataWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Customer> customers;
    protected Customer jointCustomer;
    @XmlElement(nillable = true)
    protected List<RequestComment> requestComment;
    @XmlElement(nillable = true)
    protected List<RequestInvestorIndicator> requestInvestorIndicator;

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * ��ȡjointCustomer���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * ����jointCustomer���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the requestComment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestComment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestComment }
     * 
     * 
     */
    public List<RequestComment> getRequestComment() {
        if (requestComment == null) {
            requestComment = new ArrayList<RequestComment>();
        }
        return this.requestComment;
    }

    /**
     * Gets the value of the requestInvestorIndicator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestInvestorIndicator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestInvestorIndicator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestInvestorIndicator }
     * 
     * 
     */
    public List<RequestInvestorIndicator> getRequestInvestorIndicator() {
        if (requestInvestorIndicator == null) {
            requestInvestorIndicator = new ArrayList<RequestInvestorIndicator>();
        }
        return this.requestInvestorIndicator;
    }

}
