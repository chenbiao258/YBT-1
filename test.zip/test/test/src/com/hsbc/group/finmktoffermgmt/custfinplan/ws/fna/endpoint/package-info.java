@javax.xml.bind.annotation.XmlSchema(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.endpoint;
