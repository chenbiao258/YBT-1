
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>eligibilityResult complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="eligibilityResult"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="eligibilityIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eligibilityOverrideIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eligibilityRuleCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eligibilityTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eligibilityResult", propOrder = {
    "eligibilityIndicator",
    "eligibilityOverrideIndicator",
    "eligibilityRuleCode",
    "eligibilityTypeCode",
    "reasonCode"
})
public class EligibilityResult {

    protected String eligibilityIndicator;
    protected String eligibilityOverrideIndicator;
    protected String eligibilityRuleCode;
    protected String eligibilityTypeCode;
    protected String reasonCode;

    /**
     * ��ȡeligibilityIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityIndicator() {
        return eligibilityIndicator;
    }

    /**
     * ����eligibilityIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityIndicator(String value) {
        this.eligibilityIndicator = value;
    }

    /**
     * ��ȡeligibilityOverrideIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityOverrideIndicator() {
        return eligibilityOverrideIndicator;
    }

    /**
     * ����eligibilityOverrideIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityOverrideIndicator(String value) {
        this.eligibilityOverrideIndicator = value;
    }

    /**
     * ��ȡeligibilityRuleCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityRuleCode() {
        return eligibilityRuleCode;
    }

    /**
     * ����eligibilityRuleCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityRuleCode(String value) {
        this.eligibilityRuleCode = value;
    }

    /**
     * ��ȡeligibilityTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityTypeCode() {
        return eligibilityTypeCode;
    }

    /**
     * ����eligibilityTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityTypeCode(String value) {
        this.eligibilityTypeCode = value;
    }

    /**
     * ��ȡreasonCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * ����reasonCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

}
