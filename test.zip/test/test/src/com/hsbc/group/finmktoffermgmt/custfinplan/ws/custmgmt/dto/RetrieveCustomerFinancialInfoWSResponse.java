
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.custmgmt.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.AdditionalInformation;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>retrieveCustomerFinancialInfoWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveCustomerFinancialInfoWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="responseBankNeedInfo" type="{http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}responseBankNeedDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="responseGoalsNoteDetail" type="{http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}responseGoalsNoteDetail" minOccurs="0"/&gt;
 *         &lt;element name="planInfo" type="{http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}planInfo" minOccurs="0"/&gt;
 *         &lt;element name="emergencyFund" type="{http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}emergencyFund" minOccurs="0"/&gt;
 *         &lt;element name="additionalInformation" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalInformation" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveCustomerFinancialInfoWSResponse", propOrder = {
    "responseBankNeedInfo",
    "responseGoalsNoteDetail",
    "planInfo",
    "emergencyFund",
    "additionalInformation"
})
public class RetrieveCustomerFinancialInfoWSResponse
    extends WebServiceResponse
{

    @XmlElement(nillable = true)
    protected List<ResponseBankNeedDetail> responseBankNeedInfo;
    protected ResponseGoalsNoteDetail responseGoalsNoteDetail;
    protected PlanInfo planInfo;
    protected EmergencyFund emergencyFund;
    @XmlElement(nillable = true)
    protected List<AdditionalInformation> additionalInformation;

    /**
     * Gets the value of the responseBankNeedInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the responseBankNeedInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResponseBankNeedInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ResponseBankNeedDetail }
     * 
     * 
     */
    public List<ResponseBankNeedDetail> getResponseBankNeedInfo() {
        if (responseBankNeedInfo == null) {
            responseBankNeedInfo = new ArrayList<ResponseBankNeedDetail>();
        }
        return this.responseBankNeedInfo;
    }

    /**
     * ��ȡresponseGoalsNoteDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ResponseGoalsNoteDetail }
     *     
     */
    public ResponseGoalsNoteDetail getResponseGoalsNoteDetail() {
        return responseGoalsNoteDetail;
    }

    /**
     * ����responseGoalsNoteDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseGoalsNoteDetail }
     *     
     */
    public void setResponseGoalsNoteDetail(ResponseGoalsNoteDetail value) {
        this.responseGoalsNoteDetail = value;
    }

    /**
     * ��ȡplanInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PlanInfo }
     *     
     */
    public PlanInfo getPlanInfo() {
        return planInfo;
    }

    /**
     * ����planInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PlanInfo }
     *     
     */
    public void setPlanInfo(PlanInfo value) {
        this.planInfo = value;
    }

    /**
     * ��ȡemergencyFund���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link EmergencyFund }
     *     
     */
    public EmergencyFund getEmergencyFund() {
        return emergencyFund;
    }

    /**
     * ����emergencyFund���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link EmergencyFund }
     *     
     */
    public void setEmergencyFund(EmergencyFund value) {
        this.emergencyFund = value;
    }

    /**
     * Gets the value of the additionalInformation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInformation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInformation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInformation }
     * 
     * 
     */
    public List<AdditionalInformation> getAdditionalInformation() {
        if (additionalInformation == null) {
            additionalInformation = new ArrayList<AdditionalInformation>();
        }
        return this.additionalInformation;
    }

}
