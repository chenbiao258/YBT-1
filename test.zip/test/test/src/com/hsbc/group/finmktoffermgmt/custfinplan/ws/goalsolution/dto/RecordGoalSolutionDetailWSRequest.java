
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.InvestorIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.Comment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.CommentAction;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalAttribute;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalLocalFields;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.CoreReserveArea;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.LocalFieldsArea;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.preference.dto.InvestmentAppropriateness;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.CacheIndicator;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.PackageKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto.SelectedProduct;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.simulator.dto.LeadId;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto.TaxOptimizationDetails;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>recordGoalSolutionDetailWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="recordGoalSolutionDetailWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="actualPortfolioAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}actualPortfolioAllocation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="affordability" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordability" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="affordabilityValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordabilityValidation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="alternativeProduct" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}alternativeProduct" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assetConcentration" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentration" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assetConcentrationValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentrationValidation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="cacheDataToken" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="cacheIndicator" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}cacheIndicator" minOccurs="0"/&gt;
 *         &lt;element name="comment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="commentAction" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}commentAction" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="context"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="entry" maxOccurs="999" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
 *                             &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="controlAdviceJourney" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}controlAdviceJourney" minOccurs="0"/&gt;
 *         &lt;element name="coreReserveArea" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}coreReserveArea" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="currentPortfolioAllocation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currentPortfolioAllocation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="declaration" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}declaration" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="existingHolding" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}existingHolding" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalAttribute" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/&gt;
 *         &lt;element name="goalLocalFields" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalLocalFields" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investmentAppropriateness" type="{http://dto.preference.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investmentAppropriateness" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investorIndicator" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investorIndicator" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="leadId" type="{http://dto.simulator.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}leadId" minOccurs="0"/&gt;
 *         &lt;element name="localFieldsArea" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}localFieldsArea" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="modelPortfolioAssetClassAllocationList" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}modelPortfolioAssetClassAllocationList" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="multipleAdviceStyleDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}multipleAdviceStyleDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="needEvaluation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}needEvaluation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="notes" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}notes" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="optOutDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}optOutDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="packageKey" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}packageKey" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="piqAnswerValidationInfo" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}piqAnswerValidationInfo" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="piqQuestAndAnsDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}piqQuestAndAnsDetails" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioCalculationResult" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioCalculationResult" minOccurs="0"/&gt;
 *         &lt;element name="productList" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productList" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productTable" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productTable" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="purposeBuyingProduct" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}purposeBuyingProduct" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="selectedProduct" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}selectedProduct" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="staffAdviseSeg" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}staffAdviseSeg" minOccurs="0"/&gt;
 *         &lt;element name="subserviceId" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}subserviceId" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="suitability" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}suitability" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="taxOptimizationDetails" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}taxOptimizationDetails" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "recordGoalSolutionDetailWSRequest", propOrder = {
    "actualPortfolioAllocation",
    "affordability",
    "affordabilityValidation",
    "alternativeProduct",
    "assetConcentration",
    "assetConcentrationValidation",
    "cacheDataToken",
    "cacheIndicator",
    "comment",
    "commentAction",
    "context",
    "controlAdviceJourney",
    "coreReserveArea",
    "currentPortfolioAllocation",
    "customers",
    "declaration",
    "existingHolding",
    "goalAttribute",
    "goalKey",
    "goalLocalFields",
    "investmentAppropriateness",
    "investorIndicator",
    "jointCustomer",
    "leadId",
    "localFieldsArea",
    "modelPortfolioAssetClassAllocationList",
    "multipleAdviceStyleDetails",
    "needEvaluation",
    "notes",
    "optOutDetails",
    "packageKey",
    "piqAnswerValidationInfo",
    "piqQuestAndAnsDetails",
    "portfolioCalculationResult",
    "productList",
    "productTable",
    "purposeBuyingProduct",
    "selectedProduct",
    "staffAdviseSeg",
    "subserviceId",
    "suitability",
    "taxOptimizationDetails"
})
public class RecordGoalSolutionDetailWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<ActualPortfolioAllocation> actualPortfolioAllocation;
    @XmlElement(nillable = true)
    protected List<Affordability> affordability;
    @XmlElement(nillable = true)
    protected List<AffordabilityValidation> affordabilityValidation;
    @XmlElement(nillable = true)
    protected List<AlternativeProduct> alternativeProduct;
    @XmlElement(nillable = true)
    protected List<AssetConcentration> assetConcentration;
    @XmlElement(nillable = true)
    protected List<AssetConcentrationValidation> assetConcentrationValidation;
    @XmlElement(nillable = true)
    protected List<String> cacheDataToken;
    protected CacheIndicator cacheIndicator;
    @XmlElement(nillable = true)
    protected List<Comment> comment;
    @XmlElement(nillable = true)
    protected List<CommentAction> commentAction;
    @XmlElement(required = true)
    protected RecordGoalSolutionDetailWSRequest.Context context;
    protected ControlAdviceJourney controlAdviceJourney;
    @XmlElement(nillable = true)
    protected List<CoreReserveArea> coreReserveArea;
    @XmlElement(nillable = true)
    protected List<CurrentPortfolioAllocation> currentPortfolioAllocation;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<Declaration> declaration;
    @XmlElement(nillable = true)
    protected List<ExistingHolding> existingHolding;
    @XmlElement(nillable = true)
    protected List<GoalAttribute> goalAttribute;
    protected GoalKey goalKey;
    @XmlElement(nillable = true)
    protected List<GoalLocalFields> goalLocalFields;
    @XmlElement(nillable = true)
    protected List<InvestmentAppropriateness> investmentAppropriateness;
    @XmlElement(nillable = true)
    protected List<InvestorIndicator> investorIndicator;
    protected Customer jointCustomer;
    protected LeadId leadId;
    @XmlElement(nillable = true)
    protected List<LocalFieldsArea> localFieldsArea;
    @XmlElement(nillable = true)
    protected List<ModelPortfolioAssetClassAllocationList> modelPortfolioAssetClassAllocationList;
    @XmlElement(nillable = true)
    protected List<MultipleAdviceStyleDetails> multipleAdviceStyleDetails;
    @XmlElement(nillable = true)
    protected List<NeedEvaluation> needEvaluation;
    @XmlElement(nillable = true)
    protected List<Notes> notes;
    @XmlElement(nillable = true)
    protected List<OptOutDetails> optOutDetails;
    @XmlElement(nillable = true)
    protected List<PackageKey> packageKey;
    @XmlElement(nillable = true)
    protected List<PiqAnswerValidationInfo> piqAnswerValidationInfo;
    @XmlElement(nillable = true)
    protected List<PiqQuestAndAnsDetails> piqQuestAndAnsDetails;
    protected PortfolioCalculationResult portfolioCalculationResult;
    @XmlElement(nillable = true)
    protected List<ProductList> productList;
    @XmlElement(nillable = true)
    protected List<ProductTable> productTable;
    @XmlElement(nillable = true)
    protected List<PurposeBuyingProduct> purposeBuyingProduct;
    @XmlElement(nillable = true)
    protected List<SelectedProduct> selectedProduct;
    protected StaffAdviseSeg staffAdviseSeg;
    @XmlElement(nillable = true)
    protected List<SubserviceId> subserviceId;
    @XmlElement(nillable = true)
    protected List<Suitability> suitability;
    @XmlElement(nillable = true)
    protected List<TaxOptimizationDetails> taxOptimizationDetails;

    /**
     * Gets the value of the actualPortfolioAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actualPortfolioAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActualPortfolioAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActualPortfolioAllocation }
     * 
     * 
     */
    public List<ActualPortfolioAllocation> getActualPortfolioAllocation() {
        if (actualPortfolioAllocation == null) {
            actualPortfolioAllocation = new ArrayList<ActualPortfolioAllocation>();
        }
        return this.actualPortfolioAllocation;
    }

    /**
     * Gets the value of the affordability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Affordability }
     * 
     * 
     */
    public List<Affordability> getAffordability() {
        if (affordability == null) {
            affordability = new ArrayList<Affordability>();
        }
        return this.affordability;
    }

    /**
     * Gets the value of the affordabilityValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordabilityValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordabilityValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AffordabilityValidation }
     * 
     * 
     */
    public List<AffordabilityValidation> getAffordabilityValidation() {
        if (affordabilityValidation == null) {
            affordabilityValidation = new ArrayList<AffordabilityValidation>();
        }
        return this.affordabilityValidation;
    }

    /**
     * Gets the value of the alternativeProduct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the alternativeProduct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAlternativeProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AlternativeProduct }
     * 
     * 
     */
    public List<AlternativeProduct> getAlternativeProduct() {
        if (alternativeProduct == null) {
            alternativeProduct = new ArrayList<AlternativeProduct>();
        }
        return this.alternativeProduct;
    }

    /**
     * Gets the value of the assetConcentration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentration }
     * 
     * 
     */
    public List<AssetConcentration> getAssetConcentration() {
        if (assetConcentration == null) {
            assetConcentration = new ArrayList<AssetConcentration>();
        }
        return this.assetConcentration;
    }

    /**
     * Gets the value of the assetConcentrationValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentrationValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentrationValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentrationValidation }
     * 
     * 
     */
    public List<AssetConcentrationValidation> getAssetConcentrationValidation() {
        if (assetConcentrationValidation == null) {
            assetConcentrationValidation = new ArrayList<AssetConcentrationValidation>();
        }
        return this.assetConcentrationValidation;
    }

    /**
     * Gets the value of the cacheDataToken property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cacheDataToken property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCacheDataToken().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCacheDataToken() {
        if (cacheDataToken == null) {
            cacheDataToken = new ArrayList<String>();
        }
        return this.cacheDataToken;
    }

    /**
     * ��ȡcacheIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CacheIndicator }
     *     
     */
    public CacheIndicator getCacheIndicator() {
        return cacheIndicator;
    }

    /**
     * ����cacheIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CacheIndicator }
     *     
     */
    public void setCacheIndicator(CacheIndicator value) {
        this.cacheIndicator = value;
    }

    /**
     * Gets the value of the comment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<Comment>();
        }
        return this.comment;
    }

    /**
     * Gets the value of the commentAction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the commentAction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCommentAction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommentAction }
     * 
     * 
     */
    public List<CommentAction> getCommentAction() {
        if (commentAction == null) {
            commentAction = new ArrayList<CommentAction>();
        }
        return this.commentAction;
    }

    /**
     * ��ȡcontext���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link RecordGoalSolutionDetailWSRequest.Context }
     *     
     */
    public RecordGoalSolutionDetailWSRequest.Context getContext() {
        return context;
    }

    /**
     * ����context���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link RecordGoalSolutionDetailWSRequest.Context }
     *     
     */
    public void setContext(RecordGoalSolutionDetailWSRequest.Context value) {
        this.context = value;
    }

    /**
     * ��ȡcontrolAdviceJourney���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ControlAdviceJourney }
     *     
     */
    public ControlAdviceJourney getControlAdviceJourney() {
        return controlAdviceJourney;
    }

    /**
     * ����controlAdviceJourney���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ControlAdviceJourney }
     *     
     */
    public void setControlAdviceJourney(ControlAdviceJourney value) {
        this.controlAdviceJourney = value;
    }

    /**
     * Gets the value of the coreReserveArea property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the coreReserveArea property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCoreReserveArea().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoreReserveArea }
     * 
     * 
     */
    public List<CoreReserveArea> getCoreReserveArea() {
        if (coreReserveArea == null) {
            coreReserveArea = new ArrayList<CoreReserveArea>();
        }
        return this.coreReserveArea;
    }

    /**
     * Gets the value of the currentPortfolioAllocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the currentPortfolioAllocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCurrentPortfolioAllocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrentPortfolioAllocation }
     * 
     * 
     */
    public List<CurrentPortfolioAllocation> getCurrentPortfolioAllocation() {
        if (currentPortfolioAllocation == null) {
            currentPortfolioAllocation = new ArrayList<CurrentPortfolioAllocation>();
        }
        return this.currentPortfolioAllocation;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the declaration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the declaration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeclaration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Declaration }
     * 
     * 
     */
    public List<Declaration> getDeclaration() {
        if (declaration == null) {
            declaration = new ArrayList<Declaration>();
        }
        return this.declaration;
    }

    /**
     * Gets the value of the existingHolding property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the existingHolding property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExistingHolding().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExistingHolding }
     * 
     * 
     */
    public List<ExistingHolding> getExistingHolding() {
        if (existingHolding == null) {
            existingHolding = new ArrayList<ExistingHolding>();
        }
        return this.existingHolding;
    }

    /**
     * Gets the value of the goalAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalAttribute }
     * 
     * 
     */
    public List<GoalAttribute> getGoalAttribute() {
        if (goalAttribute == null) {
            goalAttribute = new ArrayList<GoalAttribute>();
        }
        return this.goalAttribute;
    }

    /**
     * ��ȡgoalKey���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * ����goalKey���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the goalLocalFields property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalLocalFields property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalLocalFields().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalLocalFields }
     * 
     * 
     */
    public List<GoalLocalFields> getGoalLocalFields() {
        if (goalLocalFields == null) {
            goalLocalFields = new ArrayList<GoalLocalFields>();
        }
        return this.goalLocalFields;
    }

    /**
     * Gets the value of the investmentAppropriateness property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investmentAppropriateness property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestmentAppropriateness().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestmentAppropriateness }
     * 
     * 
     */
    public List<InvestmentAppropriateness> getInvestmentAppropriateness() {
        if (investmentAppropriateness == null) {
            investmentAppropriateness = new ArrayList<InvestmentAppropriateness>();
        }
        return this.investmentAppropriateness;
    }

    /**
     * Gets the value of the investorIndicator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investorIndicator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestorIndicator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestorIndicator }
     * 
     * 
     */
    public List<InvestorIndicator> getInvestorIndicator() {
        if (investorIndicator == null) {
            investorIndicator = new ArrayList<InvestorIndicator>();
        }
        return this.investorIndicator;
    }

    /**
     * ��ȡjointCustomer���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * ����jointCustomer���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * ��ȡleadId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link LeadId }
     *     
     */
    public LeadId getLeadId() {
        return leadId;
    }

    /**
     * ����leadId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link LeadId }
     *     
     */
    public void setLeadId(LeadId value) {
        this.leadId = value;
    }

    /**
     * Gets the value of the localFieldsArea property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the localFieldsArea property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocalFieldsArea().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LocalFieldsArea }
     * 
     * 
     */
    public List<LocalFieldsArea> getLocalFieldsArea() {
        if (localFieldsArea == null) {
            localFieldsArea = new ArrayList<LocalFieldsArea>();
        }
        return this.localFieldsArea;
    }

    /**
     * Gets the value of the modelPortfolioAssetClassAllocationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modelPortfolioAssetClassAllocationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModelPortfolioAssetClassAllocationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModelPortfolioAssetClassAllocationList }
     * 
     * 
     */
    public List<ModelPortfolioAssetClassAllocationList> getModelPortfolioAssetClassAllocationList() {
        if (modelPortfolioAssetClassAllocationList == null) {
            modelPortfolioAssetClassAllocationList = new ArrayList<ModelPortfolioAssetClassAllocationList>();
        }
        return this.modelPortfolioAssetClassAllocationList;
    }

    /**
     * Gets the value of the multipleAdviceStyleDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the multipleAdviceStyleDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMultipleAdviceStyleDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MultipleAdviceStyleDetails }
     * 
     * 
     */
    public List<MultipleAdviceStyleDetails> getMultipleAdviceStyleDetails() {
        if (multipleAdviceStyleDetails == null) {
            multipleAdviceStyleDetails = new ArrayList<MultipleAdviceStyleDetails>();
        }
        return this.multipleAdviceStyleDetails;
    }

    /**
     * Gets the value of the needEvaluation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the needEvaluation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNeedEvaluation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NeedEvaluation }
     * 
     * 
     */
    public List<NeedEvaluation> getNeedEvaluation() {
        if (needEvaluation == null) {
            needEvaluation = new ArrayList<NeedEvaluation>();
        }
        return this.needEvaluation;
    }

    /**
     * Gets the value of the notes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the notes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNotes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Notes }
     * 
     * 
     */
    public List<Notes> getNotes() {
        if (notes == null) {
            notes = new ArrayList<Notes>();
        }
        return this.notes;
    }

    /**
     * Gets the value of the optOutDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the optOutDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOptOutDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OptOutDetails }
     * 
     * 
     */
    public List<OptOutDetails> getOptOutDetails() {
        if (optOutDetails == null) {
            optOutDetails = new ArrayList<OptOutDetails>();
        }
        return this.optOutDetails;
    }

    /**
     * Gets the value of the packageKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the packageKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPackageKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PackageKey }
     * 
     * 
     */
    public List<PackageKey> getPackageKey() {
        if (packageKey == null) {
            packageKey = new ArrayList<PackageKey>();
        }
        return this.packageKey;
    }

    /**
     * Gets the value of the piqAnswerValidationInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the piqAnswerValidationInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPiqAnswerValidationInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PiqAnswerValidationInfo }
     * 
     * 
     */
    public List<PiqAnswerValidationInfo> getPiqAnswerValidationInfo() {
        if (piqAnswerValidationInfo == null) {
            piqAnswerValidationInfo = new ArrayList<PiqAnswerValidationInfo>();
        }
        return this.piqAnswerValidationInfo;
    }

    /**
     * Gets the value of the piqQuestAndAnsDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the piqQuestAndAnsDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPiqQuestAndAnsDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PiqQuestAndAnsDetails }
     * 
     * 
     */
    public List<PiqQuestAndAnsDetails> getPiqQuestAndAnsDetails() {
        if (piqQuestAndAnsDetails == null) {
            piqQuestAndAnsDetails = new ArrayList<PiqQuestAndAnsDetails>();
        }
        return this.piqQuestAndAnsDetails;
    }

    /**
     * ��ȡportfolioCalculationResult���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PortfolioCalculationResult }
     *     
     */
    public PortfolioCalculationResult getPortfolioCalculationResult() {
        return portfolioCalculationResult;
    }

    /**
     * ����portfolioCalculationResult���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PortfolioCalculationResult }
     *     
     */
    public void setPortfolioCalculationResult(PortfolioCalculationResult value) {
        this.portfolioCalculationResult = value;
    }

    /**
     * Gets the value of the productList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductList }
     * 
     * 
     */
    public List<ProductList> getProductList() {
        if (productList == null) {
            productList = new ArrayList<ProductList>();
        }
        return this.productList;
    }

    /**
     * Gets the value of the productTable property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productTable property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductTable().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductTable }
     * 
     * 
     */
    public List<ProductTable> getProductTable() {
        if (productTable == null) {
            productTable = new ArrayList<ProductTable>();
        }
        return this.productTable;
    }

    /**
     * Gets the value of the purposeBuyingProduct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the purposeBuyingProduct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPurposeBuyingProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PurposeBuyingProduct }
     * 
     * 
     */
    public List<PurposeBuyingProduct> getPurposeBuyingProduct() {
        if (purposeBuyingProduct == null) {
            purposeBuyingProduct = new ArrayList<PurposeBuyingProduct>();
        }
        return this.purposeBuyingProduct;
    }

    /**
     * Gets the value of the selectedProduct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the selectedProduct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSelectedProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SelectedProduct }
     * 
     * 
     */
    public List<SelectedProduct> getSelectedProduct() {
        if (selectedProduct == null) {
            selectedProduct = new ArrayList<SelectedProduct>();
        }
        return this.selectedProduct;
    }

    /**
     * ��ȡstaffAdviseSeg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link StaffAdviseSeg }
     *     
     */
    public StaffAdviseSeg getStaffAdviseSeg() {
        return staffAdviseSeg;
    }

    /**
     * ����staffAdviseSeg���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link StaffAdviseSeg }
     *     
     */
    public void setStaffAdviseSeg(StaffAdviseSeg value) {
        this.staffAdviseSeg = value;
    }

    /**
     * Gets the value of the subserviceId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subserviceId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubserviceId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubserviceId }
     * 
     * 
     */
    public List<SubserviceId> getSubserviceId() {
        if (subserviceId == null) {
            subserviceId = new ArrayList<SubserviceId>();
        }
        return this.subserviceId;
    }

    /**
     * Gets the value of the suitability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the suitability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSuitability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Suitability }
     * 
     * 
     */
    public List<Suitability> getSuitability() {
        if (suitability == null) {
            suitability = new ArrayList<Suitability>();
        }
        return this.suitability;
    }

    /**
     * Gets the value of the taxOptimizationDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the taxOptimizationDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTaxOptimizationDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxOptimizationDetails }
     * 
     * 
     */
    public List<TaxOptimizationDetails> getTaxOptimizationDetails() {
        if (taxOptimizationDetails == null) {
            taxOptimizationDetails = new ArrayList<TaxOptimizationDetails>();
        }
        return this.taxOptimizationDetails;
    }


    /**
     * <p>anonymous complex type�� Java �ࡣ
     * 
     * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="entry" maxOccurs="999" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
     *                   &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "entry"
    })
    public static class Context {

        protected List<RecordGoalSolutionDetailWSRequest.Context.Entry> entry;

        /**
         * Gets the value of the entry property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the entry property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEntry().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RecordGoalSolutionDetailWSRequest.Context.Entry }
         * 
         * 
         */
        public List<RecordGoalSolutionDetailWSRequest.Context.Entry> getEntry() {
            if (entry == null) {
                entry = new ArrayList<RecordGoalSolutionDetailWSRequest.Context.Entry>();
            }
            return this.entry;
        }


        /**
         * <p>anonymous complex type�� Java �ࡣ
         * 
         * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
         *         &lt;element name="value" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "key",
            "value"
        })
        public static class Entry {

            protected Object key;
            protected Object value;

            /**
             * ��ȡkey���Ե�ֵ��
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getKey() {
                return key;
            }

            /**
             * ����key���Ե�ֵ��
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setKey(Object value) {
                this.key = value;
            }

            /**
             * ��ȡvalue���Ե�ֵ��
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getValue() {
                return value;
            }

            /**
             * ����value���Ե�ֵ��
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setValue(Object value) {
                this.value = value;
            }

        }

    }

}
