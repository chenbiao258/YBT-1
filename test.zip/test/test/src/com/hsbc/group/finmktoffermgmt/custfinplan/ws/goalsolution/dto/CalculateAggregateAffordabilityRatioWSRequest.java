
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.svc.model.ws.dto.CalculateMode;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.Assets;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.Expense;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.Income;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.Investment;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.Liability;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.Validation;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>calculateAggregateAffordabilityRatioWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateAggregateAffordabilityRatioWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="assets" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assets" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="calculateMode" type="{http://dto.ws.model.svc.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateMode" minOccurs="0"/&gt;
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="expense" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}expense" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="income" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}income" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investment" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="liability" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}liability" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="validation" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}validation" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateAggregateAffordabilityRatioWSRequest", propOrder = {
    "assets",
    "calculateMode",
    "customers",
    "expense",
    "goalKey",
    "income",
    "investment",
    "jointCustomer",
    "liability",
    "validation"
})
public class CalculateAggregateAffordabilityRatioWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Assets> assets;
    protected CalculateMode calculateMode;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<Expense> expense;
    @XmlElement(nillable = true)
    protected List<GoalKey> goalKey;
    @XmlElement(nillable = true)
    protected List<Income> income;
    @XmlElement(nillable = true)
    protected List<Investment> investment;
    protected Customer jointCustomer;
    @XmlElement(nillable = true)
    protected List<Liability> liability;
    @XmlElement(nillable = true)
    protected List<Validation> validation;

    /**
     * Gets the value of the assets property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assets property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssets().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Assets }
     * 
     * 
     */
    public List<Assets> getAssets() {
        if (assets == null) {
            assets = new ArrayList<Assets>();
        }
        return this.assets;
    }

    /**
     * ��ȡcalculateMode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CalculateMode }
     *     
     */
    public CalculateMode getCalculateMode() {
        return calculateMode;
    }

    /**
     * ����calculateMode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateMode }
     *     
     */
    public void setCalculateMode(CalculateMode value) {
        this.calculateMode = value;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the expense property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the expense property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExpense().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Expense }
     * 
     * 
     */
    public List<Expense> getExpense() {
        if (expense == null) {
            expense = new ArrayList<Expense>();
        }
        return this.expense;
    }

    /**
     * Gets the value of the goalKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalKey }
     * 
     * 
     */
    public List<GoalKey> getGoalKey() {
        if (goalKey == null) {
            goalKey = new ArrayList<GoalKey>();
        }
        return this.goalKey;
    }

    /**
     * Gets the value of the income property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the income property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Income }
     * 
     * 
     */
    public List<Income> getIncome() {
        if (income == null) {
            income = new ArrayList<Income>();
        }
        return this.income;
    }

    /**
     * Gets the value of the investment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Investment }
     * 
     * 
     */
    public List<Investment> getInvestment() {
        if (investment == null) {
            investment = new ArrayList<Investment>();
        }
        return this.investment;
    }

    /**
     * ��ȡjointCustomer���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * ����jointCustomer���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the liability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the liability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLiability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Liability }
     * 
     * 
     */
    public List<Liability> getLiability() {
        if (liability == null) {
            liability = new ArrayList<Liability>();
        }
        return this.liability;
    }

    /**
     * Gets the value of the validation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Validation }
     * 
     * 
     */
    public List<Validation> getValidation() {
        if (validation == null) {
            validation = new ArrayList<Validation>();
        }
        return this.validation;
    }

}
