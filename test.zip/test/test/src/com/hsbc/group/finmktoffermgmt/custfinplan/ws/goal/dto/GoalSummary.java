
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;


/**
 * <p>goalSummary complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="goalSummary"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="additionalAmount" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalAmount" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="additionalInformation" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}additionalInformation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="comment" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}comment" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="financialGoalProcessPreviousStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="financialGoalProcessStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="fundAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundMonthlyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="fundMonthlyCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalAcknowledgementDatetime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalCompletionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalFeature" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalFeature" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/&gt;
 *         &lt;element name="goalMonthCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="goalObjectiveTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalOrderExecutionDatetime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetAmountCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="goalTargetEndDatetime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="recordCreateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="recordUpdateDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="riskCapacityAssignDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="riskCapacityLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="riskCapacityRecommendLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="riskToleranceLevelNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="skipRiskProfilingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "goalSummary", propOrder = {
    "additionalAmount",
    "additionalInformation",
    "comment",
    "customers",
    "financialGoalProcessPreviousStatusCode",
    "financialGoalProcessStatusCode",
    "fundAmount",
    "fundAmountCurrencyCode",
    "fundMonthlyAmount",
    "fundMonthlyCurrencyCode",
    "goalAcknowledgementDatetime",
    "goalCompletionDateTime",
    "goalDescription",
    "goalFeature",
    "goalKey",
    "goalMonthCount",
    "goalObjectiveTypeCode",
    "goalOrderExecutionDatetime",
    "goalStartDate",
    "goalTargetAmount",
    "goalTargetAmountCurrencyCode",
    "goalTargetEndDatetime",
    "goalTypeCode",
    "jointCustomer",
    "needTypeCode",
    "recordCreateDateTime",
    "recordUpdateDateTime",
    "riskCapacityAssignDate",
    "riskCapacityLevelNumber",
    "riskCapacityRecommendLevelNumber",
    "riskToleranceLevelNumber",
    "skipRiskProfilingIndicator"
})
public class GoalSummary {

    @XmlElement(nillable = true)
    protected List<AdditionalAmount> additionalAmount;
    @XmlElement(nillable = true)
    protected List<AdditionalInformation> additionalInformation;
    @XmlElement(nillable = true)
    protected List<Comment> comment;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    protected String financialGoalProcessPreviousStatusCode;
    protected String financialGoalProcessStatusCode;
    protected BigDecimal fundAmount;
    protected String fundAmountCurrencyCode;
    protected BigDecimal fundMonthlyAmount;
    protected String fundMonthlyCurrencyCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalAcknowledgementDatetime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalCompletionDateTime;
    protected String goalDescription;
    @XmlElement(nillable = true)
    protected List<GoalFeature> goalFeature;
    protected GoalKey goalKey;
    protected int goalMonthCount;
    protected String goalObjectiveTypeCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalOrderExecutionDatetime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalStartDate;
    protected BigDecimal goalTargetAmount;
    protected String goalTargetAmountCurrencyCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar goalTargetEndDatetime;
    protected String goalTypeCode;
    protected Customer jointCustomer;
    protected String needTypeCode;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordCreateDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar recordUpdateDateTime;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar riskCapacityAssignDate;
    protected Integer riskCapacityLevelNumber;
    protected Integer riskCapacityRecommendLevelNumber;
    protected Integer riskToleranceLevelNumber;
    protected String skipRiskProfilingIndicator;

    /**
     * Gets the value of the additionalAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmount }
     * 
     * 
     */
    public List<AdditionalAmount> getAdditionalAmount() {
        if (additionalAmount == null) {
            additionalAmount = new ArrayList<AdditionalAmount>();
        }
        return this.additionalAmount;
    }

    /**
     * Gets the value of the additionalInformation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInformation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInformation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInformation }
     * 
     * 
     */
    public List<AdditionalInformation> getAdditionalInformation() {
        if (additionalInformation == null) {
            additionalInformation = new ArrayList<AdditionalInformation>();
        }
        return this.additionalInformation;
    }

    /**
     * Gets the value of the comment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Comment }
     * 
     * 
     */
    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<Comment>();
        }
        return this.comment;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * ��ȡfinancialGoalProcessPreviousStatusCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialGoalProcessPreviousStatusCode() {
        return financialGoalProcessPreviousStatusCode;
    }

    /**
     * ����financialGoalProcessPreviousStatusCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialGoalProcessPreviousStatusCode(String value) {
        this.financialGoalProcessPreviousStatusCode = value;
    }

    /**
     * ��ȡfinancialGoalProcessStatusCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialGoalProcessStatusCode() {
        return financialGoalProcessStatusCode;
    }

    /**
     * ����financialGoalProcessStatusCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialGoalProcessStatusCode(String value) {
        this.financialGoalProcessStatusCode = value;
    }

    /**
     * ��ȡfundAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundAmount() {
        return fundAmount;
    }

    /**
     * ����fundAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundAmount(BigDecimal value) {
        this.fundAmount = value;
    }

    /**
     * ��ȡfundAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundAmountCurrencyCode() {
        return fundAmountCurrencyCode;
    }

    /**
     * ����fundAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundAmountCurrencyCode(String value) {
        this.fundAmountCurrencyCode = value;
    }

    /**
     * ��ȡfundMonthlyAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundMonthlyAmount() {
        return fundMonthlyAmount;
    }

    /**
     * ����fundMonthlyAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundMonthlyAmount(BigDecimal value) {
        this.fundMonthlyAmount = value;
    }

    /**
     * ��ȡfundMonthlyCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundMonthlyCurrencyCode() {
        return fundMonthlyCurrencyCode;
    }

    /**
     * ����fundMonthlyCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundMonthlyCurrencyCode(String value) {
        this.fundMonthlyCurrencyCode = value;
    }

    /**
     * ��ȡgoalAcknowledgementDatetime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalAcknowledgementDatetime() {
        return goalAcknowledgementDatetime;
    }

    /**
     * ����goalAcknowledgementDatetime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalAcknowledgementDatetime(XMLGregorianCalendar value) {
        this.goalAcknowledgementDatetime = value;
    }

    /**
     * ��ȡgoalCompletionDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalCompletionDateTime() {
        return goalCompletionDateTime;
    }

    /**
     * ����goalCompletionDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalCompletionDateTime(XMLGregorianCalendar value) {
        this.goalCompletionDateTime = value;
    }

    /**
     * ��ȡgoalDescription���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalDescription() {
        return goalDescription;
    }

    /**
     * ����goalDescription���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalDescription(String value) {
        this.goalDescription = value;
    }

    /**
     * Gets the value of the goalFeature property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the goalFeature property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGoalFeature().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GoalFeature }
     * 
     * 
     */
    public List<GoalFeature> getGoalFeature() {
        if (goalFeature == null) {
            goalFeature = new ArrayList<GoalFeature>();
        }
        return this.goalFeature;
    }

    /**
     * ��ȡgoalKey���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * ����goalKey���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * ��ȡgoalMonthCount���Ե�ֵ��
     * 
     */
    public int getGoalMonthCount() {
        return goalMonthCount;
    }

    /**
     * ����goalMonthCount���Ե�ֵ��
     * 
     */
    public void setGoalMonthCount(int value) {
        this.goalMonthCount = value;
    }

    /**
     * ��ȡgoalObjectiveTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalObjectiveTypeCode() {
        return goalObjectiveTypeCode;
    }

    /**
     * ����goalObjectiveTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalObjectiveTypeCode(String value) {
        this.goalObjectiveTypeCode = value;
    }

    /**
     * ��ȡgoalOrderExecutionDatetime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalOrderExecutionDatetime() {
        return goalOrderExecutionDatetime;
    }

    /**
     * ����goalOrderExecutionDatetime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalOrderExecutionDatetime(XMLGregorianCalendar value) {
        this.goalOrderExecutionDatetime = value;
    }

    /**
     * ��ȡgoalStartDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalStartDate() {
        return goalStartDate;
    }

    /**
     * ����goalStartDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalStartDate(XMLGregorianCalendar value) {
        this.goalStartDate = value;
    }

    /**
     * ��ȡgoalTargetAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoalTargetAmount() {
        return goalTargetAmount;
    }

    /**
     * ����goalTargetAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoalTargetAmount(BigDecimal value) {
        this.goalTargetAmount = value;
    }

    /**
     * ��ȡgoalTargetAmountCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTargetAmountCurrencyCode() {
        return goalTargetAmountCurrencyCode;
    }

    /**
     * ����goalTargetAmountCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTargetAmountCurrencyCode(String value) {
        this.goalTargetAmountCurrencyCode = value;
    }

    /**
     * ��ȡgoalTargetEndDatetime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getGoalTargetEndDatetime() {
        return goalTargetEndDatetime;
    }

    /**
     * ����goalTargetEndDatetime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setGoalTargetEndDatetime(XMLGregorianCalendar value) {
        this.goalTargetEndDatetime = value;
    }

    /**
     * ��ȡgoalTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * ����goalTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * ��ȡjointCustomer���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * ����jointCustomer���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * ��ȡneedTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * ����needTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

    /**
     * ��ȡrecordCreateDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordCreateDateTime() {
        return recordCreateDateTime;
    }

    /**
     * ����recordCreateDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordCreateDateTime(XMLGregorianCalendar value) {
        this.recordCreateDateTime = value;
    }

    /**
     * ��ȡrecordUpdateDateTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRecordUpdateDateTime() {
        return recordUpdateDateTime;
    }

    /**
     * ����recordUpdateDateTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRecordUpdateDateTime(XMLGregorianCalendar value) {
        this.recordUpdateDateTime = value;
    }

    /**
     * ��ȡriskCapacityAssignDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRiskCapacityAssignDate() {
        return riskCapacityAssignDate;
    }

    /**
     * ����riskCapacityAssignDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRiskCapacityAssignDate(XMLGregorianCalendar value) {
        this.riskCapacityAssignDate = value;
    }

    /**
     * ��ȡriskCapacityLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityLevelNumber() {
        return riskCapacityLevelNumber;
    }

    /**
     * ����riskCapacityLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityLevelNumber(Integer value) {
        this.riskCapacityLevelNumber = value;
    }

    /**
     * ��ȡriskCapacityRecommendLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskCapacityRecommendLevelNumber() {
        return riskCapacityRecommendLevelNumber;
    }

    /**
     * ����riskCapacityRecommendLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskCapacityRecommendLevelNumber(Integer value) {
        this.riskCapacityRecommendLevelNumber = value;
    }

    /**
     * ��ȡriskToleranceLevelNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRiskToleranceLevelNumber() {
        return riskToleranceLevelNumber;
    }

    /**
     * ����riskToleranceLevelNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRiskToleranceLevelNumber(Integer value) {
        this.riskToleranceLevelNumber = value;
    }

    /**
     * ��ȡskipRiskProfilingIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSkipRiskProfilingIndicator() {
        return skipRiskProfilingIndicator;
    }

    /**
     * ����skipRiskProfilingIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSkipRiskProfilingIndicator(String value) {
        this.skipRiskProfilingIndicator = value;
    }

}
