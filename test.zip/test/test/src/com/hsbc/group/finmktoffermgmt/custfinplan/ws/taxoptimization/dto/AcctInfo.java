
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>acctInfo complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="acctInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountNickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountProductTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="accountTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="countryInvestmentAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dashboardAccountSubGroupIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="groupMemberInvestmentAccountCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="investmentAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="placeholderIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="restrictWrapperFromSwitchingComd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="restrictWrapperFromSwitchingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wrapperDocument" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperDocument" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "acctInfo", propOrder = {
    "accountNickName",
    "accountNumber",
    "accountProductTypeCode",
    "accountSequenceNumber",
    "accountTypeCode",
    "countryInvestmentAccountCode",
    "currencyAccountCode",
    "dashboardAccountSubGroupIdentifier",
    "groupMemberInvestmentAccountCode",
    "investmentAccountNumber",
    "placeholderIndicator",
    "restrictWrapperFromSwitchingComd",
    "restrictWrapperFromSwitchingIndicator",
    "wrapperDocument"
})
public class AcctInfo {

    protected String accountNickName;
    protected String accountNumber;
    protected String accountProductTypeCode;
    protected long accountSequenceNumber;
    protected String accountTypeCode;
    protected String countryInvestmentAccountCode;
    protected String currencyAccountCode;
    protected String dashboardAccountSubGroupIdentifier;
    protected String groupMemberInvestmentAccountCode;
    protected String investmentAccountNumber;
    protected String placeholderIndicator;
    protected String restrictWrapperFromSwitchingComd;
    protected String restrictWrapperFromSwitchingIndicator;
    @XmlElement(nillable = true)
    protected List<WrapperDocument> wrapperDocument;

    /**
     * ��ȡaccountNickName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNickName() {
        return accountNickName;
    }

    /**
     * ����accountNickName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNickName(String value) {
        this.accountNickName = value;
    }

    /**
     * ��ȡaccountNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * ����accountNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * ��ȡaccountProductTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountProductTypeCode() {
        return accountProductTypeCode;
    }

    /**
     * ����accountProductTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountProductTypeCode(String value) {
        this.accountProductTypeCode = value;
    }

    /**
     * ��ȡaccountSequenceNumber���Ե�ֵ��
     * 
     */
    public long getAccountSequenceNumber() {
        return accountSequenceNumber;
    }

    /**
     * ����accountSequenceNumber���Ե�ֵ��
     * 
     */
    public void setAccountSequenceNumber(long value) {
        this.accountSequenceNumber = value;
    }

    /**
     * ��ȡaccountTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    /**
     * ����accountTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeCode(String value) {
        this.accountTypeCode = value;
    }

    /**
     * ��ȡcountryInvestmentAccountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryInvestmentAccountCode() {
        return countryInvestmentAccountCode;
    }

    /**
     * ����countryInvestmentAccountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryInvestmentAccountCode(String value) {
        this.countryInvestmentAccountCode = value;
    }

    /**
     * ��ȡcurrencyAccountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyAccountCode() {
        return currencyAccountCode;
    }

    /**
     * ����currencyAccountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyAccountCode(String value) {
        this.currencyAccountCode = value;
    }

    /**
     * ��ȡdashboardAccountSubGroupIdentifier���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDashboardAccountSubGroupIdentifier() {
        return dashboardAccountSubGroupIdentifier;
    }

    /**
     * ����dashboardAccountSubGroupIdentifier���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDashboardAccountSubGroupIdentifier(String value) {
        this.dashboardAccountSubGroupIdentifier = value;
    }

    /**
     * ��ȡgroupMemberInvestmentAccountCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupMemberInvestmentAccountCode() {
        return groupMemberInvestmentAccountCode;
    }

    /**
     * ����groupMemberInvestmentAccountCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupMemberInvestmentAccountCode(String value) {
        this.groupMemberInvestmentAccountCode = value;
    }

    /**
     * ��ȡinvestmentAccountNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    /**
     * ����investmentAccountNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestmentAccountNumber(String value) {
        this.investmentAccountNumber = value;
    }

    /**
     * ��ȡplaceholderIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceholderIndicator() {
        return placeholderIndicator;
    }

    /**
     * ����placeholderIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceholderIndicator(String value) {
        this.placeholderIndicator = value;
    }

    /**
     * ��ȡrestrictWrapperFromSwitchingComd���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictWrapperFromSwitchingComd() {
        return restrictWrapperFromSwitchingComd;
    }

    /**
     * ����restrictWrapperFromSwitchingComd���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictWrapperFromSwitchingComd(String value) {
        this.restrictWrapperFromSwitchingComd = value;
    }

    /**
     * ��ȡrestrictWrapperFromSwitchingIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestrictWrapperFromSwitchingIndicator() {
        return restrictWrapperFromSwitchingIndicator;
    }

    /**
     * ����restrictWrapperFromSwitchingIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestrictWrapperFromSwitchingIndicator(String value) {
        this.restrictWrapperFromSwitchingIndicator = value;
    }

    /**
     * Gets the value of the wrapperDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperDocument }
     * 
     * 
     */
    public List<WrapperDocument> getWrapperDocument() {
        if (wrapperDocument == null) {
            wrapperDocument = new ArrayList<WrapperDocument>();
        }
        return this.wrapperDocument;
    }

}
