
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveManagedSolutionDetailWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveProductSearchResultWSResponse;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>productSelectionWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productSelectionWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cacheDataToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productSelectionWSResponse", propOrder = {
    "cacheDataToken"
})
@XmlSeeAlso({
    RetrieveProductSearchResultWSResponse.class,
    RetrieveManagedSolutionDetailWSResponse.class
})
public class ProductSelectionWSResponse
    extends WebServiceResponse
{

    protected String cacheDataToken;

    /**
     * ��ȡcacheDataToken���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCacheDataToken() {
        return cacheDataToken;
    }

    /**
     * ����cacheDataToken���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCacheDataToken(String value) {
        this.cacheDataToken = value;
    }

}
