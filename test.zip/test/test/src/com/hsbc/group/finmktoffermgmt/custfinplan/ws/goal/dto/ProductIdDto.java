
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.taxoptimization.dto.WrapperAccount;


/**
 * <p>productIdDto complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="productIdDto"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="productAlternativeNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productCodeAlternativeClassCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productSelectionMethodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productTradableCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wrapperAccount" type="{http://dto.taxoptimization.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}wrapperAccount" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productIdDto", propOrder = {
    "productAlternativeNumber",
    "productCodeAlternativeClassCode",
    "productSelectionMethodCode",
    "productTradableCode",
    "productTypeCode",
    "wrapperAccount"
})
public class ProductIdDto {

    protected String productAlternativeNumber;
    protected String productCodeAlternativeClassCode;
    protected String productSelectionMethodCode;
    protected String productTradableCode;
    protected String productTypeCode;
    @XmlElement(nillable = true)
    protected List<WrapperAccount> wrapperAccount;

    /**
     * ��ȡproductAlternativeNumber���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductAlternativeNumber() {
        return productAlternativeNumber;
    }

    /**
     * ����productAlternativeNumber���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductAlternativeNumber(String value) {
        this.productAlternativeNumber = value;
    }

    /**
     * ��ȡproductCodeAlternativeClassCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCodeAlternativeClassCode() {
        return productCodeAlternativeClassCode;
    }

    /**
     * ����productCodeAlternativeClassCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCodeAlternativeClassCode(String value) {
        this.productCodeAlternativeClassCode = value;
    }

    /**
     * ��ȡproductSelectionMethodCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductSelectionMethodCode() {
        return productSelectionMethodCode;
    }

    /**
     * ����productSelectionMethodCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductSelectionMethodCode(String value) {
        this.productSelectionMethodCode = value;
    }

    /**
     * ��ȡproductTradableCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTradableCode() {
        return productTradableCode;
    }

    /**
     * ����productTradableCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTradableCode(String value) {
        this.productTradableCode = value;
    }

    /**
     * ��ȡproductTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductTypeCode() {
        return productTypeCode;
    }

    /**
     * ����productTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductTypeCode(String value) {
        this.productTypeCode = value;
    }

    /**
     * Gets the value of the wrapperAccount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wrapperAccount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWrapperAccount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WrapperAccount }
     * 
     * 
     */
    public List<WrapperAccount> getWrapperAccount() {
        if (wrapperAccount == null) {
            wrapperAccount = new ArrayList<WrapperAccount>();
        }
        return this.wrapperAccount;
    }

}
