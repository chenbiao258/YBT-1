
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>actualPortfolioAllocation complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="actualPortfolioAllocation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="allocationInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentAmountCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPieChartPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPieChartPercentLongShortIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assetClassGroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "actualPortfolioAllocation", propOrder = {
    "allocationInvestmentAmount",
    "allocationInvestmentAmountCurrency",
    "allocationInvestmentPercent",
    "allocationInvestmentPieChartPercent",
    "allocationInvestmentPieChartPercentLongShortIndicator",
    "assetClassGroupCode",
    "assetClassGroupName"
})
public class ActualPortfolioAllocation {

    protected BigDecimal allocationInvestmentAmount;
    protected String allocationInvestmentAmountCurrency;
    protected BigDecimal allocationInvestmentPercent;
    protected BigDecimal allocationInvestmentPieChartPercent;
    protected String allocationInvestmentPieChartPercentLongShortIndicator;
    protected String assetClassGroupCode;
    protected String assetClassGroupName;

    /**
     * ��ȡallocationInvestmentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentAmount() {
        return allocationInvestmentAmount;
    }

    /**
     * ����allocationInvestmentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentAmount(BigDecimal value) {
        this.allocationInvestmentAmount = value;
    }

    /**
     * ��ȡallocationInvestmentAmountCurrency���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentAmountCurrency() {
        return allocationInvestmentAmountCurrency;
    }

    /**
     * ����allocationInvestmentAmountCurrency���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentAmountCurrency(String value) {
        this.allocationInvestmentAmountCurrency = value;
    }

    /**
     * ��ȡallocationInvestmentPercent���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPercent() {
        return allocationInvestmentPercent;
    }

    /**
     * ����allocationInvestmentPercent���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPercent(BigDecimal value) {
        this.allocationInvestmentPercent = value;
    }

    /**
     * ��ȡallocationInvestmentPieChartPercent���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPieChartPercent() {
        return allocationInvestmentPieChartPercent;
    }

    /**
     * ����allocationInvestmentPieChartPercent���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPieChartPercent(BigDecimal value) {
        this.allocationInvestmentPieChartPercent = value;
    }

    /**
     * ��ȡallocationInvestmentPieChartPercentLongShortIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentPieChartPercentLongShortIndicator() {
        return allocationInvestmentPieChartPercentLongShortIndicator;
    }

    /**
     * ����allocationInvestmentPieChartPercentLongShortIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentPieChartPercentLongShortIndicator(String value) {
        this.allocationInvestmentPieChartPercentLongShortIndicator = value;
    }

    /**
     * ��ȡassetClassGroupCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * ����assetClassGroupCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * ��ȡassetClassGroupName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupName() {
        return assetClassGroupName;
    }

    /**
     * ����assetClassGroupName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupName(String value) {
        this.assetClassGroupName = value;
    }

}
