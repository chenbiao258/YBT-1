
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto.GoalKey;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>calculateGoalPortfolioWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateGoalPortfolioWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="customerKey" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalKey" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}goalKey" minOccurs="0"/&gt;
 *         &lt;element name="investmentProductList" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investmentProductList" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomerKey" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="portfolioCalculationParameter" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioCalculationParameter" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateGoalPortfolioWSRequest", propOrder = {
    "customerKey",
    "goalKey",
    "investmentProductList",
    "jointCustomerKey",
    "portfolioCalculationParameter"
})
public class CalculateGoalPortfolioWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Customer> customerKey;
    protected GoalKey goalKey;
    @XmlElement(nillable = true)
    protected List<InvestmentProductList> investmentProductList;
    protected Customer jointCustomerKey;
    @XmlElement(nillable = true)
    protected List<PortfolioCalculationParameter> portfolioCalculationParameter;

    /**
     * Gets the value of the customerKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customerKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomerKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomerKey() {
        if (customerKey == null) {
            customerKey = new ArrayList<Customer>();
        }
        return this.customerKey;
    }

    /**
     * ��ȡgoalKey���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link GoalKey }
     *     
     */
    public GoalKey getGoalKey() {
        return goalKey;
    }

    /**
     * ����goalKey���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link GoalKey }
     *     
     */
    public void setGoalKey(GoalKey value) {
        this.goalKey = value;
    }

    /**
     * Gets the value of the investmentProductList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investmentProductList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestmentProductList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestmentProductList }
     * 
     * 
     */
    public List<InvestmentProductList> getInvestmentProductList() {
        if (investmentProductList == null) {
            investmentProductList = new ArrayList<InvestmentProductList>();
        }
        return this.investmentProductList;
    }

    /**
     * ��ȡjointCustomerKey���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomerKey() {
        return jointCustomerKey;
    }

    /**
     * ����jointCustomerKey���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomerKey(Customer value) {
        this.jointCustomerKey = value;
    }

    /**
     * Gets the value of the portfolioCalculationParameter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the portfolioCalculationParameter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPortfolioCalculationParameter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PortfolioCalculationParameter }
     * 
     * 
     */
    public List<PortfolioCalculationParameter> getPortfolioCalculationParameter() {
        if (portfolioCalculationParameter == null) {
            portfolioCalculationParameter = new ArrayList<PortfolioCalculationParameter>();
        }
        return this.portfolioCalculationParameter;
    }

}
