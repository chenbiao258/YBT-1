
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto.RetrieveFinancialSituationDataWSRequest;


/**
 * <p>retrieveFinancialSituationData complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="retrieveFinancialSituationData"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="arg0" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}retrieveFinancialSituationDataWSRequest" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveFinancialSituationData", propOrder = {
    "arg0"
})
public class RetrieveFinancialSituationData {

    protected RetrieveFinancialSituationDataWSRequest arg0;

    /**
     * ��ȡarg0���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link RetrieveFinancialSituationDataWSRequest }
     *     
     */
    public RetrieveFinancialSituationDataWSRequest getArg0() {
        return arg0;
    }

    /**
     * ����arg0���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveFinancialSituationDataWSRequest }
     *     
     */
    public void setArg0(RetrieveFinancialSituationDataWSRequest value) {
        this.arg0 = value;
    }

}
