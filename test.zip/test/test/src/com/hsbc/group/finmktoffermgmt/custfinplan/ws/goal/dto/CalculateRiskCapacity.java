
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goal.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>calculateRiskCapacity complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacity"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="calculateRiskCapacityCriteria" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateRiskCapacityCriteria" minOccurs="0"/&gt;
 *         &lt;element name="calculateTimeHorizonCriteria" type="{http://dto.goal.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateTimeHorizonCriteria" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="goalTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="needTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacity", propOrder = {
    "calculateRiskCapacityCriteria",
    "calculateTimeHorizonCriteria",
    "goalTypeCode",
    "needTypeCode"
})
public class CalculateRiskCapacity {

    protected CalculateRiskCapacityCriteria calculateRiskCapacityCriteria;
    @XmlElement(nillable = true)
    protected List<CalculateTimeHorizonCriteria> calculateTimeHorizonCriteria;
    protected String goalTypeCode;
    protected String needTypeCode;

    /**
     * ��ȡcalculateRiskCapacityCriteria���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CalculateRiskCapacityCriteria }
     *     
     */
    public CalculateRiskCapacityCriteria getCalculateRiskCapacityCriteria() {
        return calculateRiskCapacityCriteria;
    }

    /**
     * ����calculateRiskCapacityCriteria���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateRiskCapacityCriteria }
     *     
     */
    public void setCalculateRiskCapacityCriteria(CalculateRiskCapacityCriteria value) {
        this.calculateRiskCapacityCriteria = value;
    }

    /**
     * Gets the value of the calculateTimeHorizonCriteria property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the calculateTimeHorizonCriteria property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCalculateTimeHorizonCriteria().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CalculateTimeHorizonCriteria }
     * 
     * 
     */
    public List<CalculateTimeHorizonCriteria> getCalculateTimeHorizonCriteria() {
        if (calculateTimeHorizonCriteria == null) {
            calculateTimeHorizonCriteria = new ArrayList<CalculateTimeHorizonCriteria>();
        }
        return this.calculateTimeHorizonCriteria;
    }

    /**
     * ��ȡgoalTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoalTypeCode() {
        return goalTypeCode;
    }

    /**
     * ����goalTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoalTypeCode(String value) {
        this.goalTypeCode = value;
    }

    /**
     * ��ȡneedTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNeedTypeCode() {
        return needTypeCode;
    }

    /**
     * ����needTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNeedTypeCode(String value) {
        this.needTypeCode = value;
    }

}
