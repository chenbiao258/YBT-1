
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>modelPortfolioAssetClassAllocation complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="modelPortfolioAssetClassAllocation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="allocationInvestmentAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentAmountCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPieChartPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="allocationInvestmentPieChartPercentLongShortIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assetClassGroupCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assetClassGroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="maximumAllocationInvestmentAmountCurrencyFirstRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="maximumAllocationInvestmentAmountCurrencySecondRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="maximumAllocationInvestmentAmountFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="maximumAllocationInvestmentAmountSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="maximumAllocationInvestmentPercentFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="maximumAllocationInvestmentPercentSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="minimumAllocationInvestmentAmountCurrencyFirstRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="minimumAllocationInvestmentAmountCurrencySecondRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="minimumAllocationInvestmentAmountFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="minimumAllocationInvestmentAmountSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="minimumAllocationInvestmentPercentFirstRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="minimumAllocationInvestmentPercentSecondRange" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "modelPortfolioAssetClassAllocation", propOrder = {
    "allocationInvestmentAmount",
    "allocationInvestmentAmountCurrency",
    "allocationInvestmentPercent",
    "allocationInvestmentPieChartPercent",
    "allocationInvestmentPieChartPercentLongShortIndicator",
    "assetClassGroupCode",
    "assetClassGroupName",
    "maximumAllocationInvestmentAmountCurrencyFirstRange",
    "maximumAllocationInvestmentAmountCurrencySecondRange",
    "maximumAllocationInvestmentAmountFirstRange",
    "maximumAllocationInvestmentAmountSecondRange",
    "maximumAllocationInvestmentPercentFirstRange",
    "maximumAllocationInvestmentPercentSecondRange",
    "minimumAllocationInvestmentAmountCurrencyFirstRange",
    "minimumAllocationInvestmentAmountCurrencySecondRange",
    "minimumAllocationInvestmentAmountFirstRange",
    "minimumAllocationInvestmentAmountSecondRange",
    "minimumAllocationInvestmentPercentFirstRange",
    "minimumAllocationInvestmentPercentSecondRange"
})
public class ModelPortfolioAssetClassAllocation {

    protected BigDecimal allocationInvestmentAmount;
    protected String allocationInvestmentAmountCurrency;
    protected BigDecimal allocationInvestmentPercent;
    protected BigDecimal allocationInvestmentPieChartPercent;
    protected String allocationInvestmentPieChartPercentLongShortIndicator;
    protected String assetClassGroupCode;
    protected String assetClassGroupName;
    protected String maximumAllocationInvestmentAmountCurrencyFirstRange;
    protected String maximumAllocationInvestmentAmountCurrencySecondRange;
    protected BigDecimal maximumAllocationInvestmentAmountFirstRange;
    protected BigDecimal maximumAllocationInvestmentAmountSecondRange;
    protected BigDecimal maximumAllocationInvestmentPercentFirstRange;
    protected BigDecimal maximumAllocationInvestmentPercentSecondRange;
    protected String minimumAllocationInvestmentAmountCurrencyFirstRange;
    protected String minimumAllocationInvestmentAmountCurrencySecondRange;
    protected BigDecimal minimumAllocationInvestmentAmountFirstRange;
    protected BigDecimal minimumAllocationInvestmentAmountSecondRange;
    protected BigDecimal minimumAllocationInvestmentPercentFirstRange;
    protected BigDecimal minimumAllocationInvestmentPercentSecondRange;

    /**
     * ��ȡallocationInvestmentAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentAmount() {
        return allocationInvestmentAmount;
    }

    /**
     * ����allocationInvestmentAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentAmount(BigDecimal value) {
        this.allocationInvestmentAmount = value;
    }

    /**
     * ��ȡallocationInvestmentAmountCurrency���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentAmountCurrency() {
        return allocationInvestmentAmountCurrency;
    }

    /**
     * ����allocationInvestmentAmountCurrency���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentAmountCurrency(String value) {
        this.allocationInvestmentAmountCurrency = value;
    }

    /**
     * ��ȡallocationInvestmentPercent���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPercent() {
        return allocationInvestmentPercent;
    }

    /**
     * ����allocationInvestmentPercent���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPercent(BigDecimal value) {
        this.allocationInvestmentPercent = value;
    }

    /**
     * ��ȡallocationInvestmentPieChartPercent���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAllocationInvestmentPieChartPercent() {
        return allocationInvestmentPieChartPercent;
    }

    /**
     * ����allocationInvestmentPieChartPercent���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAllocationInvestmentPieChartPercent(BigDecimal value) {
        this.allocationInvestmentPieChartPercent = value;
    }

    /**
     * ��ȡallocationInvestmentPieChartPercentLongShortIndicator���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationInvestmentPieChartPercentLongShortIndicator() {
        return allocationInvestmentPieChartPercentLongShortIndicator;
    }

    /**
     * ����allocationInvestmentPieChartPercentLongShortIndicator���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationInvestmentPieChartPercentLongShortIndicator(String value) {
        this.allocationInvestmentPieChartPercentLongShortIndicator = value;
    }

    /**
     * ��ȡassetClassGroupCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupCode() {
        return assetClassGroupCode;
    }

    /**
     * ����assetClassGroupCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupCode(String value) {
        this.assetClassGroupCode = value;
    }

    /**
     * ��ȡassetClassGroupName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetClassGroupName() {
        return assetClassGroupName;
    }

    /**
     * ����assetClassGroupName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetClassGroupName(String value) {
        this.assetClassGroupName = value;
    }

    /**
     * ��ȡmaximumAllocationInvestmentAmountCurrencyFirstRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumAllocationInvestmentAmountCurrencyFirstRange() {
        return maximumAllocationInvestmentAmountCurrencyFirstRange;
    }

    /**
     * ����maximumAllocationInvestmentAmountCurrencyFirstRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumAllocationInvestmentAmountCurrencyFirstRange(String value) {
        this.maximumAllocationInvestmentAmountCurrencyFirstRange = value;
    }

    /**
     * ��ȡmaximumAllocationInvestmentAmountCurrencySecondRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumAllocationInvestmentAmountCurrencySecondRange() {
        return maximumAllocationInvestmentAmountCurrencySecondRange;
    }

    /**
     * ����maximumAllocationInvestmentAmountCurrencySecondRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumAllocationInvestmentAmountCurrencySecondRange(String value) {
        this.maximumAllocationInvestmentAmountCurrencySecondRange = value;
    }

    /**
     * ��ȡmaximumAllocationInvestmentAmountFirstRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentAmountFirstRange() {
        return maximumAllocationInvestmentAmountFirstRange;
    }

    /**
     * ����maximumAllocationInvestmentAmountFirstRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentAmountFirstRange(BigDecimal value) {
        this.maximumAllocationInvestmentAmountFirstRange = value;
    }

    /**
     * ��ȡmaximumAllocationInvestmentAmountSecondRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentAmountSecondRange() {
        return maximumAllocationInvestmentAmountSecondRange;
    }

    /**
     * ����maximumAllocationInvestmentAmountSecondRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentAmountSecondRange(BigDecimal value) {
        this.maximumAllocationInvestmentAmountSecondRange = value;
    }

    /**
     * ��ȡmaximumAllocationInvestmentPercentFirstRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentPercentFirstRange() {
        return maximumAllocationInvestmentPercentFirstRange;
    }

    /**
     * ����maximumAllocationInvestmentPercentFirstRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentPercentFirstRange(BigDecimal value) {
        this.maximumAllocationInvestmentPercentFirstRange = value;
    }

    /**
     * ��ȡmaximumAllocationInvestmentPercentSecondRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMaximumAllocationInvestmentPercentSecondRange() {
        return maximumAllocationInvestmentPercentSecondRange;
    }

    /**
     * ����maximumAllocationInvestmentPercentSecondRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMaximumAllocationInvestmentPercentSecondRange(BigDecimal value) {
        this.maximumAllocationInvestmentPercentSecondRange = value;
    }

    /**
     * ��ȡminimumAllocationInvestmentAmountCurrencyFirstRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumAllocationInvestmentAmountCurrencyFirstRange() {
        return minimumAllocationInvestmentAmountCurrencyFirstRange;
    }

    /**
     * ����minimumAllocationInvestmentAmountCurrencyFirstRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumAllocationInvestmentAmountCurrencyFirstRange(String value) {
        this.minimumAllocationInvestmentAmountCurrencyFirstRange = value;
    }

    /**
     * ��ȡminimumAllocationInvestmentAmountCurrencySecondRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumAllocationInvestmentAmountCurrencySecondRange() {
        return minimumAllocationInvestmentAmountCurrencySecondRange;
    }

    /**
     * ����minimumAllocationInvestmentAmountCurrencySecondRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumAllocationInvestmentAmountCurrencySecondRange(String value) {
        this.minimumAllocationInvestmentAmountCurrencySecondRange = value;
    }

    /**
     * ��ȡminimumAllocationInvestmentAmountFirstRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentAmountFirstRange() {
        return minimumAllocationInvestmentAmountFirstRange;
    }

    /**
     * ����minimumAllocationInvestmentAmountFirstRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentAmountFirstRange(BigDecimal value) {
        this.minimumAllocationInvestmentAmountFirstRange = value;
    }

    /**
     * ��ȡminimumAllocationInvestmentAmountSecondRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentAmountSecondRange() {
        return minimumAllocationInvestmentAmountSecondRange;
    }

    /**
     * ����minimumAllocationInvestmentAmountSecondRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentAmountSecondRange(BigDecimal value) {
        this.minimumAllocationInvestmentAmountSecondRange = value;
    }

    /**
     * ��ȡminimumAllocationInvestmentPercentFirstRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentPercentFirstRange() {
        return minimumAllocationInvestmentPercentFirstRange;
    }

    /**
     * ����minimumAllocationInvestmentPercentFirstRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentPercentFirstRange(BigDecimal value) {
        this.minimumAllocationInvestmentPercentFirstRange = value;
    }

    /**
     * ��ȡminimumAllocationInvestmentPercentSecondRange���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMinimumAllocationInvestmentPercentSecondRange() {
        return minimumAllocationInvestmentPercentSecondRange;
    }

    /**
     * ����minimumAllocationInvestmentPercentSecondRange���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumAllocationInvestmentPercentSecondRange(BigDecimal value) {
        this.minimumAllocationInvestmentPercentSecondRange = value;
    }

}
