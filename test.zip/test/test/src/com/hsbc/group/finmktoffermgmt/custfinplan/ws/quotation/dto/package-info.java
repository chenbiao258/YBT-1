@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.quotation.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.quotation.dto;
