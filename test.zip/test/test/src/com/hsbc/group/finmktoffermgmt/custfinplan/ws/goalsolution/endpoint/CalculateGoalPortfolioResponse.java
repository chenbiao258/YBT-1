
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateGoalPortfolioWSResponse;


/**
 * <p>calculateGoalPortfolioResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateGoalPortfolioResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="return" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateGoalPortfolioWSResponse" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateGoalPortfolioResponse", propOrder = {
    "_return"
})
public class CalculateGoalPortfolioResponse {

    @XmlElement(name = "return")
    protected CalculateGoalPortfolioWSResponse _return;

    /**
     * ��ȡreturn���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CalculateGoalPortfolioWSResponse }
     *     
     */
    public CalculateGoalPortfolioWSResponse getReturn() {
        return _return;
    }

    /**
     * ����return���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateGoalPortfolioWSResponse }
     *     
     */
    public void setReturn(CalculateGoalPortfolioWSResponse value) {
        this._return = value;
    }

}
