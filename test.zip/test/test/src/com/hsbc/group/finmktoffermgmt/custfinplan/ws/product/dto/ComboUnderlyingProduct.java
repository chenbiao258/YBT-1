
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>comboUnderlyingProduct complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="comboUnderlyingProduct"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="eligibilityResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibilityResult" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="eligibleWrapper" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibleWrapper" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="investProductFeature" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}investProductFeature" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productAmount" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}currencyAmount" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productAttribute" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productDocument" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productKey" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productKey" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "comboUnderlyingProduct", propOrder = {
    "eligibilityResult",
    "eligibleWrapper",
    "investProductFeature",
    "productAmount",
    "productAttribute",
    "productDocument",
    "productKey"
})
public class ComboUnderlyingProduct {

    @XmlElement(nillable = true)
    protected List<EligibilityResult> eligibilityResult;
    @XmlElement(nillable = true)
    protected List<EligibleWrapper> eligibleWrapper;
    @XmlElement(nillable = true)
    protected List<InvestProductFeature> investProductFeature;
    @XmlElement(nillable = true)
    protected List<CurrencyAmount> productAmount;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productAttribute;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productDocument;
    @XmlElement(nillable = true)
    protected List<ProductKey> productKey;

    /**
     * Gets the value of the eligibilityResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibilityResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibilityResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibilityResult }
     * 
     * 
     */
    public List<EligibilityResult> getEligibilityResult() {
        if (eligibilityResult == null) {
            eligibilityResult = new ArrayList<EligibilityResult>();
        }
        return this.eligibilityResult;
    }

    /**
     * Gets the value of the eligibleWrapper property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibleWrapper property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibleWrapper().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibleWrapper }
     * 
     * 
     */
    public List<EligibleWrapper> getEligibleWrapper() {
        if (eligibleWrapper == null) {
            eligibleWrapper = new ArrayList<EligibleWrapper>();
        }
        return this.eligibleWrapper;
    }

    /**
     * Gets the value of the investProductFeature property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investProductFeature property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestProductFeature().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestProductFeature }
     * 
     * 
     */
    public List<InvestProductFeature> getInvestProductFeature() {
        if (investProductFeature == null) {
            investProductFeature = new ArrayList<InvestProductFeature>();
        }
        return this.investProductFeature;
    }

    /**
     * Gets the value of the productAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAmount }
     * 
     * 
     */
    public List<CurrencyAmount> getProductAmount() {
        if (productAmount == null) {
            productAmount = new ArrayList<CurrencyAmount>();
        }
        return this.productAmount;
    }

    /**
     * Gets the value of the productAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductAttribute() {
        if (productAttribute == null) {
            productAttribute = new ArrayList<ProductAttribute>();
        }
        return this.productAttribute;
    }

    /**
     * Gets the value of the productDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductDocument() {
        if (productDocument == null) {
            productDocument = new ArrayList<ProductAttribute>();
        }
        return this.productDocument;
    }

    /**
     * Gets the value of the productKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductKey }
     * 
     * 
     */
    public List<ProductKey> getProductKey() {
        if (productKey == null) {
            productKey = new ArrayList<ProductKey>();
        }
        return this.productKey;
    }

}
