
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.endpoint;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.endpoint package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CalculateFinancialSituationData_QNAME = new QName("http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateFinancialSituationData");
    private final static QName _CalculateFinancialSituationDataResponse_QNAME = new QName("http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "calculateFinancialSituationDataResponse");
    private final static QName _RecordFinancialSituationData_QNAME = new QName("http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordFinancialSituationData");
    private final static QName _RecordFinancialSituationDataResponse_QNAME = new QName("http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "recordFinancialSituationDataResponse");
    private final static QName _RetrieveFinancialSituationData_QNAME = new QName("http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveFinancialSituationData");
    private final static QName _RetrieveFinancialSituationDataResponse_QNAME = new QName("http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", "retrieveFinancialSituationDataResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.endpoint
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CalculateFinancialSituationData }
     * 
     */
    public CalculateFinancialSituationData createCalculateFinancialSituationData() {
        return new CalculateFinancialSituationData();
    }

    /**
     * Create an instance of {@link CalculateFinancialSituationDataResponse }
     * 
     */
    public CalculateFinancialSituationDataResponse createCalculateFinancialSituationDataResponse() {
        return new CalculateFinancialSituationDataResponse();
    }

    /**
     * Create an instance of {@link RecordFinancialSituationData }
     * 
     */
    public RecordFinancialSituationData createRecordFinancialSituationData() {
        return new RecordFinancialSituationData();
    }

    /**
     * Create an instance of {@link RecordFinancialSituationDataResponse }
     * 
     */
    public RecordFinancialSituationDataResponse createRecordFinancialSituationDataResponse() {
        return new RecordFinancialSituationDataResponse();
    }

    /**
     * Create an instance of {@link RetrieveFinancialSituationData }
     * 
     */
    public RetrieveFinancialSituationData createRetrieveFinancialSituationData() {
        return new RetrieveFinancialSituationData();
    }

    /**
     * Create an instance of {@link RetrieveFinancialSituationDataResponse }
     * 
     */
    public RetrieveFinancialSituationDataResponse createRetrieveFinancialSituationDataResponse() {
        return new RetrieveFinancialSituationDataResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateFinancialSituationData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateFinancialSituationData")
    public JAXBElement<CalculateFinancialSituationData> createCalculateFinancialSituationData(CalculateFinancialSituationData value) {
        return new JAXBElement<CalculateFinancialSituationData>(_CalculateFinancialSituationData_QNAME, CalculateFinancialSituationData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculateFinancialSituationDataResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "calculateFinancialSituationDataResponse")
    public JAXBElement<CalculateFinancialSituationDataResponse> createCalculateFinancialSituationDataResponse(CalculateFinancialSituationDataResponse value) {
        return new JAXBElement<CalculateFinancialSituationDataResponse>(_CalculateFinancialSituationDataResponse_QNAME, CalculateFinancialSituationDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordFinancialSituationData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordFinancialSituationData")
    public JAXBElement<RecordFinancialSituationData> createRecordFinancialSituationData(RecordFinancialSituationData value) {
        return new JAXBElement<RecordFinancialSituationData>(_RecordFinancialSituationData_QNAME, RecordFinancialSituationData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordFinancialSituationDataResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "recordFinancialSituationDataResponse")
    public JAXBElement<RecordFinancialSituationDataResponse> createRecordFinancialSituationDataResponse(RecordFinancialSituationDataResponse value) {
        return new JAXBElement<RecordFinancialSituationDataResponse>(_RecordFinancialSituationDataResponse_QNAME, RecordFinancialSituationDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveFinancialSituationData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveFinancialSituationData")
    public JAXBElement<RetrieveFinancialSituationData> createRetrieveFinancialSituationData(RetrieveFinancialSituationData value) {
        return new JAXBElement<RetrieveFinancialSituationData>(_RetrieveFinancialSituationData_QNAME, RetrieveFinancialSituationData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveFinancialSituationDataResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://endpoint.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/", name = "retrieveFinancialSituationDataResponse")
    public JAXBElement<RetrieveFinancialSituationDataResponse> createRetrieveFinancialSituationDataResponse(RetrieveFinancialSituationDataResponse value) {
        return new JAXBElement<RetrieveFinancialSituationDataResponse>(_RetrieveFinancialSituationDataResponse_QNAME, RetrieveFinancialSituationDataResponse.class, null, value);
    }

}
