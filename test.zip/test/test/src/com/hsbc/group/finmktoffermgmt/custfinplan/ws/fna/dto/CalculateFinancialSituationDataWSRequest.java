
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.customer.dto.Customer;
import com.hsbc.swp.common.ws.dto.WebServiceRequest;


/**
 * <p>calculateFinancialSituationDataWSRequest complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateFinancialSituationDataWSRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceRequest"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="assets" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assets" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="calculationRequest" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculationRequest" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="customers" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="expense" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}expense" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="income" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}income" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="jointCustomer" type="{http://dto.customer.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}customer" minOccurs="0"/&gt;
 *         &lt;element name="liability" type="{http://dto.fna.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}liability" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateFinancialSituationDataWSRequest", propOrder = {
    "assets",
    "calculationRequest",
    "customers",
    "expense",
    "income",
    "jointCustomer",
    "liability"
})
public class CalculateFinancialSituationDataWSRequest
    extends WebServiceRequest
{

    @XmlElement(nillable = true)
    protected List<Assets> assets;
    @XmlElement(nillable = true)
    protected List<CalculationRequest> calculationRequest;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<Expense> expense;
    @XmlElement(nillable = true)
    protected List<Income> income;
    protected Customer jointCustomer;
    @XmlElement(nillable = true)
    protected List<Liability> liability;

    /**
     * Gets the value of the assets property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assets property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssets().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Assets }
     * 
     * 
     */
    public List<Assets> getAssets() {
        if (assets == null) {
            assets = new ArrayList<Assets>();
        }
        return this.assets;
    }

    /**
     * Gets the value of the calculationRequest property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the calculationRequest property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCalculationRequest().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CalculationRequest }
     * 
     * 
     */
    public List<CalculationRequest> getCalculationRequest() {
        if (calculationRequest == null) {
            calculationRequest = new ArrayList<CalculationRequest>();
        }
        return this.calculationRequest;
    }

    /**
     * Gets the value of the customers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Customer }
     * 
     * 
     */
    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }

    /**
     * Gets the value of the expense property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the expense property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExpense().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Expense }
     * 
     * 
     */
    public List<Expense> getExpense() {
        if (expense == null) {
            expense = new ArrayList<Expense>();
        }
        return this.expense;
    }

    /**
     * Gets the value of the income property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the income property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Income }
     * 
     * 
     */
    public List<Income> getIncome() {
        if (income == null) {
            income = new ArrayList<Income>();
        }
        return this.income;
    }

    /**
     * ��ȡjointCustomer���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    public Customer getJointCustomer() {
        return jointCustomer;
    }

    /**
     * ����jointCustomer���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    public void setJointCustomer(Customer value) {
        this.jointCustomer = value;
    }

    /**
     * Gets the value of the liability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the liability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLiability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Liability }
     * 
     * 
     */
    public List<Liability> getLiability() {
        if (liability == null) {
            liability = new ArrayList<Liability>();
        }
        return this.liability;
    }

}
