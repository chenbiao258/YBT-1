
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>portfolioAssetAllocation complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="portfolioAssetAllocation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="portfolioAssetAllocationDetails" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}portfolioAssetAllocationDetail" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="portfolioTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "portfolioAssetAllocation", propOrder = {
    "portfolioAssetAllocationDetails",
    "portfolioTypeCode"
})
public class PortfolioAssetAllocation {

    @XmlElement(nillable = true)
    protected List<PortfolioAssetAllocationDetail> portfolioAssetAllocationDetails;
    protected String portfolioTypeCode;

    /**
     * Gets the value of the portfolioAssetAllocationDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the portfolioAssetAllocationDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPortfolioAssetAllocationDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PortfolioAssetAllocationDetail }
     * 
     * 
     */
    public List<PortfolioAssetAllocationDetail> getPortfolioAssetAllocationDetails() {
        if (portfolioAssetAllocationDetails == null) {
            portfolioAssetAllocationDetails = new ArrayList<PortfolioAssetAllocationDetail>();
        }
        return this.portfolioAssetAllocationDetails;
    }

    /**
     * ��ȡportfolioTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPortfolioTypeCode() {
        return portfolioTypeCode;
    }

    /**
     * ����portfolioTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPortfolioTypeCode(String value) {
        this.portfolioTypeCode = value;
    }

}
