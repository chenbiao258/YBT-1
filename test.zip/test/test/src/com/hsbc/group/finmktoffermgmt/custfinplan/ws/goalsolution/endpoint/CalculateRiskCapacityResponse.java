
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.CalculateRiskCapacityWSResponse;


/**
 * <p>calculateRiskCapacityResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateRiskCapacityResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="return" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}calculateRiskCapacityWSResponse" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateRiskCapacityResponse", propOrder = {
    "_return"
})
public class CalculateRiskCapacityResponse {

    @XmlElement(name = "return")
    protected CalculateRiskCapacityWSResponse _return;

    /**
     * ��ȡreturn���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link CalculateRiskCapacityWSResponse }
     *     
     */
    public CalculateRiskCapacityWSResponse getReturn() {
        return _return;
    }

    /**
     * ����return���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link CalculateRiskCapacityWSResponse }
     *     
     */
    public void setReturn(CalculateRiskCapacityWSResponse value) {
        this._return = value;
    }

}
