
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.fna.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>additionalSituation complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="additionalSituation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="periodicityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="situationAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="situationCategoryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="situationCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="situationTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "additionalSituation", propOrder = {
    "periodicityCode",
    "situationAmount",
    "situationCategoryCode",
    "situationCurrencyCode",
    "situationTypeCode"
})
public class AdditionalSituation {

    protected String periodicityCode;
    protected BigDecimal situationAmount;
    protected String situationCategoryCode;
    protected String situationCurrencyCode;
    protected String situationTypeCode;

    /**
     * ��ȡperiodicityCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicityCode() {
        return periodicityCode;
    }

    /**
     * ����periodicityCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicityCode(String value) {
        this.periodicityCode = value;
    }

    /**
     * ��ȡsituationAmount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSituationAmount() {
        return situationAmount;
    }

    /**
     * ����situationAmount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSituationAmount(BigDecimal value) {
        this.situationAmount = value;
    }

    /**
     * ��ȡsituationCategoryCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituationCategoryCode() {
        return situationCategoryCode;
    }

    /**
     * ����situationCategoryCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituationCategoryCode(String value) {
        this.situationCategoryCode = value;
    }

    /**
     * ��ȡsituationCurrencyCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituationCurrencyCode() {
        return situationCurrencyCode;
    }

    /**
     * ����situationCurrencyCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituationCurrencyCode(String value) {
        this.situationCurrencyCode = value;
    }

    /**
     * ��ȡsituationTypeCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituationTypeCode() {
        return situationTypeCode;
    }

    /**
     * ����situationTypeCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituationTypeCode(String value) {
        this.situationTypeCode = value;
    }

}
