
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.product.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.AccountAttribute;


/**
 * <p>selectedProduct complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="selectedProduct"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountAttribute" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}accountAttribute" minOccurs="0"/&gt;
 *         &lt;element name="eligibilityResult" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}eligibilityResult" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productAssetAllocation" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAssetAllocation" minOccurs="0"/&gt;
 *         &lt;element name="productAttribute" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productAttribute" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="productKey" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}productKey" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="quoteDetail" type="{http://dto.product.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}quoteDetail" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "selectedProduct", propOrder = {
    "accountAttribute",
    "eligibilityResult",
    "productAssetAllocation",
    "productAttribute",
    "productKey",
    "quoteDetail"
})
public class SelectedProduct {

    protected AccountAttribute accountAttribute;
    @XmlElement(nillable = true)
    protected List<EligibilityResult> eligibilityResult;
    protected ProductAssetAllocation productAssetAllocation;
    @XmlElement(nillable = true)
    protected List<ProductAttribute> productAttribute;
    @XmlElement(nillable = true)
    protected List<ProductKey> productKey;
    protected QuoteDetail quoteDetail;

    /**
     * ��ȡaccountAttribute���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link AccountAttribute }
     *     
     */
    public AccountAttribute getAccountAttribute() {
        return accountAttribute;
    }

    /**
     * ����accountAttribute���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link AccountAttribute }
     *     
     */
    public void setAccountAttribute(AccountAttribute value) {
        this.accountAttribute = value;
    }

    /**
     * Gets the value of the eligibilityResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eligibilityResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEligibilityResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EligibilityResult }
     * 
     * 
     */
    public List<EligibilityResult> getEligibilityResult() {
        if (eligibilityResult == null) {
            eligibilityResult = new ArrayList<EligibilityResult>();
        }
        return this.eligibilityResult;
    }

    /**
     * ��ȡproductAssetAllocation���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ProductAssetAllocation }
     *     
     */
    public ProductAssetAllocation getProductAssetAllocation() {
        return productAssetAllocation;
    }

    /**
     * ����productAssetAllocation���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ProductAssetAllocation }
     *     
     */
    public void setProductAssetAllocation(ProductAssetAllocation value) {
        this.productAssetAllocation = value;
    }

    /**
     * Gets the value of the productAttribute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productAttribute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductAttribute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAttribute }
     * 
     * 
     */
    public List<ProductAttribute> getProductAttribute() {
        if (productAttribute == null) {
            productAttribute = new ArrayList<ProductAttribute>();
        }
        return this.productAttribute;
    }

    /**
     * Gets the value of the productKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductKey }
     * 
     * 
     */
    public List<ProductKey> getProductKey() {
        if (productKey == null) {
            productKey = new ArrayList<ProductKey>();
        }
        return this.productKey;
    }

    /**
     * ��ȡquoteDetail���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link QuoteDetail }
     *     
     */
    public QuoteDetail getQuoteDetail() {
        return quoteDetail;
    }

    /**
     * ����quoteDetail���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link QuoteDetail }
     *     
     */
    public void setQuoteDetail(QuoteDetail value) {
        this.quoteDetail = value;
    }

}
