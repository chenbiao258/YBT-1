
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>declaration complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="declaration"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="declarationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="declarationValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="reasonDeclarationText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="reasonDeclarationTextSize" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "declaration", propOrder = {
    "declarationCode",
    "declarationValue",
    "reasonDeclarationText",
    "reasonDeclarationTextSize"
})
public class Declaration {

    protected String declarationCode;
    protected String declarationValue;
    protected String reasonDeclarationText;
    protected int reasonDeclarationTextSize;

    /**
     * ��ȡdeclarationCode���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclarationCode() {
        return declarationCode;
    }

    /**
     * ����declarationCode���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclarationCode(String value) {
        this.declarationCode = value;
    }

    /**
     * ��ȡdeclarationValue���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclarationValue() {
        return declarationValue;
    }

    /**
     * ����declarationValue���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclarationValue(String value) {
        this.declarationValue = value;
    }

    /**
     * ��ȡreasonDeclarationText���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonDeclarationText() {
        return reasonDeclarationText;
    }

    /**
     * ����reasonDeclarationText���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonDeclarationText(String value) {
        this.reasonDeclarationText = value;
    }

    /**
     * ��ȡreasonDeclarationTextSize���Ե�ֵ��
     * 
     */
    public int getReasonDeclarationTextSize() {
        return reasonDeclarationTextSize;
    }

    /**
     * ����reasonDeclarationTextSize���Ե�ֵ��
     * 
     */
    public void setReasonDeclarationTextSize(int value) {
        this.reasonDeclarationTextSize = value;
    }

}
