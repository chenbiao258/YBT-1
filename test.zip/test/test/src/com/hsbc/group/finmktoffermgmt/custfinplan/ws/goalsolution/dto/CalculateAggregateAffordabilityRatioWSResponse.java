
package com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.ValidationResult;
import com.hsbc.swp.common.ws.dto.WebServiceResponse;


/**
 * <p>calculateAggregateAffordabilityRatioWSResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="calculateAggregateAffordabilityRatioWSResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://dto.ws.common.swp.hsbc.com/}webServiceResponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="affordability" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordability" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="affordabilityValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}affordabilityValidation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assetConcentration" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentration" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="assetConcentrationValidation" type="{http://dto.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}assetConcentrationValidation" maxOccurs="999" minOccurs="0"/&gt;
 *         &lt;element name="validationResult" type="{http://endpoint.goalsolution.ws.custfinplan.finmktoffermgmt.group.hsbc.com/}validationResult" maxOccurs="999" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "calculateAggregateAffordabilityRatioWSResponse", propOrder = {
    "affordability",
    "affordabilityValidation",
    "assetConcentration",
    "assetConcentrationValidation",
    "validationResult"
})
public class CalculateAggregateAffordabilityRatioWSResponse
    extends WebServiceResponse
{

    @XmlElement(nillable = true)
    protected List<Affordability> affordability;
    @XmlElement(nillable = true)
    protected List<AffordabilityValidation> affordabilityValidation;
    @XmlElement(nillable = true)
    protected List<AssetConcentration> assetConcentration;
    @XmlElement(nillable = true)
    protected List<AssetConcentrationValidation> assetConcentrationValidation;
    @XmlElement(nillable = true)
    protected List<ValidationResult> validationResult;

    /**
     * Gets the value of the affordability property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordability property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordability().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Affordability }
     * 
     * 
     */
    public List<Affordability> getAffordability() {
        if (affordability == null) {
            affordability = new ArrayList<Affordability>();
        }
        return this.affordability;
    }

    /**
     * Gets the value of the affordabilityValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affordabilityValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffordabilityValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AffordabilityValidation }
     * 
     * 
     */
    public List<AffordabilityValidation> getAffordabilityValidation() {
        if (affordabilityValidation == null) {
            affordabilityValidation = new ArrayList<AffordabilityValidation>();
        }
        return this.affordabilityValidation;
    }

    /**
     * Gets the value of the assetConcentration property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentration property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentration().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentration }
     * 
     * 
     */
    public List<AssetConcentration> getAssetConcentration() {
        if (assetConcentration == null) {
            assetConcentration = new ArrayList<AssetConcentration>();
        }
        return this.assetConcentration;
    }

    /**
     * Gets the value of the assetConcentrationValidation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetConcentrationValidation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetConcentrationValidation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetConcentrationValidation }
     * 
     * 
     */
    public List<AssetConcentrationValidation> getAssetConcentrationValidation() {
        if (assetConcentrationValidation == null) {
            assetConcentrationValidation = new ArrayList<AssetConcentrationValidation>();
        }
        return this.assetConcentrationValidation;
    }

    /**
     * Gets the value of the validationResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validationResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidationResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidationResult }
     * 
     * 
     */
    public List<ValidationResult> getValidationResult() {
        if (validationResult == null) {
            validationResult = new ArrayList<ValidationResult>();
        }
        return this.validationResult;
    }

}
