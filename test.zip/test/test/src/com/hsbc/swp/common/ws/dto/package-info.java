@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.ws.common.swp.hsbc.com/")
package com.hsbc.swp.common.ws.dto;
