@javax.xml.bind.annotation.XmlSchema(namespace = "http://dto.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com/")
package endpoint.custmgmt.ws.custfinplan.finmktoffermgmt.group.hsbc.com;
