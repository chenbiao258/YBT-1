package test.com;

import tool.XmlTool;

import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSRequest;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.dto.RetrieveGoalSolutionDetailWSResponse;
import com.hsbc.group.finmktoffermgmt.custfinplan.ws.goalsolution.endpoint.GoalSolutionWebServiceEndpoint_Service;

public class GoalId {	
	/**
	 * 方法描述：发送webservice请求
	 * @param path XML文件路径
	 * @return goalTypeCode
	 * @throws Exception
	 */
	public String getTypeCode(String path) throws Exception{
		XmlTool xmlTool = new XmlTool();
		String goalTypeCode ="";
			RetrieveGoalSolutionDetailWSRequest retrieveGoalSolutionDetailWSRequest =xmlTool.getGoalIdXml(path);
			RetrieveGoalSolutionDetailWSResponse rs=this.getConn(retrieveGoalSolutionDetailWSRequest);			
			if(rs!=null){
				if(rs.getGoalSummary()!=null&&rs.getGoalSummary().size()>0){
					if(rs.getGoalSummary().get(0)!=null){
						if(rs.getGoalSummary().get(0).getFinancialGoal()!=null){
							goalTypeCode =rs.getGoalSummary().get(0).getFinancialGoal().getGoalTypeCode(); 	
						}
					}
				}
			};

		return goalTypeCode;
		}	
	/**
	 * 方法描述：获取webservice链接
	 * @param retrieveGoalSolutionDetailWSRequest  自定义请求对象
	 * @return RetrieveGoalSolutionDetailWSResponse 返回自定义类型对象
	 */
	private RetrieveGoalSolutionDetailWSResponse getConn(RetrieveGoalSolutionDetailWSRequest retrieveGoalSolutionDetailWSRequest){
		GoalSolutionWebServiceEndpoint_Service gs =new GoalSolutionWebServiceEndpoint_Service();
		RetrieveGoalSolutionDetailWSResponse retrieveGoalSolutionDetailWSResponse =null;
		if(gs.getGoalSolutionWebServiceEndpointPort()!=null){
			retrieveGoalSolutionDetailWSResponse=gs.getGoalSolutionWebServiceEndpointPort().retrieveGoalSolutionDetail(retrieveGoalSolutionDetailWSRequest);
		}
		return retrieveGoalSolutionDetailWSResponse;
	}
	
}
