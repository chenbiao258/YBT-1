package test.com;

import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;

public class WebServiceTest {
	public String invokeRemoteFuc(String method,String xmlText) {
		String endpoint = "http://uat-wealth-fps-hbcn.hk.hsbc:30001/fps-ws-web/GoalSolutionWebServiceEndpoint";
//		String endpoint = "http://192.168.8.107:8080/YBT_webService/services/WMSService?wsdl";
//		String endpoint = "http://192.168.8.101:8080/new_eservice_business/ybt/HelloWorld?wsdl";
		
		
		return endpoint;
	}
	public static void main(String[] args) {
		WebServiceTest webServiceTest =new WebServiceTest();		
//		String xmlString=XmlUtil.xmlChangeString("com/file/retrieveGoalSolutionDetail_sample_request.xml");
		String xmlString="qiubin";
		if(xmlString!=null){
			System.out.println(webServiceTest.invokeRemoteFuc("retrieveGoalSolutionDetail", xmlString));
		}
		
	}
}
