prompt Importing table regionall...
set feedback off
set define off
insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHK, SHH', 'EAR', 'SHH', 'SHK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHN, SHH', 'EAR', 'SHH', 'SHN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHT, SHH', 'EAR', 'SHH', 'SHT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHU, SHH', 'EAR', 'SHH', 'SHU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHY, SHH', 'EAR', 'SHH', 'SHY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SJK, SHH', 'EAR', 'SHH', 'SJK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SKP, SHH', 'EAR', 'SHH', 'SKP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SLY, SHH', 'EAR', 'SHH', 'SLY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SNI, SUZ', 'EAR', 'SUZ', 'SNI');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - STA, SZN', 'SOR', 'SZN', 'STA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - STK, SHH', 'EAR', 'SHH', 'STK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SUS, SUZ', 'EAR', 'SUZ', 'SUS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SYH, SYA', 'NOR', 'SYA', 'SYH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SYW, SYA', 'NOR', 'SYA', 'SYW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SZF, SZN', 'SOR', 'SZN', 'SZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SZJ, SZN', 'SOR', 'SZN', 'SZJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SZM, SZN', 'SOR', 'SZN', 'SZM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SZO, SZN', 'SOR', 'SZN', 'SZO');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SZQ, SZN', 'SOR', 'SZN', 'SZQ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SZU, GZH', 'SOR', 'GZH', 'SZU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - TIB, TJN', 'NOR', 'TJN', 'TIB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - TJB, TJN', 'NOR', 'TJN', 'TJB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - TJH, TJN', 'NOR', 'TJN', 'TJH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - WHZ, WUN', 'EAR', 'WUN', 'WHZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - WNW, WUN', 'EAR', 'WUN', 'WNW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - XAX, XAN', 'NOR', 'XAN', 'XAX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - XBI, XIA', 'EAR', 'XIA', 'XBI');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - XJA, XIA', 'EAR', 'XIA', 'XJA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - XMH, XIA', 'EAR', 'XIA', 'XMH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - ZGC, BJG', 'NOR', 'BJG', 'ZGC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, BJG', 'NOR', 'BJG', 'BJG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, DNG', 'SOR', 'DNG', 'DNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, GZF', 'SOR', 'GZF', 'GZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, GZH', 'SOR', 'GZH', 'GZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, HAZ', 'EAR', 'HAZ', 'HAZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, HEF', 'EAR', 'HEF', 'HEF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, JIN', 'NOR', 'JIN', 'JIN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, NGB', 'EAR', 'NGB', 'NGB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, SYA', 'NOR', 'SYA', 'SYA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier, TYU', 'NOR', 'TYU', 'TYU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM RBB Distribution, GZF', 'RBB', 'GZF', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM RBB Distribution, GZH', 'RBB', 'GZH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM RBB Distribution, SZN', 'RBB', 'SZN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM RBB Distribution,DNG', 'RBB', 'DNG', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BCP, BJG', 'NOR', 'BJG', 'BCP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BCU, BJG', 'NOR', 'BJG', 'BCU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BGH, BJG', 'NOR', 'BJG', 'BGH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BHM, BJG', 'NOR', 'BJG', 'BHM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BJD, BJG', 'NOR', 'BJG', 'BJD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BJU, BJG', 'NOR', 'BJG', 'BJU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BJY, BJG', 'NOR', 'BJG', 'BJY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BLC, BJG', 'NOR', 'BJG', 'BLC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BLD, BJG', 'NOR', 'BJG', 'BLD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BNS, BJG', 'NOR', 'BJG', 'BNS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BTP, BJG', 'NOR', 'BJG', 'BTP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BWI, BJG', 'NOR', 'BJG', 'BWI');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BWJ, BJG', 'NOR', 'BJG', 'BWJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - BZW, BJG', 'NOR', 'BJG', 'BZW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - CDJ, CGU', 'NOR', 'CGU', 'CDJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - CDL, CGU', 'NOR', 'CGU', 'CDL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - CQB, CQG', 'NOR', 'CQG', 'CQB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - CQH, CQG', 'NOR', 'CQG', 'CQH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - CQS, CQG', 'NOR', 'CQG', 'CQS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - CSG, CGU', 'NOR', 'CGU', 'CSG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DCZ, DNG', 'SOR', 'DNG', 'DCZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DDF, DNG', 'SOR', 'DNG', 'DDF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DHM, DNG', 'SOR', 'DNG', 'DHM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DHZ, DNG', 'SOR', 'DNG', 'DHZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DJY, DNG', 'SOR', 'DNG', 'DJY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DLH, DNG', 'SOR', 'DNG', 'DLH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DLP, DLN', 'NOR', 'DLN', 'DLP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DLS, DLN', 'NOR', 'DLN', 'DLS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DMZ, DNG', 'SOR', 'DNG', 'DMZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DPP, DLN', 'NOR', 'DLN', 'DPP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DST, DNG', 'SOR', 'DNG', 'DST');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DSW, DNG', 'SOR', 'DNG', 'DSW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DYB, DNG', 'SOR', 'DNG', 'DYB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - DZK, DNG', 'SOR', 'DNG', 'DZK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GCC, GZF', 'SOR', 'GZF', 'GCC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GCH, GZH', 'SOR', 'GZH', 'GCH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GDR, GZF', 'SOR', 'GZF', 'GDR');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GDS, GZH', 'SOR', 'GZH', 'GDS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GFN, GZF', 'SOR', 'GZF', 'GFN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GFS, GZF', 'SOR', 'GZF', 'GFS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GHA, GZH', 'SOR', 'GZH', 'GHA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GHS, GZH', 'SOR', 'GZH', 'GHS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GHY, GZH', 'SOR', 'GZH', 'GHY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GJH, GZH', 'SOR', 'GZH', 'GJH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GJM, GZH', 'SOR', 'GZH', 'GJM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GMM, GZH', 'SOR', 'GZH', 'GMM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GPA, GZH', 'SOR', 'GZH', 'GPA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GQU, GZH', 'SOR', 'GZH', 'GQU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GQY, GZH', 'SOR', 'GZH', 'GQY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GSD, GZF', 'SOR', 'GZF', 'GSD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GSG, GZH', 'SOR', 'GZH', 'GSG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GTH, GZH', 'SOR', 'GZH', 'GTH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GTT, GZH', 'SOR', 'GZH', 'GTT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GUH, GZH', 'SOR', 'GZH', 'GUH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GXH, GZH', 'SOR', 'GZH', 'GXH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GYF, GZH', 'SOR', 'GZH', 'GYF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GZA, GZH', 'SOR', 'GZH', 'GZA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GZJ, GZH', 'SOR', 'GZH', 'GZJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GZQ, GZH', 'SOR', 'GZH', 'GZQ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - GZS, GZH', 'SOR', 'GZH', 'GZS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - HKP, SHH', 'EAR', 'SHH', 'HKP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - HRG, HAZ', 'EAR', 'HAZ', 'HRG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - HZH, HAZ', 'EAR', 'HAZ', 'HZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - IEH, SHH', 'EAR', 'SHH', 'IEH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - KRN, SHH', 'EAR', 'SHH', 'KRN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - KWC, SHH', 'EAR', 'SHH', 'KWC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - NHY, NGB', 'EAR', 'NGB', 'NHY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - NJX, NJN', 'EAR', 'NJN', 'NJX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - PUD, SHH', 'EAR', 'SHH', 'PUD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - QHG, QDO', 'NOR', 'QDO', 'QHG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - QSD, QDO', 'NOR', 'QDO', 'QSD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - RGL, SHH', 'EAR', 'SHH', 'RGL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SAF, SHH', 'EAR', 'SHH', 'SAF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SCR, SHH', 'EAR', 'SHH', 'SCR');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SCT, SHH', 'EAR', 'SHH', 'SCT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SCX, SHH', 'EAR', 'SHH', 'SCX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SEC, SZN', 'SOR', 'SZN', 'SEC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SFL, SUZ', 'EAR', 'SUZ', 'SFL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SGB, SHH', 'EAR', 'SHH', 'SGB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SGC, SZN', 'SOR', 'SZN', 'SGC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SGL, SZN', 'SOR', 'SZN', 'SGL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SGO, GZH', 'SOR', 'GZH', 'SGO');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SGS, GZH', 'SOR', 'GZH', 'SGS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHB, SHH', 'EAR', 'SHH', 'SHB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHC, SHH', 'EAR', 'SHH', 'SHC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHD, SHH', 'EAR', 'SHH', 'SHD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHF, SHH', 'EAR', 'SHH', 'SHF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHK, SHH', 'EAR', 'SHH', 'SHK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHN, SHH', 'EAR', 'SHH', 'SHN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHT, SHH', 'EAR', 'SHH', 'SHT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHU, SHH', 'EAR', 'SHH', 'SHU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHY, SHH', 'EAR', 'SHH', 'SHY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SHZ, SHH', 'EAR', 'SHH', 'SHZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SJK, SHH', 'EAR', 'SHH', 'SJK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SKP, SHH', 'EAR', 'SHH', 'SKP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SKS, SUZ', 'EAR', 'SUZ', 'SKS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SLH, GZH', 'SOR', 'GZH', 'SLH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SLY, SHH', 'EAR', 'SHH', 'SLY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SNI, SUZ', 'EAR', 'SUZ', 'SNI');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SPN, SHH', 'EAR', 'SHH', 'SPN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SQH, SZN', 'SOR', 'SZN', 'SQH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - STA, SZN', 'SOR', 'SZN', 'STA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - STK, SHH', 'EAR', 'SHH', 'STK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SUS, SUZ', 'EAR', 'SUZ', 'SUS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SXL, GZH', 'SOR', 'GZH', 'SXL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SYH, SYA', 'NOR', 'SYA', 'SYH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SYW, SYA', 'NOR', 'SYA', 'SYW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SZF, SZN', 'SOR', 'SZN', 'SZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SZJ, SZN', 'SOR', 'SZN', 'SZJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SZM, SZN', 'SOR', 'SZN', 'SZM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SZO, SZN', 'SOR', 'SZN', 'SZO');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SZQ, SZN', 'SOR', 'SZN', 'SZQ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - SZU, GZH', 'SOR', 'GZH', 'SZU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - TIB, TJN', 'NOR', 'TJN', 'TIB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - TJB, TJN', 'NOR', 'TJN', 'TJB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - TJH, TJN', 'NOR', 'TJN', 'TJH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - WHZ, WUN', 'EAR', 'WUN', 'WHZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - WNW, WUN', 'EAR', 'WUN', 'WNW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - XAK, XAN', 'NOR', 'XAN', 'XAK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - XAX, XAN', 'NOR', 'XAN', 'XAX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - XBI, XIA', 'EAR', 'XIA', 'XBI');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - XJA, XIA', 'EAR', 'XIA', 'XJA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - XMH, XIA', 'EAR', 'XIA', 'XMH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail - ZGC, BJG', 'NOR', 'BJG', 'ZGC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, BJG', 'NOR', 'BJG', 'BJG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, CNG', 'EAR', 'CNG', 'CNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, DNG', 'SOR', 'DNG', 'DNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, GZF', 'SOR', 'GZF', 'GZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, GZH', 'SOR', 'GZH', 'GZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, HAZ', 'EAR', 'HAZ', 'HAZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, HBB', 'NOR', 'HBB', 'HBB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, HEF', 'EAR', 'HEF', 'HEF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, JIN', 'NOR', 'JIN', 'JIN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, NGB', 'EAR', 'NGB', 'NGB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, QDO', 'NOR', 'QDO', 'QDO');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, SYA', 'NOR', 'SYA', 'SYA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, TGH', 'NOR', 'TGH', 'TGH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, TYU', 'NOR', 'TYU', 'TYU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, WUX', 'EAR', 'WUX', 'WUX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, XIA', 'EAR', 'XIA', 'XIA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Retail, ZHE', 'NOR', 'ZHE', 'ZHE');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales - NGB', 'Wealth Sales', 'NGB', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales - QDO', 'Wealth Sales', 'QDO', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales - TJN', 'Wealth Sales', 'TJN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, BJG', 'Wealth Sales', 'BJG', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, DLN', 'Wealth Sales', 'DLN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, GZH', 'Wealth Sales', 'GZH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, HAZ', 'Wealth Sales', 'HAZ', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, SHH', 'Wealth Sales', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, SUZ', 'Wealth Sales', 'SUZ', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Wealth Sales, SZN', 'Wealth Sales', 'SZN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services JIN', 'NOR', 'JIN', 'JIN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services KUM', 'NOR', 'KUM', 'KUM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services TYU', 'NOR', 'TYU', 'TYU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services WUN', 'EAR', 'WUN', 'WUN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services ZHE', 'NOR', 'ZHE', 'ZHE');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services, CGU', 'NOR', 'CGU', 'CGU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Branch Counter Services, CNG', 'EAR', 'CNG', 'CNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Cards and Loans RBWM, SZN', 'Credit Card', 'SZN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('CNQ RBWM -Cards and Loans', 'Credit Card', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, BJG', 'NOR', 'BJG', 'BJG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, DLN', 'NOR', 'DLN', 'DLN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, DNG', 'SOR', 'DNG', 'DNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, GZF', 'SOR', 'GZF', 'GZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, GZH', 'SOR', 'GZH', 'GZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, HAZ', 'EAR', 'HAZ', 'HAZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, HBB', 'NOR', 'HBB', 'HBB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, HEF', 'EAR', 'HEF', 'HEF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, NGB', 'EAR', 'NGB', 'NGB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, NJN', 'EAR', 'NJN', 'NJN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, QDO', 'NOR', 'QDO', 'QDO');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, SUZ', 'EAR', 'SUZ', 'SUZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, SYA', 'NOR', 'SYA', 'SYA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, TGH', 'NOR', 'TGH', 'TGH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, TJN', 'NOR', 'TJN', 'TJN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, WUX', 'EAR', 'WUX', 'WUX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services, XIA', 'EAR', 'XIA', 'XIA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DCZ, DNG', 'SOR', 'DNG', 'DCZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DHM, DNG', 'SOR', 'DNG', 'DHM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DHZ, DNG', 'SOR', 'DNG', 'DHZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DJY, DNG', 'SOR', 'DNG', 'DJY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DLH, DNG', 'SOR', 'DNG', 'DLH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DMZ, DNG', 'SOR', 'DNG', 'DMZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DST, DNG', 'SOR', 'DNG', 'DST');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DSW, DNG', 'SOR', 'DNG', 'DSW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-DZK, DNG', 'SOR', 'DNG', 'DZK');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GCC, GZF', 'SOR', 'GZF', 'GCC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GDR, GZF', 'SOR', 'GZF', 'GDR');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GFS, GZF', 'SOR', 'GZF', 'GFS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GHA, GZH', 'SOR', 'GZH', 'GHA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GHY, GZH', 'SOR', 'GZH', 'GHY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GJM, GZH', 'SOR', 'GZH', 'GJM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GMM, GZH', 'SOR', 'GZH', 'GMM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GQU, GZH', 'SOR', 'GZH', 'GQU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GQY, GZH', 'SOR', 'GZH', 'GQY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GSD, GZF', 'SOR', 'GZF', 'GSD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GSG, GZH', 'SOR', 'GZH', 'GSG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GXH, GZH', 'SOR', 'GZH', 'GXH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GYF, GZH', 'SOR', 'GZH', 'GYF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GYJ, GZH', 'SOR', 'GZH', 'GYJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GZA, GZH', 'SOR', 'GZH', 'GZA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-GZQ, GZH', 'SOR', 'GZH', 'GZQ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-HKP, Shanghai', 'EAR', 'SHH', 'HKP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-PUD, Shanghai', 'EAR', 'SHH', 'PUD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SGS, GZH', 'SOR', 'GZH', 'SGS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SKS, SUZ', 'EAR', 'SUZ', 'SKS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SLH, GZH', 'SOR', 'GZH', 'SLH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SPN, SHH', 'EAR', 'SHH', 'SPN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SQH, SZN', 'SOR', 'SZN', 'SQH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SSQ, GZH', 'SOR', 'GZH', 'SSQ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SXL, GZH', 'SOR', 'GZH', 'SXL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('Counter Services-SZU, GZH', 'SOR', 'GZH', 'SZU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM - East Region', 'EAR', 'SHH', 'SHH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM - North Region', 'NOR', 'BJG', 'BJG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM - South Region - GZH', 'SOR', 'GZH', 'GZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM - South Region - SZN&DNG', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Advance CD - DNG', 'SOR', 'DNG', 'DNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Advance CD - SGS', 'SOR', 'GZH', 'SGS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Advance CD - SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Advance CD, GZF', 'SOR', 'GZF', 'GZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF OS, GZH', 'Credit Card', 'GZH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF OS, SZN', 'Credit Card', 'SZN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF, BJG', 'Credit Card', 'BJG', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF, GZH', 'Credit Card', 'GZH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF, NHC', 'Credit Card', 'GZF', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF, SHH', 'Credit Card', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Cards & Loans MSF, SZN', 'Credit Card', 'SZN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCS Collection, PRD, GZF', 'RCS', 'GZF', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCS Collection, PRD, GZH', 'RCS', 'GZH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCSS - Credit Card', 'CCSS', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCSS - Credit Card, GZF', 'CCSS', 'GZF', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCSS - IBC', 'CCSS', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCSS - Porfolio Mgmt', 'CCSS', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCSS PRD Banking_GZF', 'CCSS', 'GZF', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCS-UWS,PRD,GZF', 'RCS', 'GZF', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM CCS-UWS,PRD,GZH', 'RCS', 'GZH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Central MA', 'CCSS', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Contact Centre Svs&Sales', 'CCSS', 'SHH', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-GDS', 'SOR', 'GZH', 'GDS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-GTH', 'SOR', 'GZH', 'GTH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-GTT', 'SOR', 'GZH', 'GTT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-GZJ', 'SOR', 'GZH', 'GZJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-PUD', 'EAR', 'SHH', 'PUD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-SGC', 'SOR', 'SZN', 'SGC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Full Service Counters-SHC', 'EAR', 'SHH', 'SHC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML - PRD DNG', 'SOR', 'DNG', 'DNG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML - PRD GZH', 'SOR', 'GZH', 'GZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML - PRD SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML - PRD, GZF', 'SOR', 'GZF', 'GZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, BJG', 'NOR', 'BJG', 'BJG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, CGU', 'NOR', 'CGU', 'CGU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, CQG', 'NOR', 'CQG', 'CQG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, GZF', 'SOR', 'GZF', 'GZF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, GZH', 'SOR', 'GZH', 'GZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, HAZ', 'EAR', 'HAZ', 'HAZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, NGB', 'EAR', 'NGB', 'NGB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, NJN', 'EAR', 'NJN', 'NJN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, QDO', 'NOR', 'QDO', 'QDO');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, SHH', 'EAR', 'SHH', 'PUD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, SUZ', 'EAR', 'SUZ', 'SUZ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, SYA', 'NOR', 'SYA', 'SYA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, WUN', 'EAR', 'WUN', 'WUN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM HML, XIA', 'EAR', 'XIA', 'XIA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Non PRD Distribution, SHH', 'EAR', 'SHH', 'SHH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM PRD Acquisition, SZN', 'SOR', 'SZN', 'SZN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM PRD Distribution, SZN', 'SOR', 'SZN', 'NA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BCP, BJG', 'NOR', 'BJG', 'BCP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BCU, BJG', 'NOR', 'BJG', 'BCU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BGH, BJG', 'NOR', 'BJG', 'BGH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BHM, BJG', 'NOR', 'BJG', 'BHM');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BJD, BJG', 'NOR', 'BJG', 'BJD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BJU, BJG', 'NOR', 'BJG', 'BJU');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BJY, BJG', 'NOR', 'BJG', 'BJY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BLC, BJG', 'NOR', 'BJG', 'BLC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BLD, BJG', 'NOR', 'BJG', 'BLD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BNS, BJG', 'NOR', 'BJG', 'BNS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BTP, BJG', 'NOR', 'BJG', 'BTP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BWI, BJG', 'NOR', 'BJG', 'BWI');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - BZW, BJG', 'NOR', 'BJG', 'BZW');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - CDJ, CGU', 'NOR', 'CGU', 'CDJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - CDL, CGU', 'NOR', 'CGU', 'CDL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - CQB, CQG', 'NOR', 'CQG', 'CQB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - CQH, CQG', 'NOR', 'CQG', 'CQH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - CSG, CGU', 'NOR', 'CGU', 'CSG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - DDF, DNG', 'SOR', 'DNG', 'DDF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - DLP, DLN', 'NOR', 'DLN', 'DLP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - DPP, DLN', 'NOR', 'DLN', 'DPP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GCH, GZH', 'SOR', 'GZH', 'GCH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GDS, GZH', 'SOR', 'GZH', 'GDS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GFN, GZF', 'SOR', 'GZF', 'GFN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GHS, GZH', 'SOR', 'GZH', 'GHS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GJH, GZH', 'SOR', 'GZH', 'GJH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GPA, GZH', 'SOR', 'GZH', 'GPA');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GTH, GZH', 'SOR', 'GZH', 'GTH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GTT, GZH', 'SOR', 'GZH', 'GTT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GUH, GZH', 'SOR', 'GZH', 'GUH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GZJ, GZH', 'SOR', 'GZH', 'GZJ');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - GZS, GZH', 'SOR', 'GZH', 'GZS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - HKP, SHH', 'EAR', 'SHH', 'HKP');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - HRG, HAZ', 'EAR', 'HAZ', 'HRG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - HZH, HAZ', 'EAR', 'HAZ', 'HZH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - IEH, SHH', 'EAR', 'SHH', 'IEH');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - KRN, SHH', 'EAR', 'SHH', 'KRN');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - KWC, SHH', 'EAR', 'SHH', 'KWC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - NHY, NGB', 'EAR', 'NGB', 'NHY');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - NJX, NJN', 'EAR', 'NJN', 'NJX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - PUD, SHH', 'EAR', 'SHH', 'PUD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - QHG, QDO', 'NOR', 'QDO', 'QHG');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - QSD, QDO', 'NOR', 'QDO', 'QSD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - RGL, SHH', 'EAR', 'SHH', 'RGL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SAF, SHH', 'EAR', 'SHH', 'SAF');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SCR, SHH', 'EAR', 'SHH', 'SCR');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SCT, SHH', 'EAR', 'SHH', 'SCT');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SCX, SHH', 'EAR', 'SHH', 'SCX');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SEC, SZN', 'SOR', 'SZN', 'SEC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SFL, SUZ', 'EAR', 'SUZ', 'SFL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SGB, SHH', 'EAR', 'SHH', 'SGB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SGC, SZN', 'SOR', 'SZN', 'SGC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SGL, SZN', 'SOR', 'SZN', 'SGL');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SGS, GZH', 'SOR', 'GZH', 'SGS');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHB, SHH', 'EAR', 'SHH', 'SHB');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHC, SHH', 'EAR', 'SHH', 'SHC');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHD, SHH', 'EAR', 'SHH', 'SHD');

insert into regionall (DEPARTMENT, REGION, CITY, SUBBRANCH)
values ('RBWM Premier - SHF, SHH', 'EAR', 'SHH', 'SHF');

prompt Done.
