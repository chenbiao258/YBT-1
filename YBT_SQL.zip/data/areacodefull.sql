prompt Importing table areacodefull...
set feedback off
set define off
insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('130200', 'TGH', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('310100', 'SHH', '001', null, null, '1', null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('440300', 'SZN', '001', null, null, '3', null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('350200', 'XIA', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('370200', 'QDO', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('120100', 'TJN', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('110100', 'BJG', '001', null, null, '2', null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('210200', 'DLN', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('420100', 'WUN', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('440100', 'GZH', '001', null, null, '4', null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('320500', 'SUZ', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('500100', 'CQG', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('510100', 'CGU', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('330100', 'HAZ', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('610100', 'XAN', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('340100', 'HEF', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('320100', 'NJN', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('530100', 'KUM', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('320200', 'WUX', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('210100', 'SYA', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('440000', 'DNG', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('430100', 'CNG', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('230100', 'HBB', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('330200', 'NGB', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('410100', 'ZHE', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('140100', 'TYU', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('370100', 'JIN', '001', null, null, null, null, null);

insert into areacodefull (CITYCODE, CITYNAME, OPERATOR, MAKEDATE, MAKETIME, BAK1, BAK2, BAK3)
values ('440600', 'GZF', '001', null, null, null, null, null);

prompt Done.
