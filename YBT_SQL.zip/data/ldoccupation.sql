prompt Importing table ldoccupation...
set feedback off
set define off
insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('A001', '��λ��ְ����', '12', 'YD', 'YD', 12, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('A002', '�������ò���', '12', 'YD', 'YD', 12, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('B103', 'ũ������װ��', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('C104', '��۲�ɰˮ��', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('H121', '����������е', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('F427', '�߿պ��Ϻ���', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('F303', '���溽�˳���', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('W801', 'Ǳˮ��������', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('V092', 'δ������', null, 'YD', 'YD', null, null, null, null);

insert into ldoccupation (OCCUPATIONCODE, OCCUPATIONNAME, OCCUPATIONTYPE, WORKTYPE, WORKNAME, MEDRATE, SUDDRISK, DISEARISK, HOSIPRISK)
values ('Q301', '����ְҵ', null, 'YD', 'YD', null, null, null, null);

prompt Done.
