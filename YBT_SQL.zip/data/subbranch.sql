prompt Importing table subbranch...
set feedback off
set define off
insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S18', 'CDJ', 'C18');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S19', 'CDL', 'C19');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S20', 'CGU', 'C17');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S21', 'CSG', 'C20');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S22', 'CNG', 'C21');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S23', 'CQB', 'C23');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S24', 'CQG', 'C21');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S25', 'CQH', 'C24');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S26', 'CQS', 'C25');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S27', 'DLN', 'C26');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S28', 'DLP', 'C27');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S29', 'DLS', 'C28');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S30', 'DPP', 'C29');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S32', 'DCZ', 'C31');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S33', 'DDF', 'C32');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S34', 'DHM', 'C33');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S35', 'DHZ', 'C34');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S36', 'DJY', 'C35');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S37', 'DLH', 'C36');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S38', 'DMZ', 'C37');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S39', 'DNG', 'C30');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S40', 'DST', 'C38');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S41', 'DSW', 'C39');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S42', 'DYB', 'C40');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S43', 'DZK', 'C41');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S44', 'GCC', 'C46');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S45', 'GCH', 'C45');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S46', 'GDR', 'C47');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S47', 'GDS', 'C50');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S48', 'GFN', 'C158');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S49', 'GFS', 'C159');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S50', 'GHA', 'C51');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S51', 'GHS', 'C52');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S52', 'GHY', 'C53');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S53', 'GJH', 'C54');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S54', 'GJM', 'C55');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S55', 'GMM', 'C56');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S56', 'GPA', 'C57');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S57', 'GQU', 'C58');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S58', 'GQY', 'C59');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S59', 'GSD', 'C160');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S60', 'GSG', 'C60');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S61', 'GTH', 'C61');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S62', 'GTT', 'C62');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S63', 'GUH', 'C63');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S64', 'GXH', 'C64');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S65', 'GYF', 'C65');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S66', 'GYJ', 'C66');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S67', 'GZA', 'C67');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S68', 'GZF', 'C45');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S69', 'GZH', 'C48');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S70', 'GZJ', 'C68');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S71', 'GZQ', 'C69');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S72', 'GZS', 'C70');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S73', 'HAZ', 'C77');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S74', 'HRG', 'C78');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S75', 'HZH', 'C79');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S77', 'SGO', 'C71');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S78', 'SGS', 'C72');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S79', 'SLH', 'C73');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S80', 'SSQ', 'C74');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S81', 'SXL', 'C75');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S82', 'SZU', 'C76');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S83', 'HBB', 'C80');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S84', 'HEF', 'C81');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S85', 'HKP', 'C93');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S86', 'IEH', 'C94');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S87', 'JIN', 'C82');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S88', 'KRN', 'C95');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S89', 'KUM', '83');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S90', 'KWC', 'C82');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S92', 'NGB', 'C85');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S93', 'NHY', 'C153');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S94', 'NJN', 'C86');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S95', 'NJX', 'C87');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S96', 'PUD', 'C97');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S97', 'QDO', 'C88');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S98', 'QHG', 'C89');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S99', 'QSD', 'C90');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S100', 'RGL', 'C98');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S101', 'SAF', 'C99');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S102', 'SCR', 'C100');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S103', 'SCT', 'C101');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S104', 'SCX', 'C102');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S105', 'SEC', 'C129');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S106', 'SFL', 'C118');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S107', 'SGB', 'C82');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S108', 'SGC', 'C82');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S109', 'SGL', 'C103');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S110', 'SHB', 'C104');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S111', 'SHC', 'C105');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S112', 'SHD', 'C106');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S113', 'SHF', 'C107');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S114', 'SHK', 'C108');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S115', 'SHN', 'C109');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S116', 'SHT', 'C110');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S117', 'SHU', 'C111');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S118', 'SHY', 'C112');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S119', 'SHZ', 'C113');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S120', 'SJK', 'C114');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S121', 'SKP', 'C115');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S122', 'SKS', 'C119');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S123', 'SLY', 'C116');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S124', 'SNI', 'C120');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S126', 'SQH', 'C169');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S127', 'STA', 'C173');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S129', 'SUS', 'C121');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S130', 'SUZ', 'C117');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S131', 'SYA', 'C122');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S132', 'SYH', 'C124');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S133', 'SYW', 'C123');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S134', 'SZF', 'C174');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S135', 'SZJ', 'C135');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S136', 'SZM', 'C165');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S137', 'SZN', 'C128');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S138', 'SZO', 'C166');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S139', 'SZQ', 'C167');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S140', 'TGH', 'C136');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S141', 'TIB', 'C139');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S142', 'TJB', 'C140');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S143', 'TJH', 'C179');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S144', 'TJN', 'C138');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S145', 'TYU', 'C141');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S146', 'WHZ', 'C143');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S147', 'WNW', 'C144');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S148', 'WUN', 'C142');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S149', 'WUX', 'C145');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S150', 'XAK', 'C146');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S151', 'XAX', 'C147');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S152', 'XBI', 'C149');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S153', 'XIA', 'C148');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S154', 'XJA', 'C150');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S155', 'XMH', 'C151');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S156', 'ZHE', 'C152');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S1', 'BCP', 'C4');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S2', 'BCU', 'C5');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S3', 'BGH', 'C6');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S4', 'BHM', 'C7');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S5', 'BJD', 'C8');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S6', 'BJG', 'C3');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S7', 'BJU', 'C9');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S8', 'BJY', 'C10');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S9', 'BLC', 'C11');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S10', 'BLD', 'C12');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S11', 'BNS', 'C13');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S12', 'BTP', 'C14');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S13', 'BWI', 'C15');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S14', 'BWJ', 'C16');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S15', 'BZW', 'C17');

insert into subbranch (SUBBRANCHID, SUBBRANCH, CITYID)
values ('S17', 'ZGC', 'C155');

prompt Done.
