prompt Importing table department...
set feedback off
set define off
insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D1', 'Counter Services, TGH', 'C1');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D2', 'RBWM Retail, TGH', 'C1');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D3', 'CNQ RBWM -Cards and Loans', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D4', 'RBWM CCSS - Credit Card', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D5', 'RBWM CCSS - IBC', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D6', 'RBWM CCSS - Porfolio Mgmt', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D7', 'RBWM Central MA', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D8', 'RBWM Contact Centre Svs', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D9', 'RBWM Non PRD Distribution, SHH', 'C2');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D10', 'Counter Services-HKP, Shanghai', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D11', 'Counter Services-PUD, Shanghai', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D12', 'Counter Services-SPN, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D13', 'RBWM - East Region', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D14', 'RBWM Cards & Loans MSF, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D15', 'RBWM Full Service Counters-PUD', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D16', 'RBWM Full Service Counters-SHC', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D17', 'RBWM HML, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D18', 'RBWM Premier - HKP, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D19', 'RBWM Premier - IEH, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D20', 'RBWM Premier - KRN, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D21', 'RBWM Premier - KWC, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D22', 'RBWM Premier - PUD, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D23', 'RBWM Premier - RGL, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D24', 'RBWM Premier - SAF, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D25', 'RBWM Premier - SCR, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D26', 'RBWM Premier - SCT, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D27', 'RBWM Premier - SCX, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D28', 'RBWM Premier - SGB, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D29', 'RBWM Premier - SHB, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D30', 'RBWM Premier - SHC, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D31', 'RBWM Premier - SHD, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D32', 'RBWM Premier - SHF, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D33', 'RBWM Premier - SHK, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D34', 'RBWM Premier - SHN, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D35', 'RBWM Premier - SHT, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D36', 'RBWM Premier - SHU, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D37', 'RBWM Premier - SHY, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D38', 'RBWM Premier - SJK, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D39', 'RBWM Premier - SKP, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D40', 'RBWM Premier - SLY, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D41', 'RBWM Premier - STK, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D42', 'RBWM Retail - HKP, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D43', 'RBWM Retail - IEH, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D44', 'RBWM Retail - KRN, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D45', 'RBWM Retail - KWC, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D46', 'RBWM Retail - PUD, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D47', 'RBWM Retail - RGL, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D48', 'RBWM Retail - SAF, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D49', 'RBWM Retail - SCR, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D50', 'RBWM Retail - SCT, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D51', 'RBWM Retail - SCX, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D52', 'RBWM Retail - SGB, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D53', 'RBWM Retail - SHB, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D54', 'RBWM Retail - SHC, SHH ', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D55', 'RBWM Retail - SHD, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D56', 'RBWM Retail - SHF, SH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D57', 'RBWM Retail - SHK, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D58', 'RBWM Retail - SHN, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D59', 'RBWM Retail - SHT, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D60', 'RBWM Retail - SHU, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D61', 'RBWM Retail - SHY, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D62', 'RBWM Retail - SHZ, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D63', 'RBWM Retail - SJK, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D64', 'RBWM Retail - SKP, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D65', 'RBWM Retail - SLY, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D66', 'RBWM Retail - SPN, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D67', 'RBWM Retail - STK, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D68', 'RBWM Wealth Sales, SHH', 'C3');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D69', 'Cards and Loans RBWM, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D70', 'Counter Services, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D71', 'Counter Services-SQH, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D72', 'RBWM - South Region - SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D73', 'RBWM Advance CD - SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D74', 'RBWM Biz Performance-BRCM, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D75', 'RBWM Biz Performance-SQ, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D76', 'RBWM Cards & Loans MSF, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D77', 'RBWM Digital - PRD SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D78', 'RBWM Full Service Counters-SGC', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D79', 'RBWM HML - PRD SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D80', 'RBWM HML, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D81', 'RBWM PRD Acquisition, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D82', 'RBWM PRD Distribution, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D83', 'RBWM Premier - SEC, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D84', 'RBWM Premier - SGL, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D85', 'RBWM Premier - STA, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D86', 'RBWM Premier - SZF, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D87', 'RBWM Premier - SZJ, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D88', 'RBWM Premier - SZM, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D89', 'RBWM Premier - SZO, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D90', 'RBWM Premier - SZQ, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D91', 'RBWM Premier, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D92', 'RBWM RBB Distribution, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D93', 'RBWM Retail - SEC, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D94', 'RBWM Retail - SGC, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D95', 'RBWM Retail - SGL, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D96', 'RBWM Retail - SQH, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D97', 'RBWM Retail - STA, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D98', 'RBWM Retail - SZF, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D99', 'RBWM Retail - SZJ, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D100', 'RBWM Retail - SZM, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D101	', 'RBWM Retail - SZO, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D102	', 'RBWM Retail - SZQ, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D103	', 'RBWM Retail, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D104	', 'RBWM Wealth Sales, SZN', 'C4');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D105	', 'Counter Services, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D106	', 'RBWM HML, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D107	', 'RBWM Premier - XBI, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D108', 'RBWM Premier - XJA, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D109', 'RBWM Premier - XMH, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D110	', 'RBWM Retail - XBI, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D111	', 'RBWM Retail - XJA, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D112	', 'RBWM Retail - XMH, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D113	', 'RBWM Retail, XIA', 'C5');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D114	', 'Counter Services, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D144	', 'RBWM Premier - BLC, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D143	', 'RBWM Premier - BJY, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D142	', 'RBWM Premier - BJU, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D141	', 'RBWM Premier - BJD, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D140	', 'RBWM Premier - BHM, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D139	', 'RBWM Premier - BGH, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D138	', 'RBWM Premier - BCU, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D137	', 'RBWM Premier - BCP, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D136	', 'RBWM HML, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D135	', 'RBWM Cards & Loans MSF, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D134	', 'RBWM CVM - Rel & Exp, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D133	', 'RBWM Biz Performance-SQ, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D132	', 'RBWM Biz Performance-BRCM, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D131	', 'RBWM - North Region', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D130	', 'Counter Services, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D129	', 'RBWM Wealth Sales - TJN', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D128	', 'RBWM Retail - TJH, TJN ', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D127	', 'RBWM Retail - TJB, TJN', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D126	', 'RBWM Retail - TIB, TJN ', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D125	', 'RBWM Premier - TJH, TJN', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D124	', 'RBWM Premier - TJB, TJN', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D123	', 'RBWM Premier - TIB, TJN', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D122	', 'Counter Services, TJN', 'C7');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D121	', 'RBWM Wealth Sales - QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D120	', 'RBWM Retail, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D119	', 'RBWM Retail - QSD, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D118	', 'RBWM Retail - QHG, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D117	', 'RBWM Premier - QSD, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D116	', 'RBWM Premier - QHG, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D115	', 'RBWM HML, QDO', 'C6');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D145	', 'RBWM Premier - BLD, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D165	', 'RBWM Retail - BZW, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D164	', 'RBWM Retail - BWJ, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D163	', 'RBWM Retail - BWI, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D162	', 'RBWM Retail - BTP, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D161	', 'RBWM Retail - BNS, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D160	', 'RBWM Retail - BLD, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D159	', 'RBWM Retail - BLC, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D158	', 'RBWM Retail - BJY, BJG ', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D157	', 'RBWM Retail - BJU, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D156	', 'RBWM Retail - BJD, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D155	', 'RBWM Retail - BHM, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D154	', 'RBWM Retail - BGH, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D153	', 'RBWM Retail - BCU, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D152	', 'RBWM Retail - BCP, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D151	', 'RBWM Premier, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D150	', 'RBWM Premier - ZGC, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D149	', 'RBWM Premier - BZW, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D148	', 'RBWM Premier - BWI, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D147	', 'RBWM Premier - BTP, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D146	', 'RBWM Premier - BNS, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D166	', 'RBWM Retail - ZGC, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D195	', 'Counter Services-SGS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D194	', 'Counter Services-GZQ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D193	', 'Counter Services-GZA, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D192	', 'Counter Services-GYJ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D191	', 'Counter Services-GYF, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D190	', 'Counter Services-GXH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D189	', 'Counter Services-GSG, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D188	', 'Counter Services-GQY, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D187	', 'Counter Services-GQU, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D186	', 'Counter Services-GMM, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D185	', 'Counter Services-GJM, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D184	', 'Counter Services-GHY, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D183	', 'Counter Services-GHA, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D182	', 'Counter Services, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D181	', 'RBWM Retail - WNW, WUN', 'C10');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D180	', 'RBWM Retail - WHZ, WUN', 'C10');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D179	', 'RBWM Premier - WNW, WUN', 'C10');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D178	', 'RBWM Premier - WHZ, WUN', 'C10');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D177	', 'RBWM HML, WUN', 'C10');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D176	', 'Branch Counter Services WUN', 'C10');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D175	', 'RBWM Wealth Sales, DLN', 'C9');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D174	', 'RBWM Retail - DPP, DLN', 'C9');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D173	', 'RBWM Retail - DLS, DLN', 'C9');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D172	', 'RBWM Retail - DLP, DLN', 'C9');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D171	', 'RBWM Premier - DPP, DLN', 'C9');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D170	 ', ' RBWM Premier - DLP, DLN', ' ');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D169	', 'Counter Services, DLN', 'C9');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D168	', 'RBWM Wealth Sales, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D167	', 'RBWM Retail, BJG', 'C8');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D196	', 'Counter Services-SLH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D197	', 'Counter Services-SSQ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D198	', 'Counter Services-SXL, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D199	', 'Counter Services-SZU, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D200	', 'RBWM - South Region - GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D201	', 'RBWM Advance CD - SGS', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D202	', 'RBWM Biz Performance-BRCM, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D203	', 'RBWM Biz Performance-SQ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D204	', 'RBWM CCS Collection, PRD, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D205	', 'RBWM CCS-UWS,PRD,GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D206	', 'RBWM Cards & Loans MSF, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D207	', 'RBWM Digital DCoE, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D208	', 'RBWM Full Service Counters-GDS', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D209	', 'RBWM Full Service Counters-GTH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D210	', 'RBWM Full Service Counters-GTT', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D211	', 'RBWM Full Service Counters-GZJ', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D212	', 'RBWM HML - PRD GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D213	', 'RBWM HML, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D214	', 'RBWM Premier - GCH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D215	', 'RBWM Premier - GDS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D244	', 'RBWM Retail - GYF, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D243	', 'RBWM Retail - GXH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D242	', 'RBWM Retail - GUH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D241	', 'RBWM Retail - GTT, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D240	', 'RBWM Retail - GTH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D239	', 'RBWM Retail - GSG, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D238	', 'RBWM Retail - GQY, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D237	', 'RBWM Retail - GQU, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D236	', 'RBWM Retail - GPA, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D235	', 'RBWM Retail - GMM, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D234	', 'RBWM Retail - GJM, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D233	', 'RBWM Retail - GJH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D232	', 'RBWM Retail - GHY, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D231	', 'RBWM Retail - GHS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D230	', 'RBWM Retail - GHA, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D229	', 'RBWM Retail - GDS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D228	', 'RBWM Retail - GCH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D227	', 'RBWM RBB Distribution, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D226	', 'RBWM Premier, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D225	', 'RBWM Premier - SZU, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D224	', 'RBWM Premier - SGS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D223	', 'RBWM Premier - GZS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D222	', 'RBWM Premier - GZJ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D221	', 'RBWM Premier - GUH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D220	', 'RBWM Premier - GTT, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D219	', 'RBWM Premier - GTH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D218	', 'RBWM Premier - GPA, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D217	', 'RBWM Premier - GJH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D216	', 'RBWM Premier - GHS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D245	', 'RBWM Retail - GZA, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D263	', 'RBWM Retail - SKS, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D262	', 'RBWM Retail - SFL, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D261	', 'RBWM Premier - SUS, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D260	', 'RBWM Premier - SNI, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D259	', 'RBWM Premier - SFL, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D258	', 'RBWM HML, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D257	', 'Counter Services-SKS, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D256	', 'Counter Services, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D255	', 'RBWM Wealth Sales, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D254	', 'RBWM Retail, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D253	', 'RBWM Retail - SZU, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D252	', 'RBWM Retail - SXL, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D251	', 'RBWM Retail - SLH, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D250	', 'RBWM Retail - SGS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D249	', 'RBWM Retail - SGO, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D248	', 'RBWM Retail - GZS, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D247	', 'RBWM Retail - GZQ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D246	', 'RBWM Retail - GZJ, GZH', 'C11');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D264	', 'RBWM Retail - SNI, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D281	', 'RBWM Retail - CDL, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D280	', 'RBWM Retail - CDJ, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D279	', 'RBWM Premier - CSG, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D278	', 'RBWM Premier - CDL, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D277	', 'RBWM Premier - CDJ, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D276	', 'RBWM HML, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D275	', 'RBWM Biz Performance-SQ, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D274	', 'RBWM Biz Performance-BRCM, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D273	', 'Branch Counter Services, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D272	', 'RBWM Retail - CQS, CQG', 'C13');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D271	', 'RBWM Retail - CQH, CQG', 'C13');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D270	', 'RBWM Retail - CQB, CQG', 'C13');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D269	', 'RBWM Premier - CQH, CQG', 'C13');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D268	', 'RBWM Premier - CQB, CQG', 'C13');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D267	', 'RBWM HML, CQG', 'C13');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D266	', 'RBWM Wealth Sales, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D265	', 'RBWM Retail - SUS, SUZ', 'C12');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D282	', 'RBWM Retail - CSG, CGU', 'C14');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D304	', 'RBWM Retail, WUX', 'C20');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D303	', 'Counter Services, WUX', 'C20');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D302	', 'Branch Counter Services KUM', 'C19');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D301	', 'RBWM Retail - NJX, NJN', 'C18');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D300	', 'RBWM Premier - NJX, NJN', 'C18');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D299	', 'RBWM HML, NJN', 'C18');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D298	', 'Counter Services, NJN', 'C18');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D297	', 'RBWM Retail, HEF', 'C17');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D296	', 'RBWM Premier, HEF', 'C17');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D295	', 'Counter Services, HEF', 'C17');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D294	', 'RBWM Retail - XAX, XAN', 'C16');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D293	', 'RBWM Retail - XAK, XAN', 'C16');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D292	', 'RBWM Premier - XAX, XAN', 'C16');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D291	', 'RBWM Wealth Sales, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D290	', 'RBWM Retail, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D289	', 'RBWM Retail - HZH, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D288	', 'RBWM Retail - HRG, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D287	', 'RBWM Premier, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D286	', 'RBWM Premier - HZH, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D285	', 'RBWM Premier - HRG, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D284	', 'RBWM HML, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D283	', 'Counter Services, HAZ', 'C15');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D305	', 'Counter Services, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D306	', 'RBWM HML, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D342	', 'RBWM Retail, HBB', 'C24');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D341	', 'Counter Services, HBB', 'C24');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D340	', 'RBWM Retail, CNG', 'C23');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D339	', 'Branch Counter Services, CNG', 'C23');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D338	', 'RBWM Retail, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D337	', 'RBWM Retail - DYB, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D336	', 'RBWM Retail - DSW, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D335	', 'RBWM Retail - DST, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D334	', 'RBWM Retail - DMZ, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D333	', 'RBWM Retail - DLH, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D332	', 'RBWM Retail - DJY, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D331	', 'RBWM Retail - DHZ, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D330	', 'RBWM Retail - DHM, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D329	', 'RBWM Retail - DDF, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D328	', 'RBWM Retail - DCZ, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D327	', 'RBWM Premier, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D326	', 'RBWM Premier - DYB, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D325	', 'RBWM Premier - DDF, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D324	', 'RBWM HML - PRD DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D323	', 'RBWM Advance CD - DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D322	', 'Counter Services-DZK, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D321	', 'Counter Services-DSW, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D320	', 'Counter Services-DST, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D319	', 'Counter Services-DMZ, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D318	', 'Counter Services-DLH, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D317	', 'Counter Services-DJY, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D316	', 'Counter Services-DHZ, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D315	', 'Counter Services-DHM, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D314	', 'Counter Services-DCZ, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D313	', 'Counter Services, DNG', 'C22');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D312	', 'RBWM Retail, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D311	', 'RBWM Retail - SYW, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D310	', 'RBWM Retail - SYH, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D309	', 'RBWM Premier, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D308	', 'RBWM Premier - SYW, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D307	', 'RBWM Premier - SYH, SYA', 'C21');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D343	', 'Counter Services, NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D344	', 'RBWM HML, NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D345	', 'RBWM Premier - NHY, NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D346	', 'RBWM Premier, NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D375	', 'RBWM Retail - GFN, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D374	', 'RBWM Retail - GCC, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D373	', 'RBWM RBB Distribution, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D372	', 'RBWM Premier, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D371	', 'RBWM Premier - GFN, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D370	', 'RBWM HML, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D369	', 'RBWM HML - PRD, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D368	', 'RBWM Cards & Loans MSF, NHC', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D367	', 'RBWM CCSS PRD Banking_GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D366	', 'RBWM CCSS - Credit Card, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D365	', 'RBWM CCS-UWS,PRD,GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D364	', 'RBWM CCS Collection, PRD, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D363	', 'RBWM Advance CD, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D362	', 'Counter Services-GSD, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D361	', 'Counter Services-GFS, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D360	', 'Counter Services-GDR, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D359	', 'Counter Services-GCC, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D358	', 'Counter Services, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D357	', 'RBWM Retail, JIN', 'C28');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D356	', 'RBWM Premier, JIN', 'C28');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D355	', 'Branch Counter Services JIN', 'C28');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D354	', 'RBWM Retail, TYU', 'C27');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D353	', 'RBWM Premier, TYU', 'C27');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D352	', 'Branch Counter Services TYU', 'C27');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D351	', 'RBWM Retail, ZHE', 'C26');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D350	', 'Branch Counter Services ZHE', 'C26');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D349	', 'RBWM Wealth Sales - NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D348	', 'RBWM Retail, NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D347	', 'RBWM Retail - NHY, NGB', 'C25');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D376	', 'RBWM Retail - GFS, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D377	', 'RBWM Retail - GSD, GZF', 'C29');

insert into department (DEPARTMENTID, DEPARTMENT, COMPANYNAMEID)
values ('D378	', 'RBWM Retail, GZF', 'C29');

prompt Done.
