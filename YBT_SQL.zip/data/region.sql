prompt Importing table region...
set feedback off
set define off
insert into region (REGIONID, REGION)
values ('R1', 'CCSS');

insert into region (REGIONID, REGION)
values ('R2', 'Credit Card');

insert into region (REGIONID, REGION)
values ('R3', 'Digital');

insert into region (REGIONID, REGION)
values ('R4', 'EAR');

insert into region (REGIONID, REGION)
values ('R5', 'NA');

insert into region (REGIONID, REGION)
values ('R6', 'NOR');

insert into region (REGIONID, REGION)
values ('R7', 'RBB');

insert into region (REGIONID, REGION)
values ('R8', 'RCS');

insert into region (REGIONID, REGION)
values ('R9', 'SOR');

insert into region (REGIONID, REGION)
values ('R10', 'wealth coach');

prompt Done.
