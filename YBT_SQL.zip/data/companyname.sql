prompt Importing table companyname...
set feedback off
set define off
insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C1', 'HBCN Tangshan Branch', '1');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C2', 'HSBC Bank (China) Co., Ltd.', '2');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C3', 'HBCN Shanghai Branch', '2');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C4', 'HBCN Shenzhen Branch', '3');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C5', 'HBCN Xiamen Branch', '4');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C6', 'HBCN Qingdao Branch', '5');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C7', 'HBCN Tianjin Branch', '6');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C8', 'HBCN Beijing Branch', '7');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C9', 'HBCN Dalian Branch', '8');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C10', 'HBCN Wuhan Branch', '9');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C11', 'HBCN Guangzhou Branch', '10');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C12', 'HBCN Suzhou Branch', '11');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C13', 'HBCN Chongqing Branch', '12');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C14', 'HBCN Chengdu Branch', '13');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C15', 'HBCN Hangzhou Branch', '14');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C16', 'HBCN Xi''''an Branch', '15');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C17', 'HBCN Hefei Branch', '16');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C18', 'HBCN Nanjing Branch', '17');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C19', 'HBCN Kunming Branch', '18');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C20', 'HBCN Wuxi Branch', '19');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C21', 'HBCN Shenyang Branch', '20');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C22', 'HBCN Dongguan Branch', '21');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C23', 'HBCN Changsha Branch', '22');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C24', 'HBCN Harbin Branch', '23');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C25', 'HBCN Ningbo Branch', '24');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C26', 'HBCN Zhengzhou Branch', '25');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C27', 'HBCN Taiyuan Branch', '26');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C28', 'HBCN Ji''''nan Branch', '27');

insert into companyname (COMPANYNAMEID, COMPANYNAME, CITYID)
values ('C29', 'HBCN Foshan Branch', '28');

prompt Done.
