prompt Importing table lmriskparamsdef...
set feedback off
set define off
insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'Y', 'D', 'insuyear', '20Y', '����20��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'Y', 'D', 'payendyear', '10Y', '�ɷ�10��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'Y', 'D', 'payendyear', '3Y', '�ɷ�3��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'Y', 'D', 'payendyear', '5Y', '�ɷ�5��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'Y', 'D', 'payendyear', '20Y', '�ɷ�20��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', '2', 'D', 'insuyearflag', '2', '�걣', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', '1', 'D', 'payendyearflag', '1', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'Y', 'D', 'payendyear', '3Y', '�ɷ�3��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'Y', 'D', 'payendyear', '10Y', '�ɷ�10��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JZ', null, 'D@JZ0', 'A', 'D', 'insuyear', '100A', '������100��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JZ', null, 'D@JZ0', '999', 'D', 'payendyear', '0Y', '������', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JZ', null, 'D@JZ0', 'S', 'D', 'payintv', 'S', '����', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JZ', null, 'D@JZ0', '2', 'D', 'insuyearflag', '2', '�걣', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JZ', null, 'D@JZ0', '1', 'D', 'payendyearflag', '1', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'Y', 'D', 'payendyear', '10Y', '�ɷ�10��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'A', 'D', 'insuyear', '100A', '������100��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', '2', 'D', 'insuyearflag', '2', '�걣', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'Y', 'D', 'payendyear', '20Y', '�ɷ�20��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'Y', 'D', 'payendyear', '30Y', '�ɷ�30��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', '1', 'D', 'payendyearflag', '1', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'S', 'D', 'payintv', 'S', '����', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'Y', 'D', 'payendyear', '5Y', '�ɷ�5��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'Y', 'D', 'payendyear', '15Y', '�ɷ�15��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', '2', 'D', 'payendyearflag', '2', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', '999', 'D', 'payendyear', '0Y', '������', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'Y', 'D', 'payintv', 'Y', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', '999', 'D', 'payendyear', '0Y', '������', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'Y', 'D', 'insuyear', '25Y', '����25��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'S', 'D', 'payintv', 'S', '����', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'Y', 'D', 'payendyear', '5Y', '�ɷ�5��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'Y', 'D', 'insuyear', '20Y', '����20��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'Y', 'D', 'payendyear', '10Y', '�ɷ�10��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'Y', 'D', 'payintv', 'Y', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', '1', 'D', 'insuyearflag', '1', '�걣', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', 'Y', 'D', 'payendyear', '3Y', '�ɷ�3��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', '999', 'D', 'payendyear', '0Y', '������', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'S', 'D', 'payintv', 'S', '����', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'Y', 'D', 'payendyear', '5Y', '�ɷ�5��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'Y', 'D', 'insuyear', '20Y', '����20��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', '1', 'D', 'insuyearflag', '1', '�걣', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'Y', 'D', 'payendyear', '3Y', '�ɷ�3��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', '999', 'D', 'payendyear', '0Y', '������', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'Y', 'D', 'insuyear', '25Y', '����25��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', '1', 'D', 'payendyearflag', '1', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'Y', 'D', 'payintv', 'Y', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'S', 'D', 'payintv', 'S', '����', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', 'A', 'D', 'insuyear', '100A', '������100��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@MA', null, 'D@MA0', '999', 'D', 'payendyear', '0Y', '������', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JE', null, 'D@JE0', '1', 'D', 'payendyearflag', '1', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'Y', 'D', 'insuyear', '25Y', '����25��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', '1', 'D', 'payendyearflag', '1', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'Y', 'D', 'payendyear', '10Y', '�ɷ�10��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JD', null, 'D@JD0', 'Y', 'D', 'payintv', 'Y', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'S', 'D', 'payintv', 'S', '����', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'Y', 'D', 'payendyear', '5Y', '�ɷ�5��', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', 'Y', 'D', 'payintv', 'Y', '���', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JC', null, 'D@JC0', '1', 'D', 'insuyearflag', '1', '�걣', 'W', 'N');

insert into lmriskparamsdef (RISKCODE, RISKVER, DUTYCODE, OTHERCODE, CTRLTYPE, PARAMSTYPE, PARAMSCODE, PARAMSNAME, CHAR1, CHAR2)
values ('@JN', null, 'D@JN0', 'A', 'D', 'payendyear', '60A', '�ɷ���60��', 'W', 'N');

prompt Done.
