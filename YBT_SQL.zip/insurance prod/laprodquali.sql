prompt Importing table laprodquali...
set feedback off
set define off
insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@MA', 'CN3120', 'MetLife Du Hui Kang Jian Critical Illness Insurance', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:51:23', to_date('31-10-2017', 'dd-mm-yyyy'), '21:51:23');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@MA', 'CNL00096', 'Insurance-nonILI Accreditation', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:53:16', to_date('31-10-2017', 'dd-mm-yyyy'), '21:53:16');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JZ', 'CNL00095', 'Insurance-ILI Accreditation', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:55:07', to_date('31-10-2017', 'dd-mm-yyyy'), '21:55:07');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JC', 'CN3122', 'Metlife Du Hui Jin Sheng Annuity Insurance(Participating)', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:56:55', to_date('31-10-2017', 'dd-mm-yyyy'), '21:56:55');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JD', 'CN3122', 'Metlife Du Hui Jin Sheng Annuity Insurance(Participating)', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:57:16', to_date('31-10-2017', 'dd-mm-yyyy'), '21:57:16');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JE', 'CN3122', 'Metlife Du Hui Jin Sheng Annuity Insurance(Participating)', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:57:35', to_date('31-10-2017', 'dd-mm-yyyy'), '21:57:35');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JN', 'CN3133', 'Metlife Hua Yang Nian Hua Whole of life Insurance (HYNH2)', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:58:22', to_date('31-10-2017', 'dd-mm-yyyy'), '21:58:22');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JZ', 'CN3143', 'MetLife CFJX2 product launch training', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '22:10:04', to_date('31-10-2017', 'dd-mm-yyyy'), '22:10:04');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JN', 'CNL00096', 'Insurance-nonILI Accreditation', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:54:22', to_date('31-10-2017', 'dd-mm-yyyy'), '21:54:22');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JC', 'CNL00096', 'Insurance-nonILI Accreditation', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:49:11', to_date('31-10-2017', 'dd-mm-yyyy'), '21:49:11');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JD', 'CNL00096', 'Insurance-nonILI Accreditation', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:52:00', to_date('31-10-2017', 'dd-mm-yyyy'), '21:52:00');

insert into laprodquali (RISKCODE, QUALIFITYPECODE, QUALIFITYPE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('@JE', 'CNL00096', 'Insurance-nonILI Accreditation', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '21:52:56', to_date('31-10-2017', 'dd-mm-yyyy'), '21:52:56');

prompt Done.
