prompt Importing table lacom...
set feedback off
set define off
insert into lacom (AGENTCOM, NAME, STATES, COOPERATIONDATE, CHANNELTYPE, LICENSESTARTDATE, OPERATOR, REMARK, AMEND, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('MELI', '������̩�󶼻����ٱ������޹�˾', '3', to_date('01-12-2015', 'dd-mm-yyyy'), 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), 'admin', null, 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:44:51', to_date('30-10-2017', 'dd-mm-yyyy'), '20:44:51');

prompt Done.
