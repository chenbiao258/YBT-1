-------------------------------------------------
-- Export file for user YBT                    --
-- Created by suojinyu on 2017/10/31, 20:19:24 --
-------------------------------------------------

set define off
spool lccont.log

prompt
prompt Creating table LCCONT
prompt =====================
prompt
create table YBT.LCCONT
(
  transno                 VARCHAR2(35) not null,
  contno                  VARCHAR2(20) not null,
  proposalcontno          VARCHAR2(20),
  prtno                   VARCHAR2(20),
  conttype                VARCHAR2(1),
  familytype              VARCHAR2(40),
  familyid                VARCHAR2(200),
  poltype                 VARCHAR2(1),
  cardflag                VARCHAR2(1),
  managecom               VARCHAR2(10),
  executecom              VARCHAR2(10),
  agentcom                VARCHAR2(20),
  agentcode               VARCHAR2(10),
  agentgroup              VARCHAR2(40),
  agentcode1              VARCHAR2(200),
  agenttype               VARCHAR2(20),
  insurancecom            VARCHAR2(20),
  insurancemanagecom      VARCHAR2(30),
  salechnl                VARCHAR2(2),
  handler                 VARCHAR2(20),
  password                VARCHAR2(20),
  appntno                 VARCHAR2(24),
  appntname               VARCHAR2(120),
  appntsex                VARCHAR2(1),
  appntbirthday           DATE,
  appntidtype             VARCHAR2(2),
  appntidno               VARCHAR2(20),
  insuredno               VARCHAR2(24),
  insuredname             VARCHAR2(120),
  insuredsex              VARCHAR2(1),
  insuredbirthday         DATE,
  insuredidtype           VARCHAR2(2),
  insuredidno             VARCHAR2(20),
  paylocation             VARCHAR2(1),
  outpayflag              VARCHAR2(20),
  getpolmode              VARCHAR2(1),
  signcom                 VARCHAR2(10),
  signdate                DATE,
  signtime                VARCHAR2(8),
  bankcode                VARCHAR2(10),
  bankaccno               VARCHAR2(40),
  accname                 VARCHAR2(60),
  printcount              INTEGER,
  losttimes               INTEGER,
  remark                  VARCHAR2(1600),
  peoples                 INTEGER,
  mult                    NUMBER(20,5),
  prem                    NUMBER(16,2),
  amnt                    NUMBER(16,2),
  sumprem                 NUMBER(16,2),
  firstpaydate            DATE,
  approvetime             VARCHAR2(20),
  appflag                 VARCHAR2(2),
  polapplydate            DATE,
  state                   VARCHAR2(10),
  firsttrialoperator      VARCHAR2(10),
  firsttrialdate          DATE,
  firsttrialtime          VARCHAR2(8),
  receiveoperator         VARCHAR2(10),
  receivedate             DATE,
  chargerate              VARCHAR2(8),
  tempfeeno               VARCHAR2(20),
  selltype                VARCHAR2(2),
  forceuwflag             VARCHAR2(1),
  forceuwreason           VARCHAR2(500),
  newbankcode             VARCHAR2(10),
  newbankaccno            VARCHAR2(40),
  newaccname              VARCHAR2(60),
  newpaymode              VARCHAR2(1),
  agentbankcode           VARCHAR2(50),
  bankagent               VARCHAR2(50),
  organcomcode            VARCHAR2(30),
  operator                VARCHAR2(10),
  makedate                DATE,
  maketime                VARCHAR2(10),
  modifydate              DATE,
  modifytime              VARCHAR2(10),
  agentname               VARCHAR2(120),
  grpcontno               VARCHAR2(35),
  receivetime             VARCHAR2(3),
  riskcode                VARCHAR2(40),
  accountbalance          INTEGER,
  debitflag               VARCHAR2(10),
  delayeddebit            DATE,
  hesitationflag          VARCHAR2(10),
  investmentstartdate     DATE,
  investmentstartdateflag VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT.LCCONT.transno
  is '���׵�?';
comment on column YBT.LCCONT.contno
  is '����??';
comment on column YBT.LCCONT.proposalcontno
  is '����??';
comment on column YBT.LCCONT.prtno
  is '����??';
comment on column YBT.LCCONT.conttype
  is '��?1';
comment on column YBT.LCCONT.poltype
  is '��?0';
comment on column YBT.LCCONT.agentcode
  is '��??����?';
comment on column YBT.LCCONT.insurancecom
  is '��?����';
comment on column YBT.LCCONT.salechnl
  is '��??�� ';
comment on column YBT.LCCONT.appntno
  is '������? ��֪����';
comment on column YBT.LCCONT.appntname
  is '��������٣';
comment on column YBT.LCCONT.appntsex
  is '����������?';
comment on column YBT.LCCONT.appntbirthday
  is '����������';
comment on column YBT.LCCONT.appntidtype
  is '������?��?��';
comment on column YBT.LCCONT.appntidno
  is '������?��??';
comment on column YBT.LCCONT.insuredno
  is '������?����֪����';
comment on column YBT.LCCONT.insuredname
  is '��������٣';
comment on column YBT.LCCONT.insuredsex
  is '��������?';
comment on column YBT.LCCONT.insuredbirthday
  is '����������';
comment on column YBT.LCCONT.insuredidtype
  is '������?��?��';
comment on column YBT.LCCONT.insuredidno
  is '������?��??';
comment on column YBT.LCCONT.getpolmode
  is '����??��۰��';
comment on column YBT.LCCONT.appflag
  is '���?? 00 ��?����';
comment on column YBT.LCCONT.polapplydate
  is '������Ѣ';
comment on column YBT.LCCONT.state
  is '��??? ��? 0';
comment on column YBT.LCCONT.selltype
  is '??۰����?08';
comment on column YBT.LCCONT.forceuwflag
  is '��? 0';
comment on column YBT.LCCONT.operator
  is '����?';
comment on column YBT.LCCONT.makedate
  is '?����Ѣ';
comment on column YBT.LCCONT.maketime
  is '?��??';
comment on column YBT.LCCONT.modifydate
  is '������Ѣ';
comment on column YBT.LCCONT.modifytime
  is '����??';
comment on column YBT.LCCONT.agentname
  is '��??����٣';
comment on column YBT.LCCONT.grpcontno
  is 'cif?';
comment on column YBT.LCCONT.receivetime
  is '��??���??����';
comment on column YBT.LCCONT.riskcode
  is '��??����?';
comment on column YBT.LCCONT.accountbalance
  is '��?';
comment on column YBT.LCCONT.debitflag
  is '��??γ';
comment on column YBT.LCCONT.delayeddebit
  is '��??γ��Ѣ';
comment on column YBT.LCCONT.hesitationflag
  is '?��Ѣ����';
comment on column YBT.LCCONT.investmentstartdate
  is '��?�����Ѣ';
comment on column YBT.LCCONT.investmentstartdateflag
  is '��?�����Ѣ?�';
alter table YBT.LCCONT
  add constraint PK_LCCONT primary key (TRANSNO, CONTNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );


spool off
