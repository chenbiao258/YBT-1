var tab_d = $('#cusTable');
// 页面初始化
$(document).ready(function() {

	 $("#reset").click(function() {
		 $('#forms')[0].reset();
	 });
	 
		$('#hireDate').datepicker({
			dateFormat: "yyyy-mm-dd",
		anguage: "zh-CN",
		onSelect: gotoDate
		}).on('changeDate',gotoDate);
		
		
		function gotoDate(){
			$('#forms').data('bootstrapValidator')
			.updateStatus('hireDate','NOT_VALIDATED',null)
			.validateField('hireDate');
	   }
		
		
		$('#rehireDate').datepicker({
			dateFormat: "yyyy-mm-dd",
		anguage: "zh-CN",
		onSelect: gotoDates
		}).on('changeDate',gotoDates);
		
		
		function gotoDates(){
			$('#forms').data('bootstrapValidator')
			.updateStatus('rehireDate','NOT_VALIDATED',null)
			.validateField('rehireDate');
	   }
		
		
		$('#termDate').datepicker({
			dateFormat: "yyyy-mm-dd",
		anguage: "zh-CN",
		onSelect: gotoDatea
		}).on('changeDate',gotoDatea);
		
		
		function gotoDatea(){
			$('#forms').data('bootstrapValidator')
			.updateStatus('termDate','NOT_VALIDATED',null)
			.validateField('termDate');
	   }
		
		
		$('#originalHireDate').datepicker({
			dateFormat: "yyyy-mm-dd",
		anguage: "zh-CN",
		onSelect: gotoDateb
		}).on('changeDate',gotoDateb);
		
		
		function gotoDateb(){
			$('#forms').data('bootstrapValidator')
			.updateStatus('originalHireDate','NOT_VALIDATED',null)
			.validateField('originalHireDate');
	   }
		
		
		$('#companyDt').datepicker({
			dateFormat: "yyyy-mm-dd",
		anguage: "zh-CN",
		onSelect: gotoDatec
		}).on('changeDate',gotoDatec);
		
		
		function gotoDatec(){
			$('#forms').data('bootstrapValidator')
			.updateStatus('companyDt','NOT_VALIDATED',null)
			.validateField('companyDt');
	   }
	 
	 
	 
	 
});



$(function(){

	  $('form').bootstrapValidator({
          message: 'This value is not valid',
          feedbackIcons: {
              valid: 'glyphicon glyphicon-ok',
              invalid: 'glyphicon glyphicon-remove',
              validating: 'glyphicon glyphicon-refresh'
          },
          fields: {
        	  emplID: {
                  message: 'emplID验证失败',
                  validators: {
                      notEmpty: {
                          message: 'emplID不能为空'
                      } ,
                    }
              },
              department: {
                  validators: {
                      notEmpty: {
                          message: 'department不能为空'
                      }
                  }
              },
              name:{
                validators: {
                      notEmpty: {
                          message: 'name不能为空'
                      }
                  }
               },
               preferredFirstName:{
                   validators: {
                         notEmpty: {
                             message: 'preferredFirstName不能为空'
                         }
                     }
                  },
               jobCode: {
                  validators: {
                      notEmpty: {
                          message: 'jobCode不能为空'
                      }
                  }
              },
              positionCode: {
                  validators: {
                      notEmpty: {
                          message: 'positionCode不能为空'
                      }
                  }
              },
              positionTitle: {
                  validators: {
                      notEmpty: {
                          message: 'positionTitle不能为空'
                      }
                  }
              },

              originalHireDate:{
           	   validators: {
           		   date:{
           		format:'yyyy-mm-dd', 
           		message:'The format is yyyy-mm-dd'
           		   },
           		  notEmpty: {
                          message: 'originalHireDate不能为空'
                      },
           	   },
              },
              termDate:{
           	   validators: {
           		   date:{
           		format:'yyyy-mm-dd', 
           		message:'The format is yyyy-mm-dd'
           		   },
           		  notEmpty: {
                          message: 'termDate不能为空'
                      },
           	   },
              },
              
              
              companyDt:{
            	   validators: {
            		   date:{
            		format:'yyyy-mm-dd', 
            		message:'The format is yyyy-mm-dd'
            		   },
            		  notEmpty: {
                           message: 'companyDt不能为空'
                       },
            	   },
               },
               rehireDate:{
               	   validators: {
               		   date:{
               		format:'yyyy-mm-dd', 
               		message:'The format is yyyy-mm-dd'
               		   },
               		  notEmpty: {
                              message: 'rehireDate不能为空'
                          },
               	   },
                  },
                  
                  
                  hireDate:{
                	   validators: {
                		   date:{
                		format:'yyyy-mm-dd', 
                		message:'The format is yyyy-mm-dd'
                		   },
                		  notEmpty: {
                               message: 'hireDate不能为空'
                           },
                	   },
                   },
                   
           
              companyCode:{
                validators: {
                      notEmpty: {
                          message: 'companyCode不能为空'
                      }
                  }
               },
               
               
               companyName:{
                validators: {
                      notEmpty: {
                          message: 'companyName不能为空'
                      }
                  }
               },
               
               operator:{
                validators: {
                      notEmpty: {
                          message: '操作员不能为空'
                      }
                  }
               },
               
               status:{
                   validators: {
                         notEmpty: {
                             message: 'status不能为空'
                         }
                     }
                  },
                  
               location:{
                validators: {
                      notEmpty: {
                          message: 'location不能为空'
                      }
                  }
               },   
               
               
               
               
               locationDescr:{
                   validators: {
                         notEmpty: {
                             message: 'locationDescr不能为空'
                         }
                     }
                  },   
                  deptID:{
                  validators: {
                        notEmpty: {
                            message: 'deptID不能为空'
                        }
                    }
                     },   
                     costCentre:{
                     validators: {
                           notEmpty: {
                               message: 'costCentre不能为空'
                           }
                       }
                    },   
                    emplRcd:{
                    validators: {
                          notEmpty: {
                              message: 'emplRcd不能为空'
                          }
                      }
                   },   
                   lastName:{
                       validators: {
                             notEmpty: {
                                 message: 'lastName不能为空'
                             }
                         }
                 },   
                 
                 
                eMsPositionCode:{
                     validators: {
                           notEmpty: {
                               message: 'eMsPositionCode不能为空'
                           }
                       }
               },   
               
               eMsPositionTitle:{
                   validators: {
                         notEmpty: {
                             message: 'eMsPositionTitle不能为空'
                         }
                     }
             },   
             
             eMsStaffID:{
                 validators: {
                       notEmpty: {
                           message: 'eMsStaffID不能为空'
                       }
                   }
           },   
           
           eMsName:{
               validators: {
                     notEmpty: {
                         message: 'eMsName不能为空'
                     }
                 }
           },   
         fMsPositionCode:{
               validators: {
                     notEmpty: {
                         message: 'fMsPositionCode不能为空'
                     }
                 }
         },   
         
         fMsPositionTitle:{
             validators: {
                   notEmpty: {
                       message: 'fMsPositionTitle不能为空'
                   }
               }
       },   
       
       fMsStaffID:{
           validators: {
                 notEmpty: {
                     message: 'fMsStaffID不能为空'
                 }
             }
        },   
        
        
        fMsName:{
            validators: {
                  notEmpty: {
                      message: 'fMsName不能为空'
                  }
              }
      },   
      
      jobTitle:{
          validators: {
                notEmpty: {
                    message: 'jobTitle不能为空'
                }
            }
    },   
    
    legacyJobcode:{
        validators: {
              notEmpty: {
                  message: 'legacyJobcode不能为空'
              }
          }
     },   
     
     
     
     
     hRL1Descr:{
         validators: {
               notEmpty: {
                   message: 'hRL1Descr不能为空'
               }
           }
   },   
   
   hRL2Descr:{
       validators: {
             notEmpty: {
                 message: 'hRL2Descr不能为空'
             }
         }
    },   
    
    
    hRL3Descr:{
        validators: {
              notEmpty: {
                  message: 'hRL3Descr不能为空'
              }
          }
  },   
  
  hRL4Descr:{
      validators: {
            notEmpty: {
                message: 'hRL4Descr不能为空'
            }
        }
},   

hRL5Descr:{
    validators: {
          notEmpty: {
              message: 'hRL5Descr不能为空'
          }
      }
 },   
     
     
     
   },
          
         
          submitHandler: function (validator, form, submitButton) {
        	 var ids1 =form.serialize();
        		addproduct(ids1);
        	 
  		
  		
          }
      });
	  
	function addproduct(ids1){
		$.ajax({
			type : "POST",
			url:path+"/UserManageController/insertA.do",// 后台请求URL地址
			data : ids1,
			dataType : "json",
			success : function(data) {
			  if(data=="1"){
				  alert("添加成功，数据已添加到中间表");
				  url="userAdd.jsp";
				  toback(url);
			  }
			  if(data=="2"){
				  alert("添加成功");
				  url="userAdd.jsp";
				  toback(url);
			  }
			  
			  
			},
			error : function() {
				alert("plus failed");
			}
		});
	}

	  function addParam(ids1){
	  		// 去取参数
	  		var qualificationInfo = $("#com").children(
	  				"tr");
	  		 var ic=$("#agentcom").val();
	  		var count=false;
	  		for (var i = 0; i < qualificationInfo.length; i++) {

	  			var tdArr = qualificationInfo.eq(i).find("td");
	  			
	  			var fundname = tdArr.eq(0).find('input').val();
	  			var fundcode = tdArr.eq(1).find('input').val();
	  			var riskrating = tdArr.eq(2).find('input').val();
	  			
	  			//校验
	  			if(riskrating == ''||riskrating == null){
	  				alert("风险等级不能为空");
	  				$('#form').bootstrapValidator('disableSubmitButtons', false);  
	  				count=false;
	  				return;
	  			}if(riskrating != ''||riskrating !=null){
	  				count=true;
	  				
	  			}
	  		
	   }
	  		if(count){
	  			for (var i = 0; i < qualificationInfo.length; i++) {

		  			var tdArr = qualificationInfo.eq(i).find("td");
		  			var fundname = tdArr.eq(0).find('input').val();
		  			var fundcode = tdArr.eq(1).find('input').val();
		  			var riskrating = tdArr.eq(2).find('input').val();
		  		insertParam(ic,fundname,fundcode,riskrating,qualificationInfo.length-1,i,ids1);
	  			}
	  		}else{
  				alert('false');
  			}
	  }


	  function insertParam(ic,fundname,fundcode,riskrating,i,j,ids1){
	  	
	  	$.ajax({
	  			type : "POST",
	  			url:path+"/JoinaccountaController/saveAddBean.do",// 后台请求URL地址
	  			data :"ic="+ic+"&fundname="+fundname+"&fundcode="+fundcode+"&riskrating="+riskrating,
	  			dataType : "json",
	  			success : function(data) {
	  				if(data=="1"&&i==j){
	  					alert("投连险账户添加成功");
	  					addproduct(ids1);
	  				}
	  			},
	  			error : function() {
	  				alert("plus failed");
	  			}
	  		});
	  }
	  

});
