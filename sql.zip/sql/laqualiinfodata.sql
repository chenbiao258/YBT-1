prompt PL/SQL Developer import file
prompt Created on 2017��10��31�� by LRH
set feedback off
set define off
prompt Creating LAQUALIINFO...
drop table LAQUALIINFO;
create table LAQUALIINFO
(
  QUALIFITYPECODE VARCHAR2(60) not null,
  QUALIFITYPE     VARCHAR2(120) not null,
  CERTIFICATE     VARCHAR2(120) not null,
  CERTIFICATECODE VARCHAR2(60) not null,
  FLAG            VARCHAR2(1) not null,
  MAKEDATE        DATE not null,
  MAKETIME        VARCHAR2(8) not null,
  MODIFYDATE      DATE not null,
  MODIFYTIME      VARCHAR2(8) not null
)
;
alter table LAQUALIINFO
  add constraint PK_LAQUALIINFO primary key (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE);

prompt Loading LAQUALIINFO...
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00096', 'Insurance-nonILI Accreditation', 'All-in-One (Sales)', 'YBT0001', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:59:28', to_date('30-10-2017', 'dd-mm-yyyy'), '20:59:28');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00096', 'Insurance-nonILI Accreditation', 'PVC policy ElSHHning Assessment (Module 3)', 'YBT0013', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:59:43', to_date('30-10-2017', 'dd-mm-yyyy'), '20:59:43');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00096', 'Insurance-nonILI Accreditation', 'Y2016 20H', 'YBT0016', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:59:43', to_date('30-10-2017', 'dd-mm-yyyy'), '20:59:43');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00095', 'Insurance-ILI Accreditation', 'All-in-One (Sales)', 'YBT0001', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:00:40', to_date('30-10-2017', 'dd-mm-yyyy'), '21:00:40');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00095', 'Insurance-ILI Accreditation', 'Insurance-nonILI Accreditation', 'CNL00096' || chr(10) || '', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:10:22', to_date('30-10-2017', 'dd-mm-yyyy'), '21:10:22');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00098', 'HML ArrangerAccreditation Cert', 'HML EXAM', 'YBT0004', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:10:49', to_date('30-10-2017', 'dd-mm-yyyy'), '21:10:49');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00094', 'QDII Accreditation Certificate', 'Y2016 20H', 'YBT0016', 'N', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:06', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:06');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00094', 'QDII Accreditation Certificate', 'All-in-One (Sales)', 'YBT0001', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:50:53', to_date('30-10-2017', 'dd-mm-yyyy'), '20:50:53');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00094', 'QDII Accreditation Certificate', 'PVC policy ElSHHning Assessment (Module 3)', 'YBT0013', 'N', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:06', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:06');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00122', 'UT Accreditation', 'Fund Fundamental Knowledge' || chr(10) || '', 'CNL00132' || chr(10) || '', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '11:02:54', to_date('31-10-2017', 'dd-mm-yyyy'), '11:02:54');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00122', 'UT Accreditation', 'IAC InsuranceSales Qualif Test', 'CNL00133' || chr(10) || '', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '11:02:54', to_date('31-10-2017', 'dd-mm-yyyy'), '11:02:54');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00092', 'DCI Accreditation Certificate', 'Insurance-nonILI Accreditation', 'CNL00096' || chr(10) || '', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '11:03:11', to_date('31-10-2017', 'dd-mm-yyyy'), '11:03:11');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00093', 'Structured Inv Accreditation', 'SAC - Sec Fundmental Knowledge', 'CNL00073', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '11:27:12', to_date('31-10-2017', 'dd-mm-yyyy'), '11:27:12');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00093', 'Structured Inv Accreditation', 'SAC - Sec Fund', 'CNL00084', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '11:27:12', to_date('31-10-2017', 'dd-mm-yyyy'), '11:27:12');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00093', 'Structured Inv Accreditation', 'Cert of CHN Insurance Agent', 'CNL00080', 'Y', to_date('31-10-2017', 'dd-mm-yyyy'), '11:27:12', to_date('31-10-2017', 'dd-mm-yyyy'), '11:27:12');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00093' || chr(10) || '', 'Structured Inv Accreditation' || chr(10) || '', 'Y2016 20H', 'YBT0016' || chr(10) || '', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:35:12', to_date('30-10-2017', 'dd-mm-yyyy'), '20:35:12');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00093' || chr(10) || '', 'Structured Inv Accreditation' || chr(10) || '', 'PVC policy ElSHHning Assessment (3 Module)' || chr(10) || '', 'YBT0013', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:35:12', to_date('30-10-2017', 'dd-mm-yyyy'), '20:35:12');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00093' || chr(10) || '', 'Structured Inv Accreditation' || chr(10) || '', 'All-in-One (Sales)', 'YBT0001' || chr(10) || '', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:35:12', to_date('30-10-2017', 'dd-mm-yyyy'), '20:35:12');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00092', 'DCI Accreditation Certificate', 'All-in-One (Sales)', 'YBT0001', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:49:31', to_date('30-10-2017', 'dd-mm-yyyy'), '20:49:31');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00092', 'DCI Accreditation Certificate', 'Y2016 20H', 'YBT0016', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:49:44', to_date('30-10-2017', 'dd-mm-yyyy'), '20:49:44');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00092', 'DCI Accreditation Certificate', 'PVC policy ElSHHning Assessment (Module 3)', 'YBT0013', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:49:44', to_date('30-10-2017', 'dd-mm-yyyy'), '20:49:44');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00106', 'QDII Bond Sales Certificate', 'All-in-One (Sales)', 'YBT0001', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:33', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:33');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00106', 'QDII Bond Sales Certificate', 'PVC policy ElSHHning Assessment (Module 3)', 'YBT0013', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:45', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:45');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00106', 'QDII Bond Sales Certificate', 'Y2016 20H', 'YBT0016', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:45', to_date('30-10-2017', 'dd-mm-yyyy'), '20:51:45');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00122', 'UT Accreditation', 'All-in-One (Sales)', 'YBT0001', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:52:25', to_date('30-10-2017', 'dd-mm-yyyy'), '20:52:25');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00122', 'UT Accreditation', 'PVC policy ElSHHning Assessment (Module 3)', 'YBT0013', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:52:41', to_date('30-10-2017', 'dd-mm-yyyy'), '20:52:41');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00122', 'UT Accreditation', 'Y2016 20H', 'YBT0016', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:52:41', to_date('30-10-2017', 'dd-mm-yyyy'), '20:52:41');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00122', 'UT Accreditation', 'Local UT-UnitTrust SalesQualif', 'CNL00089' || chr(10) || '', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '20:58:28', to_date('30-10-2017', 'dd-mm-yyyy'), '20:58:28');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00096', 'Insurance-nonILI Accreditation', 'IAC InsuranceSales Qualif Test', 'CNL00133' || chr(10) || '', 'N', to_date('30-10-2017', 'dd-mm-yyyy'), '21:00:14', to_date('30-10-2017', 'dd-mm-yyyy'), '21:00:14');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00095', 'Insurance-ILI Accreditation', 'PVC policy ElSHHning Assessment (Module 3)', 'YBT0013', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:01:08', to_date('30-10-2017', 'dd-mm-yyyy'), '21:01:08');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00095', 'Insurance-ILI Accreditation', '40hr ILI Pre-service', 'YBT0015', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:01:08', to_date('30-10-2017', 'dd-mm-yyyy'), '21:01:08');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00095', 'Insurance-ILI Accreditation', 'Y2016 20H', 'YBT0016', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:01:08', to_date('30-10-2017', 'dd-mm-yyyy'), '21:01:08');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00101', 'HML SlsSpecialistAccrdtn Cert', 'HML EXAM', 'YBT0004', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:11:13', to_date('30-10-2017', 'dd-mm-yyyy'), '21:11:13');
insert into LAQUALIINFO (QUALIFITYPECODE, QUALIFITYPE, CERTIFICATE, CERTIFICATECODE, FLAG, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('CNL00101', 'HML SlsSpecialistAccrdtn Cert', 'HML ROLE PLAY ', 'YBT0005', 'Y', to_date('30-10-2017', 'dd-mm-yyyy'), '21:11:13', to_date('30-10-2017', 'dd-mm-yyyy'), '21:11:13');
prompt 34 records loaded
set feedback on
set define on
prompt Done.
