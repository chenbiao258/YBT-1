prompt PL/SQL Developer import file
prompt Created on 2017��10��31�� by LRH
set feedback off
set define off

prompt Creating JOBCODE...

drop table JOBCODE;
create table JOBCODE
(
  JOBCODE    VARCHAR2(20),
  SALESROLE1 VARCHAR2(20),
  SALESROLE2 VARCHAR2(20)
)
;

prompt Loading JOBCODE...
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5482', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5525', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5538', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5550', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5551', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5552', 'REF', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5553', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5611', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5614', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5625', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5627', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5647', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5649', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5654', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5655', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5661', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5675', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5679', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5681', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5689', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5698', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5704', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5707', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5709', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5734', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HB1585', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HB2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HF0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HF1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HF1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HF1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HF4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HF4626', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ4815', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ4845', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5453', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5472', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('HZ5689', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN4626', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('JN5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('KM1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('KM4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB4848', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NB5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ4815', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('NJ5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD4815', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD4848', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD4956', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('QD5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('RR1292', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU0633', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU4334', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU5453', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SU5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY4626', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SY5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ0947', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ1676', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ2152', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ3258', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ3543', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ3862', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4359', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4574', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4575', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4583', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4619', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4845', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5065', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5203', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5274', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5390', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5391', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5425', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5427', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5429', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5435', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5474', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5479', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5481', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5482', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5491', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5492', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5493', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5523', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5525', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5538', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5545', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5550', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5551', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5552', 'REF', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5553', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5554', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5624', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5627', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5631', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5641', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5642', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5643', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5651', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5654', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5655', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5661', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5669', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5675', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5677', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5678', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5679', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5689', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5692', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5707', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5714', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5716', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5727', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5732', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5734', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5760', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5801', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('SZ5824', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TJ5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TS1585', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TS4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY4626', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('TY5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WH5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WX0633', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('WX5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XA5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('XM5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('ZZ1585', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('ZZ1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('ZZ2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1615', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ1676', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ2444', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ3543', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4334', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4359', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4619', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4629', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4815', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4845', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4868', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ4869', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5224', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5274', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5432', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5435', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5453', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5479', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5481', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5482', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5525', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5538', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5550', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5551', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5552', 'REF', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5553', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5654', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5669', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5675', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('BJ5689', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5453', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CD5820', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN0005', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN0633', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1615', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN1676', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN2444', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN3461', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN3543', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN3550', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN3857', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4334', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4359', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4574', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4576', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4596', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4619', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4629', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4638', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4765', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4767', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4775', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4776', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4777', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4815', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4848', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4868', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4869', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4910', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4911', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4939', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN4956', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5016', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5152', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5203', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5217', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5274', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5324', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5341', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5388', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5435', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5445', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5446', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5447', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5448', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5451', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5452', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5453', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5472', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5479', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5481', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5482', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5491', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5498', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5523', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5525', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5526', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5527', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5528', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5531', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5538', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5546', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5550', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5551', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5552', 'REF', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5553', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5571', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5572', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5594', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5595', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5619', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5624', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5654', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5669', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5675', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5676', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5680', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5683', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5684', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5687', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5688', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5689', 'Y', 'Y5(only insurance)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5690', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5691', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5704', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5731', 'Y', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5747', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5784', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5785', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5805', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5806', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CN5807', 'N', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ5486', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ5487', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CQ5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CS1585', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CS1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('CS4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1585', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG1676', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DG5679', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL2416', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL5646', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('DL5821', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10011', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10298', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10333', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10512', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10514', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10515', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10522', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10523', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10524', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10525', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10527', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10530', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10532', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10533', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10535', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10539', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10540', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10543', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10544', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10545', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10547', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10548', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10549', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10552', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10554', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10555', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10561', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10563', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10564', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10565', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10566', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10567', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10568', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10569', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10570', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10572', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10573', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10574', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10575', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10578', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10580', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10581', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F10582', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F11658', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F11659', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F11797', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F11922', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F11923', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('F11924', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS4765', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS4767', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS4775', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS4777', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS4911', 'N', 'CCSS(VRM)');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5016', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5324', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5388', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5447', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5448', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5450', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5531', 'REF', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5550', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5551', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5553', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5619', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5679', 'N', 'RBB');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5686', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5688', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5728', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5731', 'Y', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5742', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5781', 'Y', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5782', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('FS5960', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD0633', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD0947', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1091', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1585', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1676', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD1763', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD2325', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD2808', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4276', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4329', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4460', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4481', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD4837', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5307', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5404', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5449', 'N', 'CCSS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5472', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5488', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5490', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5543', 'Y', 'Y1');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5583', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5796', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5797', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5798', 'N', 'RCS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5822', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GD5823', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ0106', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ0566', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1036', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1037', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1038', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1181', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1182', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1183', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1263', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1351', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1615', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1632', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ1676', 'REF', 'REF');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ2001', 'HML', 'HMA');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ2444', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ2605', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ3466', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ3543', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ3796', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4281', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4334', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4359', 'Y', 'Y');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4631', 'HML', 'HML');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4815', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4845', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4847', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ4868', 'Wealth Sales', 'Wealth Sales');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5095', 'Y', 'Y4');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5419', 'N', 'N');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5432', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5472', 'HML', 'HMS');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5479', 'Y', 'Card');
insert into JOBCODE (JOBCODE, SALESROLE1, SALESROLE2)
values ('GZ5481', 'N', 'Card');
prompt 712 records loaded
set feedback on
set define on
prompt Done.
