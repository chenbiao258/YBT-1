prompt PL/SQL Developer import file
prompt Created on 2017��10��30�� by LRH
set feedback off
set define off
prompt Creating LDCODE...

delete from ldcode where codetype='othertraining';
commit;
prompt Loading LDCODE...
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0001', 'All-in-One (Sales)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0002', 'All-in-One (Referral)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0003', 'Accoount Opening', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0004', 'HML EXAM', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0005', 'HML ROLE PLAY & CASE STUDY', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0006', '2010 HML waiver', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0007', 'Credit Card Accreditation Assessment', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0008', 'AMAC Approval', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0009', 'E-lSHHning Asset allocation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0010', 'E-LSHHning Portfolio Theory-The Markowitz Model', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0011', 'Classroom Training and accreditation (F220)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0012', 'SFPv2.5(A143)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0013', 'PVC policy ElSHHning Assessment (Module 3)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0014', '��ֹ�ɵ� (F193)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0015', '40hr ILI Pre-service', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0016', 'Y2016 20H', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0017', 'Y2016 20h Process', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0018', 'Y2017 20H(completion date)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0019', 'Y2017 20h Process', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0020', 'Investment Jouney(B129)', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0021', 'Suspension Event ' || chr(10) || '', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0022' || chr(10) || '', 'Suspension effective Date' || chr(10) || '', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('othertraining', 'YBT0023' || chr(10) || '', ' Suspended accreditation' || chr(10) || '', null, null, null);
prompt 23 records loaded
set feedback on
set define on
prompt Done.
