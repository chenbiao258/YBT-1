prompt PL/SQL Developer import file
prompt Created on 2017��10��31�� by LRH
set feedback off
set define off
prompt Creating LDCODE...
delete from ldcode where codetype='natural';
commit;

prompt Loading LDCODE...
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00073', 'SAC - Sec Fundmental Knowledge', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00080' || chr(10) || '', 'Cert of CHN Insurance Agent' || chr(10) || '', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00084', 'SAC - Sec Fund', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00089' || chr(10) || '', 'Local UT-UnitTrust SalesQualif', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00096' || chr(10) || '', 'Insurance-nonILI Accreditation', '5', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00131' || chr(10) || '', 'Fund Law&Regltn Ethics&Conduct' || chr(10) || '', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00132' || chr(10) || '', 'Fund Fundamental Knowledge' || chr(10) || '', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'CNL00133' || chr(10) || '', 'IAC InsuranceSales Qualif Test', '1', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'YBT0008' || chr(10) || '', 'AMAC Approval' || chr(10) || '', '4', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'YBT0021', 'Suspension Event ' || chr(10) || '', '4', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'YBT0022' || chr(10) || '', 'Suspension effective Date' || chr(10) || '', '4', null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('natural', 'YBT0023' || chr(10) || '', 'Suspended accreditation' || chr(10) || '', '4', null, null);
prompt 12 records loaded
set feedback on
set define on
prompt Done.
