prompt PL/SQL Developer import file
prompt Created on 2017��10��31�� by LRH
set feedback off
set define off
prompt Creating LDCODE...
delete from ldcode where codetype='laqualiinfo';
commit;


prompt Loading LDCODE...
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00093', 'Structured Inv Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00092', 'DCI Accreditation Certificate', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00094', 'QDII Accreditation Certificate', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00106', 'QDII Bond Sales Certificate', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00122', 'UT Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00096', 'Insurance-nonILI Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00095', 'Insurance-ILI Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00098', 'HML ArrangerAccreditation Cert', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00137', 'PAS Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00101', 'HML SlsSpecialistAccrdtn Cert', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00110', 'QDII Independent Sell Cert', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00126', 'UT Independent Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00111', 'ILI Independent Sell Cert', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00118', 'BQA Accreditation', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00108', 'InvReferral Accreditation Cert', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00102', 'Ins. ReferralAccreditationCert', null, null, null);
insert into LDCODE (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('laqualiinfo', 'CNL00107', 'HML Coordinator Certificate', null, null, null);
prompt 17 records loaded
set feedback on
set define on
prompt Done.
