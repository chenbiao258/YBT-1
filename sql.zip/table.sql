-------------------------------------------------
-- Export file for user YBT_UAT                    --
-- Created by suojinyu on 2017/10/27, 16:57:38 --
-------------------------------------------------

set define off
spool table.log

prompt
prompt Creating table AREACODEFULL
prompt ===========================
prompt
create table YBT_UAT.AREACODEFULL
(
  citycode VARCHAR2(20) not null,
  cityname VARCHAR2(100),
  operator VARCHAR2(50),
  makedate DATE,
  maketime VARCHAR2(50),
  bak1     VARCHAR2(50),
  bak2     VARCHAR2(50),
  bak3     VARCHAR2(50)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.AREACODEFULL
  add constraint PK_AREACODEFULL primary key (CITYCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table PROVINCE
prompt =======================
prompt
create table YBT_UAT.PROVINCE
(
  provinceid   NUMBER(5) not null,
  provincename VARCHAR2(50)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.PROVINCE
  add primary key (PROVINCEID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table CITY
prompt ===================
prompt
create table YBT_UAT.CITY
(
  cityid     NUMBER(5) not null,
  cityname   VARCHAR2(50),
  zipcode    VARCHAR2(50),
  provinceid NUMBER(5)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.CITY
  add primary key (CITYID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.CITY
  add constraint FOR_PROVINCEID foreign key (PROVINCEID)
  references YBT_UAT.PROVINCE (PROVINCEID) on delete cascade;

prompt
prompt Creating table COMPANYNAME
prompt ==========================
prompt
create table YBT_UAT.COMPANYNAME
(
  companynameid VARCHAR2(20) not null,
  companyname   VARCHAR2(100),
  cityid        VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.COMPANYNAME
  add constraint PK_COMPANYNAME primary key (COMPANYNAMEID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table COUNTY
prompt =====================
prompt
create table YBT_UAT.COUNTY
(
  countyid   NUMBER(5) not null,
  countyname VARCHAR2(50),
  cityid     NUMBER(5)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.COUNTY
  add primary key (COUNTYID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.COUNTY
  add constraint FOR_CITYID foreign key (CITYID)
  references YBT_UAT.CITY (CITYID) on delete cascade;

prompt
prompt Creating table DEPARTMENT
prompt =========================
prompt
create table YBT_UAT.DEPARTMENT
(
  departmentid  VARCHAR2(20) not null,
  department    VARCHAR2(100),
  companynameid VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.DEPARTMENT
  add constraint PK_DEPARTMENT primary key (DEPARTMENTID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table DETAILALL
prompt ========================
prompt
create table YBT_UAT.DETAILALL
(
  transno  VARCHAR2(120),
  staffid  VARCHAR2(8),
  flag     VARCHAR2(5),
  descs    VARCHAR2(200),
  fileid   VARCHAR2(100),
  operator VARCHAR2(30),
  makedate DATE,
  maketime VARCHAR2(22)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table EXTERNALGIFTS
prompt ============================
prompt
create table YBT_UAT.EXTERNALGIFTS
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table EXTERNALGIFTSA
prompt =============================
prompt
create table YBT_UAT.EXTERNALGIFTSA
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null,
  checkflag                   VARCHAR2(30) default 'W'
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table EXTERNALGIFTSB
prompt =============================
prompt
create table YBT_UAT.EXTERNALGIFTSB
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HESITATIONTOBANK
prompt ===============================
prompt
create table YBT_UAT.HESITATIONTOBANK
(
  transno      VARCHAR2(20) not null,
  insurancecom VARCHAR2(20),
  bankcode     VARCHAR2(20),
  totalcount   INTEGER,
  totalmoney   NUMBER(15,2),
  succmoney    NUMBER(15,2),
  succcount    INTEGER,
  state        VARCHAR2(10),
  makedate     VARCHAR2(8),
  maketime     VARCHAR2(10),
  bak1         VARCHAR2(100),
  bak2         VARCHAR2(100),
  bak3         VARCHAR2(100),
  bak4         VARCHAR2(100),
  bak5         VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.HESITATIONTOBANK
  add primary key (TRANSNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HESITATIONTOBANKDETAIL
prompt =====================================
prompt
create table YBT_UAT.HESITATIONTOBANKDETAIL
(
  transno         VARCHAR2(20) not null,
  insurancecom    VARCHAR2(20),
  bankcode        VARCHAR2(10),
  proposalcontno  VARCHAR2(12),
  hesitationmoney NUMBER(15,2),
  succflag        VARCHAR2(2),
  state           VARCHAR2(10),
  makedate        VARCHAR2(8),
  maketime        VARCHAR2(10),
  bak1            VARCHAR2(100),
  bak2            VARCHAR2(100),
  bak3            VARCHAR2(100),
  bak4            VARCHAR2(100),
  bak5            VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HOLIDAY
prompt ======================
prompt
create table YBT_UAT.HOLIDAY
(
  seqnumber VARCHAR2(20) not null,
  holiday   VARCHAR2(20),
  workday   DATE,
  flag      VARCHAR2(2),
  operator  VARCHAR2(30),
  bak1      VARCHAR2(20),
  bak2      VARCHAR2(20),
  bak3      VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.HOLIDAY
  add constraint PK_HOLIDAY primary key (SEQNUMBER)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HOLIDAYA
prompt =======================
prompt
create table YBT_UAT.HOLIDAYA
(
  seqnumber VARCHAR2(20) not null,
  holiday   VARCHAR2(20),
  workday   DATE,
  flag      VARCHAR2(2),
  operator  VARCHAR2(30),
  bak1      VARCHAR2(20),
  bak2      VARCHAR2(20),
  bak3      VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.HOLIDAYA
  add constraint PK_HOLIDAYA primary key (SEQNUMBER)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table HOLIDAYB
prompt =======================
prompt
create table YBT_UAT.HOLIDAYB
(
  seqnumber VARCHAR2(20) not null,
  holiday   VARCHAR2(20),
  workday   DATE,
  flag      VARCHAR2(2),
  operator  VARCHAR2(30),
  bak1      VARCHAR2(20),
  bak2      VARCHAR2(20),
  bak3      VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table IMPARTCONTENT
prompt ============================
prompt
create table YBT_UAT.IMPARTCONTENT
(
  contnoimpartcode     VARCHAR2(40) not null,
  transno              VARCHAR2(20),
  contno               VARCHAR2(20),
  insuredcompany       VARCHAR2(1000),
  impartcode           VARCHAR2(1000),
  insuredimpart        VARCHAR2(1000),
  ownerimpart          VARCHAR2(1000),
  insuredyesorno       VARCHAR2(2),
  owneryesorno         VARCHAR2(2),
  impartno             VARCHAR2(40),
  insuredyesornoimpart VARCHAR2(1000)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.IMPARTCONTENT
  add constraint PK_IMPARTCONTENT primary key (CONTNOIMPARTCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table JOBCODE
prompt ======================
prompt
create table YBT_UAT.JOBCODE
(
  jobcode    VARCHAR2(20),
  salesrole1 VARCHAR2(20),
  salesrole2 VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table JOINACCOUNT
prompt ==========================
prompt
create table YBT_UAT.JOINACCOUNT
(
  ic         VARCHAR2(20) not null,
  fundname   VARCHAR2(120) not null,
  fundcode   VARCHAR2(20),
  riskrating VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.JOINACCOUNT
  add constraint PK_JOINACCOUNT primary key (IC, FUNDNAME)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table JOINACCOUNTA
prompt ===========================
prompt
create table YBT_UAT.JOINACCOUNTA
(
  ic         VARCHAR2(20) not null,
  fundname   VARCHAR2(120) not null,
  fundcode   VARCHAR2(20),
  riskrating VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.JOINACCOUNTA
  add constraint PK_JOINACCOUNTA primary key (IC, FUNDNAME)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table JOINACCOUNTB
prompt ===========================
prompt
create table YBT_UAT.JOINACCOUNTB
(
  ic         VARCHAR2(20),
  fundname   VARCHAR2(120),
  fundcode   VARCHAR2(20),
  riskrating VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAAGENT
prompt ======================
prompt
create table YBT_UAT.LAAGENT
(
  staffid            VARCHAR2(20) not null,
  region             VARCHAR2(22),
  locationcode       VARCHAR2(22),
  city               VARCHAR2(10),
  subbranch          VARCHAR2(10),
  companyname        VARCHAR2(40),
  department         VARCHAR2(40),
  name               VARCHAR2(20) not null,
  preferredfirstname VARCHAR2(20),
  jobcode            VARCHAR2(20),
  positiontitle      VARCHAR2(40),
  checkflag          VARCHAR2(10),
  salesrole          VARCHAR2(40),
  actnrsneffdt       DATE,
  hiredate           DATE,
  rehiredate         DATE
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAAGENT
  add constraint PK_LAAGENT primary key (STAFFID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAAGENTA
prompt =======================
prompt
create table YBT_UAT.LAAGENTA
(
  staffid            VARCHAR2(20) not null,
  region             VARCHAR2(22),
  locationcode       VARCHAR2(22),
  city               VARCHAR2(10),
  subbranch          VARCHAR2(10),
  companyname        VARCHAR2(40),
  department         VARCHAR2(40),
  name               VARCHAR2(20) not null,
  preferredfirstname VARCHAR2(20),
  jobcode            VARCHAR2(20),
  positiontitle      VARCHAR2(40),
  checkflag          VARCHAR2(10),
  salesrole          VARCHAR2(40),
  actnrsneffdt       DATE,
  hiredate           DATE,
  rehiredate         DATE
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAAGENTA
  add constraint PK_LAAGENTA primary key (STAFFID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAAGENTB
prompt =======================
prompt
create table YBT_UAT.LAAGENTB
(
  staffid            VARCHAR2(20) not null,
  region             VARCHAR2(22),
  locationcode       VARCHAR2(22),
  city               VARCHAR2(10),
  subbranch          VARCHAR2(10),
  companyname        VARCHAR2(40),
  department         VARCHAR2(40),
  name               VARCHAR2(20) not null,
  preferredfirstname VARCHAR2(20),
  jobcode            VARCHAR2(20),
  positiontitle      VARCHAR2(40),
  checkflag          VARCHAR2(10),
  salesrole          VARCHAR2(40),
  actnrsneffdt       DATE,
  hiredate           DATE,
  rehiredate         DATE
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAAUTHORIZE
prompt ==========================
prompt
create table YBT_UAT.LAAUTHORIZE
(
  riskcode        VARCHAR2(10) not null,
  insurancecom    VARCHAR2(20) not null,
  authorobj       VARCHAR2(20) not null,
  authortype      VARCHAR2(2) not null,
  authorflow      VARCHAR2(2) not null,
  authorstartdate DATE,
  authorenddate   DATE,
  operator        VARCHAR2(20) not null,
  makedate        DATE,
  maketime        VARCHAR2(8),
  modifydate      DATE,
  modifytime      VARCHAR2(8),
  branchtype      VARCHAR2(2) not null,
  risktype        VARCHAR2(2) not null,
  risktypename    VARCHAR2(50),
  branchattr      VARCHAR2(20),
  agentcode       VARCHAR2(10),
  branchtype2     VARCHAR2(2),
  isnullproduct   VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LAAUTHORIZE.authortype
  is '0-��ҵ��Ա��Ȩ
1-��ְ����Ȩ
2-��������Ȩ';
comment on column YBT_UAT.LAAUTHORIZE.authorflow
  is '01-�����������ۣ�
02-���򣨽�ֹ���ۣ�';
comment on column YBT_UAT.LAAUTHORIZE.branchtype
  is 'չҵ����(1-����Ӫ����2-���գ�3�����б��գ�9������)';
comment on column YBT_UAT.LAAUTHORIZE.risktype
  is 'L--����(Life)��
A--������(Accident)��
H--������(Health)"
';
comment on column YBT_UAT.LAAUTHORIZE.branchtype2
  is '01 or null -ֱ��
02-�н�
03-��������';
alter table YBT_UAT.LAAUTHORIZE
  add constraint PK_LAAUTHORIZE primary key (RISKCODE, AUTHOROBJ, AUTHORTYPE, INSURANCECOM)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAAUTHORIZEA
prompt ===========================
prompt
create table YBT_UAT.LAAUTHORIZEA
(
  riskcode        VARCHAR2(10) not null,
  insurancecom    VARCHAR2(20) not null,
  authorobj       VARCHAR2(20) not null,
  authortype      VARCHAR2(2) not null,
  authorflow      VARCHAR2(2) not null,
  authorstartdate DATE,
  authorenddate   DATE,
  operator        VARCHAR2(20) not null,
  makedate        DATE,
  maketime        VARCHAR2(8),
  modifydate      DATE,
  modifytime      VARCHAR2(8),
  branchtype      VARCHAR2(2) not null,
  risktype        VARCHAR2(2) not null,
  risktypename    VARCHAR2(50),
  branchattr      VARCHAR2(20),
  agentcode       VARCHAR2(10),
  branchtype2     VARCHAR2(2),
  isnullproduct   VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAAUTHORIZEA
  add constraint PK_LAAUTHORIZEA primary key (RISKCODE, INSURANCECOM, AUTHOROBJ, AUTHORTYPE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAAUTHORIZEB
prompt ===========================
prompt
create table YBT_UAT.LAAUTHORIZEB
(
  riskcode        VARCHAR2(10) not null,
  insurancecom    VARCHAR2(20) not null,
  authorobj       VARCHAR2(20) not null,
  authortype      VARCHAR2(2) not null,
  authorflow      VARCHAR2(2) not null,
  authorstartdate DATE,
  authorenddate   DATE,
  operator        VARCHAR2(20) not null,
  makedate        DATE,
  maketime        VARCHAR2(8),
  modifydate      DATE,
  modifytime      VARCHAR2(8),
  branchtype      VARCHAR2(2) not null,
  risktype        VARCHAR2(2) not null,
  risktypename    VARCHAR2(50),
  branchattr      VARCHAR2(20),
  agentcode       VARCHAR2(10),
  branchtype2     VARCHAR2(2),
  isnullproduct   VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LACOM
prompt ====================
prompt
create table YBT_UAT.LACOM
(
  agentcom         VARCHAR2(20) not null,
  name             VARCHAR2(60) not null,
  states           VARCHAR2(1),
  cooperationdate  DATE,
  channeltype      VARCHAR2(2),
  licensestartdate DATE,
  operator         VARCHAR2(20) not null,
  remark           VARCHAR2(200),
  amend            VARCHAR2(1),
  makedate         DATE,
  maketime         VARCHAR2(8),
  modifydate       DATE,
  modifytime       VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LACOM
  add constraint PK_LACOM primary key (AGENTCOM, NAME)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LACOMA
prompt =====================
prompt
create table YBT_UAT.LACOMA
(
  agentcom         VARCHAR2(20) not null,
  name             VARCHAR2(60) not null,
  states           VARCHAR2(1),
  cooperationdate  DATE,
  channeltype      VARCHAR2(2),
  licensestartdate DATE,
  operator         VARCHAR2(20) not null,
  remark           VARCHAR2(200),
  amend            VARCHAR2(1),
  makedate         DATE,
  maketime         VARCHAR2(8),
  modifydate       DATE,
  modifytime       VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LACOMA
  add constraint PK_LACOMA primary key (AGENTCOM, NAME)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LACOMB
prompt =====================
prompt
create table YBT_UAT.LACOMB
(
  agentcom         VARCHAR2(20) not null,
  name             VARCHAR2(60),
  states           VARCHAR2(1),
  cooperationdate  DATE,
  channeltype      VARCHAR2(2),
  licensestartdate DATE,
  operator         VARCHAR2(20) not null,
  remark           VARCHAR2(200),
  amend            VARCHAR2(1),
  makedate         DATE,
  maketime         VARCHAR2(8),
  modifydate       DATE,
  modifytime       VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAPRODQUALI
prompt ==========================
prompt
create table YBT_UAT.LAPRODQUALI
(
  riskcode    VARCHAR2(25) not null,
  qualifitype VARCHAR2(60) not null,
  flag        VARCHAR2(1) not null,
  makedate    DATE not null,
  maketime    VARCHAR2(8) not null,
  modifydate  DATE not null,
  modifytime  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAPRODQUALI
  add constraint PK_LAPRODQUALI primary key (RISKCODE, QUALIFITYPE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALIDETAIL
prompt ============================
prompt
create table YBT_UAT.LAQUALIDETAIL
(
  staffid     VARCHAR2(8) not null,
  certificate VARCHAR2(120) not null,
  getdate     DATE,
  status      VARCHAR2(1),
  makedate    DATE not null,
  maketime    VARCHAR2(8) not null,
  modifydate  DATE not null,
  modifytime  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAQUALIDETAIL
  add constraint PK_LAQUALIDETAIL primary key (STAFFID, CERTIFICATE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALIDETAILS
prompt =============================
prompt
create table YBT_UAT.LAQUALIDETAILS
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALIDETAILSA
prompt ==============================
prompt
create table YBT_UAT.LAQUALIDETAILSA
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null,
  checkflag                   VARCHAR2(30) default 'W'
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALIDETAILSB
prompt ==============================
prompt
create table YBT_UAT.LAQUALIDETAILSB
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALIFICATION
prompt ==============================
prompt
create table YBT_UAT.LAQUALIFICATION
(
  staffid       VARCHAR2(8) not null,
  qualifitype   VARCHAR2(60) not null,
  effectivedate DATE,
  status        VARCHAR2(1),
  makedate      DATE not null,
  maketime      VARCHAR2(8) not null,
  modifydate    DATE not null,
  modifytime    VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAQUALIFICATION
  add constraint PK_LAQUALIFICATION primary key (STAFFID, QUALIFITYPE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALIINFO
prompt ==========================
prompt
create table YBT_UAT.LAQUALIINFO
(
  qualifitype     VARCHAR2(60) not null,
  certificate     VARCHAR2(120) not null,
  certificatecode VARCHAR2(60) not null,
  flag            VARCHAR2(1) not null,
  makedate        DATE not null,
  maketime        VARCHAR2(8) not null,
  modifydate      DATE not null,
  modifytime      VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAQUALIINFO
  add constraint PK_LAQUALIINFO primary key (QUALIFITYPE, CERTIFICATE, CERTIFICATECODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LAQUALITRAIN
prompt ===========================
prompt
create table YBT_UAT.LAQUALITRAIN
(
  qualifiinfo  VARCHAR2(25) not null,
  trainingtype VARCHAR2(25) not null,
  flag         VARCHAR2(1),
  makedate     DATE not null,
  maketime     VARCHAR2(8) not null,
  modifydate   DATE not null,
  modifytime   VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LAQUALITRAIN
  add constraint PK_LAQUALITRAIN primary key (QUALIFIINFO, TRAININGTYPE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LATRAINCOURSE
prompt ============================
prompt
create table YBT_UAT.LATRAINCOURSE
(
  coursecode  VARCHAR2(60) not null,
  coursetitle VARCHAR2(160) not null,
  flag        VARCHAR2(1),
  makedate    DATE not null,
  maketime    VARCHAR2(8) not null,
  modifydate  DATE not null,
  modifytime  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LATRAINCOURSE
  add constraint PK_LATRAINCOURSE primary key (COURSECODE, COURSETITLE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LATRAINING
prompt =========================
prompt
create table YBT_UAT.LATRAINING
(
  id                 VARCHAR2(8),
  staffid            VARCHAR2(8) not null,
  name               VARCHAR2(100),
  preferredfirstname VARCHAR2(100),
  coursecode         VARCHAR2(100),
  coursetitle        VARCHAR2(160),
  insurancetype      VARCHAR2(60),
  trainingtype       VARCHAR2(20),
  trainingno         VARCHAR2(20),
  rate               VARCHAR2(3),
  hour               VARCHAR2(5),
  startdate          DATE,
  enddate            DATE,
  status             VARCHAR2(1),
  makedate           DATE not null,
  maketime           VARCHAR2(8) not null,
  modifydate         DATE not null,
  modifytime         VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCACCOUNTINFO
prompt ============================
prompt
create table YBT_UAT.LCACCOUNTINFO
(
  transno        VARCHAR2(30) not null,
  insurcecom     VARCHAR2(30) not null,
  proposalcontno VARCHAR2(30) not null,
  riskcode       VARCHAR2(30) not null,
  accno          VARCHAR2(30) not null,
  accrate        VARCHAR2(30),
  bak1           VARCHAR2(30),
  bak2           VARCHAR2(130),
  bak3           VARCHAR2(120),
  bak4           VARCHAR2(30),
  bak5           VARCHAR2(30)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LCACCOUNTINFO.transno
  is '���׺�';
comment on column YBT_UAT.LCACCOUNTINFO.insurcecom
  is 'CIFID';
comment on column YBT_UAT.LCACCOUNTINFO.proposalcontno
  is 'Ͷ������';
comment on column YBT_UAT.LCACCOUNTINFO.riskcode
  is '���ִ���';
comment on column YBT_UAT.LCACCOUNTINFO.accno
  is '�˺����ʹ���';
comment on column YBT_UAT.LCACCOUNTINFO.bak1
  is 'POLNO';
alter table YBT_UAT.LCACCOUNTINFO
  add constraint PK_LCACCOUNTINFO primary key (TRANSNO, PROPOSALCONTNO, RISKCODE, ACCNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCADDRESS
prompt ========================
prompt
create table YBT_UAT.LCADDRESS
(
  transno       VARCHAR2(35) not null,
  customerno    VARCHAR2(24) not null,
  addressno     INTEGER not null,
  postaladdress VARCHAR2(1000),
  zipcode       VARCHAR2(6),
  phone         VARCHAR2(30),
  homeaddress   VARCHAR2(1000),
  homezipcode   VARCHAR2(6),
  homephone     VARCHAR2(30),
  mobile        VARCHAR2(30),
  email         VARCHAR2(160),
  operator      VARCHAR2(50) not null,
  makedate      VARCHAR2(10) not null,
  maketime      VARCHAR2(10) not null,
  modifydate    VARCHAR2(10) not null,
  modifytime    VARCHAR2(10) not null,
  otheraddress  VARCHAR2(1000)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LCADDRESS.addressno
  is '��ַ���         0Ͷ���� 1������     ';
alter table YBT_UAT.LCADDRESS
  add constraint PK_LCADDRESS primary key (TRANSNO, CUSTOMERNO, ADDRESSNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCAPPNT
prompt ======================
prompt
create table YBT_UAT.LCAPPNT
(
  transno             VARCHAR2(35) not null,
  contno              VARCHAR2(20) not null,
  prtno               VARCHAR2(20),
  appntno             VARCHAR2(20),
  relationtolcinsured VARCHAR2(2),
  appntstartdate      DATE,
  appntname           VARCHAR2(120) not null,
  appntsex            VARCHAR2(1),
  appntbirthday       DATE,
  appntenddate        DATE,
  idtype              VARCHAR2(10),
  idno                VARCHAR2(20),
  nativeplace         VARCHAR2(10),
  idsubmit            VARCHAR2(2),
  rgtaddress          VARCHAR2(80),
  health              VARCHAR2(6),
  stature             NUMBER(5,2),
  avoirdupois         NUMBER(5,2),
  creditgrade         VARCHAR2(1),
  bankcode            VARCHAR2(10),
  bankaccno           VARCHAR2(40),
  accname             VARCHAR2(60),
  salary              NUMBER(12,2),
  occupationcode      VARCHAR2(10),
  company             VARCHAR2(40),
  responsibility      VARCHAR2(80),
  managecom           VARCHAR2(10),
  operator            VARCHAR2(10),
  makedate            DATE,
  maketime            VARCHAR2(20),
  modifydate          DATE,
  modifytime          VARCHAR2(10),
  grpcontno           VARCHAR2(20)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LCAPPNT.transno
  is '������ˮ��';
comment on column YBT_UAT.LCAPPNT.contno
  is 'Ͷ������';
comment on column YBT_UAT.LCAPPNT.prtno
  is 'Ͷ������';
comment on column YBT_UAT.LCAPPNT.appntno
  is 'Ͷ���˺�';
comment on column YBT_UAT.LCAPPNT.relationtolcinsured
  is '�뱻���˵Ĺ�ϵ';
comment on column YBT_UAT.LCAPPNT.appntstartdate
  is 'Ͷ����֤����Ч����';
comment on column YBT_UAT.LCAPPNT.appntname
  is 'Ͷ��������';
comment on column YBT_UAT.LCAPPNT.appntsex
  is 'Ͷ�����Ա�';
comment on column YBT_UAT.LCAPPNT.appntbirthday
  is 'Ͷ��������';
comment on column YBT_UAT.LCAPPNT.appntenddate
  is 'Ͷ����֤����Чֹ��';
comment on column YBT_UAT.LCAPPNT.idtype
  is '֤������';
comment on column YBT_UAT.LCAPPNT.idno
  is '֤������';
comment on column YBT_UAT.LCAPPNT.nativeplace
  is '����';
comment on column YBT_UAT.LCAPPNT.idsubmit
  is '�Ƿ��ύ��ʶ';
comment on column YBT_UAT.LCAPPNT.rgtaddress
  is 'Ͷ����������';
comment on column YBT_UAT.LCAPPNT.health
  is '���޽�����ʶ';
comment on column YBT_UAT.LCAPPNT.stature
  is '����';
comment on column YBT_UAT.LCAPPNT.avoirdupois
  is '����';
comment on column YBT_UAT.LCAPPNT.creditgrade
  is 'Ͷ���˾�ס����';
comment on column YBT_UAT.LCAPPNT.salary
  is 'Ͷ���˹���';
comment on column YBT_UAT.LCAPPNT.occupationcode
  is 'Ͷ����ְҵ����';
comment on column YBT_UAT.LCAPPNT.company
  is 'Ͷ���˹�����λ������';
comment on column YBT_UAT.LCAPPNT.responsibility
  is 'ְλ����������';
comment on column YBT_UAT.LCAPPNT.makedate
  is '��������';
comment on column YBT_UAT.LCAPPNT.maketime
  is '����ʱ��';
comment on column YBT_UAT.LCAPPNT.modifydate
  is '�޸�ʱ��';
comment on column YBT_UAT.LCAPPNT.modifytime
  is '�޸�����';
comment on column YBT_UAT.LCAPPNT.grpcontno
  is 'cif';
alter table YBT_UAT.LCAPPNT
  add constraint PK_LCAPPNT primary key (TRANSNO, CONTNO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCBNF
prompt ====================
prompt
create table YBT_UAT.LCBNF
(
  transno           VARCHAR2(35) not null,
  contno            VARCHAR2(20),
  polno             VARCHAR2(20) not null,
  insuredno         VARCHAR2(24) not null,
  bnftype           VARCHAR2(1) not null,
  bnfno             INTEGER not null,
  bnfgrade          VARCHAR2(1) not null,
  relationtoinsured VARCHAR2(2),
  bnflot            NUMBER(10,4),
  customerno        VARCHAR2(24),
  name              VARCHAR2(120),
  sex               VARCHAR2(1),
  birthday          DATE,
  idtype            VARCHAR2(2),
  idno              VARCHAR2(20),
  getform           VARCHAR2(1),
  getbankcode       VARCHAR2(10),
  getbankaccno      VARCHAR2(40),
  getaccname        VARCHAR2(60),
  operator          VARCHAR2(10),
  makedate          DATE,
  maketime          VARCHAR2(8),
  modifydate        DATE,
  modifytime        VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LCBNF
  add constraint PK_LCBNF primary key (POLNO, INSUREDNO, BNFTYPE, BNFNO, BNFGRADE, TRANSNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCCHECKTRACE
prompt ===========================
prompt
create table YBT_UAT.LCCHECKTRACE
(
  checkno     VARCHAR2(6) not null,
  checkedcode VARCHAR2(20),
  checkedname VARCHAR2(200),
  comcode     VARCHAR2(20),
  checker     VARCHAR2(20),
  checkdes    VARCHAR2(300),
  checktype   VARCHAR2(2),
  checkdate   DATE not null,
  checktime   VARCHAR2(10) not null,
  bak1        VARCHAR2(10),
  bak2        VARCHAR2(10)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LCCHECKTRACE
  add constraint PK_LCCHECKTRACE primary key (CHECKNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCCONT
prompt =====================
prompt
create table YBT_UAT.LCCONT
(
  transno            VARCHAR2(35) not null,
  contno             VARCHAR2(20) not null,
  proposalcontno     VARCHAR2(20),
  prtno              VARCHAR2(20),
  conttype           VARCHAR2(1),
  familytype         VARCHAR2(40),
  familyid           VARCHAR2(200),
  poltype            VARCHAR2(1),
  cardflag           VARCHAR2(1),
  managecom          VARCHAR2(10),
  executecom         VARCHAR2(10),
  agentcom           VARCHAR2(20),
  agentcode          VARCHAR2(10),
  agentgroup         VARCHAR2(40),
  agentcode1         VARCHAR2(200),
  agenttype          VARCHAR2(20),
  insurancecom       VARCHAR2(20),
  insurancemanagecom VARCHAR2(30),
  salechnl           VARCHAR2(2),
  handler            VARCHAR2(20),
  password           VARCHAR2(20),
  appntno            VARCHAR2(24),
  appntname          VARCHAR2(120),
  appntsex           VARCHAR2(1),
  appntbirthday      DATE,
  appntidtype        VARCHAR2(2),
  appntidno          VARCHAR2(20),
  insuredno          VARCHAR2(24),
  insuredname        VARCHAR2(120),
  insuredsex         VARCHAR2(1),
  insuredbirthday    DATE,
  insuredidtype      VARCHAR2(2),
  insuredidno        VARCHAR2(20),
  paylocation        VARCHAR2(1),
  outpayflag         VARCHAR2(20),
  getpolmode         VARCHAR2(1),
  signcom            VARCHAR2(10),
  signdate           DATE,
  signtime           VARCHAR2(8),
  bankcode           VARCHAR2(10),
  bankaccno          VARCHAR2(40),
  accname            VARCHAR2(60),
  printcount         INTEGER,
  losttimes          INTEGER,
  remark             VARCHAR2(1600),
  peoples            INTEGER,
  mult               NUMBER(20,5),
  prem               NUMBER(16,2),
  amnt               NUMBER(16,2),
  sumprem            NUMBER(16,2),
  firstpaydate       DATE,
  approvetime        VARCHAR2(20),
  appflag            VARCHAR2(2),
  polapplydate       DATE,
  state              VARCHAR2(10),
  firsttrialoperator VARCHAR2(10),
  firsttrialdate     DATE,
  firsttrialtime     VARCHAR2(8),
  receiveoperator    VARCHAR2(10),
  receivedate        DATE,
  chargerate         VARCHAR2(8),
  tempfeeno          VARCHAR2(20),
  selltype           VARCHAR2(2),
  forceuwflag        VARCHAR2(1),
  forceuwreason      VARCHAR2(500),
  newbankcode        VARCHAR2(10),
  newbankaccno       VARCHAR2(40),
  newaccname         VARCHAR2(60),
  newpaymode         VARCHAR2(1),
  agentbankcode      VARCHAR2(50),
  bankagent          VARCHAR2(50),
  organcomcode       VARCHAR2(30),
  operator           VARCHAR2(10),
  makedate           DATE,
  maketime           VARCHAR2(10),
  modifydate         DATE,
  modifytime         VARCHAR2(10),
  agentname          VARCHAR2(120),
  grpcontno          VARCHAR2(35),
  receivetime        VARCHAR2(3),
  riskcode           VARCHAR2(40),
  accountbalance     INTEGER,
  debitflag          VARCHAR2(10),
  delayeddebit       DATE,
  hesitationflag     VARCHAR2(10)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LCCONT.transno
  is '������ˮ��';
comment on column YBT_UAT.LCCONT.contno
  is 'Ͷ������';
comment on column YBT_UAT.LCCONT.proposalcontno
  is 'Ͷ������';
comment on column YBT_UAT.LCCONT.prtno
  is 'Ͷ������';
comment on column YBT_UAT.LCCONT.conttype
  is 'Ĭ��1';
comment on column YBT_UAT.LCCONT.poltype
  is 'Ĭ��0';
comment on column YBT_UAT.LCCONT.agentcode
  is '���ƾ�������';
comment on column YBT_UAT.LCCONT.insurancecom
  is '���չ�˾';
comment on column YBT_UAT.LCCONT.salechnl
  is 'Ĭ��д�� ';
comment on column YBT_UAT.LCCONT.appntno
  is 'Ͷ���˺� ��������';
comment on column YBT_UAT.LCCONT.appntname
  is 'Ͷ��������';
comment on column YBT_UAT.LCCONT.appntsex
  is 'Ͷ�������Ա�';
comment on column YBT_UAT.LCCONT.appntbirthday
  is 'Ͷ��������';
comment on column YBT_UAT.LCCONT.appntidtype
  is 'Ͷ����֤������';
comment on column YBT_UAT.LCCONT.appntidno
  is 'Ͷ����֤������';
comment on column YBT_UAT.LCCONT.insuredno
  is '�����˺ţ���������';
comment on column YBT_UAT.LCCONT.insuredname
  is '����������';
comment on column YBT_UAT.LCCONT.insuredsex
  is '�������Ա�';
comment on column YBT_UAT.LCCONT.insuredbirthday
  is '����������';
comment on column YBT_UAT.LCCONT.insuredidtype
  is '������֤������';
comment on column YBT_UAT.LCCONT.insuredidno
  is '������֤������';
comment on column YBT_UAT.LCCONT.getpolmode
  is 'Ͷ�������ͷ�ʽ';
comment on column YBT_UAT.LCCONT.appflag
  is '�б�״̬ 00 Ĭ�ϱ���';
comment on column YBT_UAT.LCCONT.polapplydate
  is 'Ͷ������';
comment on column YBT_UAT.LCCONT.state
  is '����״̬ Ĭ�� 0';
comment on column YBT_UAT.LCCONT.selltype
  is '���۷�ʽĬ��08';
comment on column YBT_UAT.LCCONT.forceuwflag
  is 'Ĭ�� 0';
comment on column YBT_UAT.LCCONT.operator
  is '����Ա';
comment on column YBT_UAT.LCCONT.makedate
  is '��������';
comment on column YBT_UAT.LCCONT.maketime
  is '����ʱ��';
comment on column YBT_UAT.LCCONT.modifydate
  is '�޸�����';
comment on column YBT_UAT.LCCONT.modifytime
  is '�޸�ʱ��';
comment on column YBT_UAT.LCCONT.agentname
  is '���ƾ�������';
comment on column YBT_UAT.LCCONT.grpcontno
  is 'cif��';
comment on column YBT_UAT.LCCONT.receivetime
  is '���ƾ��������ѱ���';
comment on column YBT_UAT.LCCONT.riskcode
  is '���ղ�Ʒ����';
comment on column YBT_UAT.LCCONT.accountbalance
  is '���';
comment on column YBT_UAT.LCCONT.debitflag
  is '�ӳٿۿ�';
comment on column YBT_UAT.LCCONT.delayeddebit
  is '�ӳٿۿ�����';
comment on column YBT_UAT.LCCONT.hesitationflag
  is '��ԥ���˱�';
alter table YBT_UAT.LCCONT
  add constraint PK_LCCONT primary key (TRANSNO, CONTNO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCINSURED
prompt ========================
prompt
create table YBT_UAT.LCINSURED
(
  transno                  VARCHAR2(35) not null,
  contno                   VARCHAR2(20) not null,
  insuredno                VARCHAR2(24) not null,
  prtno                    VARCHAR2(20),
  appntno                  VARCHAR2(20),
  managecom                VARCHAR2(10),
  executecom               VARCHAR2(10),
  relationtoappnt          VARCHAR2(2),
  lcinsuredname            VARCHAR2(120),
  lcinsuredsex             VARCHAR2(1),
  lcinsuredbirthday        DATE,
  lcinsuredidtype          VARCHAR2(2),
  lcinsuredidno            VARCHAR2(20),
  insureidenddate          DATE,
  insureidstartdate        DATE,
  lcinsurednativeplace     VARCHAR2(3),
  lcinsuredidsubmit        VARCHAR2(2),
  rgtaddress               VARCHAR2(80),
  health                   VARCHAR2(6),
  stature                  NUMBER(5,2),
  avoirdupois              NUMBER(5,2),
  lcinsuredrgtaddress      NUMBER(12,2),
  lcinsuredcompany         VARCHAR2(40),
  lcinsuredresponsibility  VARCHAR2(80),
  lcinsuredroccupationcode VARCHAR2(10),
  operator                 VARCHAR2(10),
  makedate                 DATE,
  maketime                 VARCHAR2(10),
  modifydate               DATE,
  modifytime               VARCHAR2(10),
  grpcontno                VARCHAR2(20) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LCINSURED.transno
  is '������ˮ��';
comment on column YBT_UAT.LCINSURED.contno
  is 'Ͷ������';
comment on column YBT_UAT.LCINSURED.insuredno
  is '�����˺�';
comment on column YBT_UAT.LCINSURED.prtno
  is 'Ͷ������';
comment on column YBT_UAT.LCINSURED.appntno
  is 'Ͷ���˺�';
comment on column YBT_UAT.LCINSURED.managecom
  is '��������';
comment on column YBT_UAT.LCINSURED.executecom
  is '��������';
comment on column YBT_UAT.LCINSURED.relationtoappnt
  is '��Ͷ���˵Ĺ�ϵ';
comment on column YBT_UAT.LCINSURED.lcinsuredname
  is '����������';
comment on column YBT_UAT.LCINSURED.lcinsuredsex
  is '�������Ա�';
comment on column YBT_UAT.LCINSURED.lcinsuredbirthday
  is '����������';
comment on column YBT_UAT.LCINSURED.lcinsuredidtype
  is '������֤������';
comment on column YBT_UAT.LCINSURED.lcinsuredidno
  is '������֤������';
comment on column YBT_UAT.LCINSURED.insureidenddate
  is '֤����Чֹ��';
comment on column YBT_UAT.LCINSURED.insureidstartdate
  is '֤����Ч����';
comment on column YBT_UAT.LCINSURED.lcinsurednativeplace
  is '�����˹���';
comment on column YBT_UAT.LCINSURED.health
  is '�����˽�����ʶ';
comment on column YBT_UAT.LCINSURED.stature
  is '����';
comment on column YBT_UAT.LCINSURED.avoirdupois
  is '����';
comment on column YBT_UAT.LCINSURED.lcinsuredcompany
  is '�����˹�����λ������';
comment on column YBT_UAT.LCINSURED.lcinsuredresponsibility
  is '������ְҵ����������';
comment on column YBT_UAT.LCINSURED.lcinsuredroccupationcode
  is '������ְҵ����';
comment on column YBT_UAT.LCINSURED.operator
  is '����Ա';
comment on column YBT_UAT.LCINSURED.makedate
  is '��������';
comment on column YBT_UAT.LCINSURED.maketime
  is '����ʱ��';
comment on column YBT_UAT.LCINSURED.modifydate
  is '�޸�����';
comment on column YBT_UAT.LCINSURED.modifytime
  is '�޸�ʱ��';
comment on column YBT_UAT.LCINSURED.grpcontno
  is 'cif';
alter table YBT_UAT.LCINSURED
  add constraint PK_LCINSURED primary key (CONTNO, TRANSNO)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 320K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LCPOL
prompt ====================
prompt
create table YBT_UAT.LCPOL
(
  transno            VARCHAR2(35) not null,
  grpcontno          VARCHAR2(20),
  grppolno           VARCHAR2(20),
  contno             VARCHAR2(20),
  polno              VARCHAR2(20) not null,
  proposalno         VARCHAR2(20) not null,
  prtno              VARCHAR2(20),
  conttype           VARCHAR2(20),
  poltypeflag        VARCHAR2(20),
  mainpolno          VARCHAR2(20),
  masterpolno        VARCHAR2(20),
  kindcode           VARCHAR2(20),
  riskcode           VARCHAR2(20) not null,
  riskversion        VARCHAR2(20),
  managecom          VARCHAR2(20),
  agentcom           VARCHAR2(20),
  agenttype          VARCHAR2(20),
  agentcode          VARCHAR2(100),
  agentgroup         VARCHAR2(120),
  agentcode1         VARCHAR2(20),
  insurancecom       VARCHAR2(20),
  insurancemanagecom VARCHAR2(30),
  salechnl           VARCHAR2(20),
  handler            VARCHAR2(20),
  insuredno          VARCHAR2(24),
  insuredname        VARCHAR2(120),
  insuredsex         VARCHAR2(20),
  insuredbirthday    DATE,
  insuredappage      INTEGER,
  insuredpeoples     INTEGER,
  occupationtype     VARCHAR2(50),
  appntno            VARCHAR2(24),
  appntname          VARCHAR2(120),
  cvalidate          DATE,
  signcom            VARCHAR2(20),
  signdate           DATE,
  signtime           VARCHAR2(20),
  firstpaydate       DATE,
  payenddate         DATE,
  paytodate          DATE,
  getstartdate       DATE,
  enddate            DATE,
  accienddate        DATE,
  getyearflag        VARCHAR2(2),
  getyear            INTEGER,
  payendyearflag     VARCHAR2(2),
  payendyear         VARCHAR2(5),
  insuyearflag       VARCHAR2(2),
  insuyear           VARCHAR2(5),
  acciyearflag       VARCHAR2(2),
  acciyear           INTEGER,
  getstarttype       VARCHAR2(2),
  specifyvalidate    VARCHAR2(2),
  paymode            VARCHAR2(2),
  paylocation        VARCHAR2(2),
  payintv            VARCHAR2(5),
  payyears           INTEGER,
  years              INTEGER,
  managefeerate      FLOAT,
  floatrate          NUMBER(16,10),
  premtoamnt         VARCHAR2(1),
  mult               NUMBER(20,5) not null,
  standprem          NUMBER(12,2) not null,
  prem               NUMBER(12,2) not null,
  sumprem            NUMBER(12,2) not null,
  amnt               NUMBER(12,2) not null,
  riskamnt           NUMBER(12,2) not null,
  leavingmoney       NUMBER(12,2),
  endorsetimes       INTEGER,
  claimtimes         INTEGER,
  livetimes          INTEGER,
  renewcount         INTEGER,
  lastgetdate        DATE,
  lastloandate       DATE,
  lastregetdate      DATE,
  lastedordate       DATE,
  lastrevdate        DATE,
  rnewflag           VARCHAR2(50),
  stopflag           VARCHAR2(1),
  expiryflag         VARCHAR2(1),
  autopayflag        VARCHAR2(1),
  interestdifflag    VARCHAR2(1),
  subflag            VARCHAR2(1),
  bnfflag            VARCHAR2(1),
  healthcheckflag    VARCHAR2(1),
  impartflag         VARCHAR2(1),
  reinsureflag       VARCHAR2(1),
  agentpayflag       VARCHAR2(1),
  agentgetflag       VARCHAR2(1),
  livegetmode        VARCHAR2(1),
  deadgetmode        VARCHAR2(1),
  bonusgetmode       VARCHAR2(1),
  bonusman           VARCHAR2(1),
  deadflag           VARCHAR2(1),
  smokeflag          VARCHAR2(1),
  remark             VARCHAR2(300),
  approveflag        VARCHAR2(1),
  approvecode        VARCHAR2(40),
  approvedate        DATE,
  approvetime        VARCHAR2(8),
  uwflag             VARCHAR2(1),
  uwcode             VARCHAR2(10),
  uwdate             DATE,
  uwtime             VARCHAR2(8),
  polapplydate       DATE,
  appflag            VARCHAR2(2),
  polstate           VARCHAR2(10),
  standbyflag1       VARCHAR2(10),
  standbyflag2       VARCHAR2(10),
  standbyflag3       VARCHAR2(10),
  waitperiod         INTEGER,
  getform            VARCHAR2(1),
  getbankcode        VARCHAR2(10),
  getbankaccno       VARCHAR2(40),
  getaccname         VARCHAR2(60),
  keepvalueopt       VARCHAR2(1),
  payrulecode        VARCHAR2(2),
  ascriptionrulecode VARCHAR2(2),
  autopubaccflag     VARCHAR2(1),
  ascriptionflag     VARCHAR2(1),
  investrulecode     VARCHAR2(20),
  uintlinkvaliflag   VARCHAR2(2),
  operator           VARCHAR2(50) not null,
  makedate           DATE not null,
  maketime           VARCHAR2(8) not null,
  modifydate         DATE not null,
  modifytime         VARCHAR2(8) not null,
  bonuspaymode       VARCHAR2(20),
  getintv            VARCHAR2(20),
  getstartage        VARCHAR2(20),
  getendage          VARCHAR2(20),
  fullbonusgetmode   VARCHAR2(20),
  autorenewflag      VARCHAR2(20),
  setflag            VARCHAR2(20),
  setcycleflag       VARCHAR2(20),
  setcycle           VARCHAR2(20),
  setno              VARCHAR2(20),
  setmoney           VARCHAR2(20),
  bak1               VARCHAR2(120),
  bak2               VARCHAR2(20),
  bak3               VARCHAR2(20),
  bak4               VARCHAR2(20),
  bak5               VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 8K
    minextents 1
    maxextents unlimited
  );
comment on table YBT_UAT.LCPOL
  is '�������ֱ�';
comment on column YBT_UAT.LCPOL.prtno
  is '���࣬��׼�ڸ��˱�����
��3,4λ���������£�
11������ӡˢ����
12������ӡˢ����
15��������ӡˢ����';
comment on column YBT_UAT.LCPOL.conttype
  is '��������';
comment on column YBT_UAT.LCPOL.masterpolno
  is '����������������ʱ�򣬴油���������ĺ��롣';
comment on column YBT_UAT.LCPOL.agentcom
  is 'ͨ�����ֶζ�Ӧ����ר�����Ա�(������������Ϣ����';
comment on column YBT_UAT.LCPOL.agenttype
  is '�Բ�ͬ�Ĵ��������Ž����ڲ��ķ��ࡣ
��Ա
';
comment on column YBT_UAT.LCPOL.salechnl
  is '1-����Ӫ��,2-����ֱ��,3-���д���';
comment on column YBT_UAT.LCPOL.insuredname
  is '���࣬��׼�ڸ��˿ͻ���';
comment on column YBT_UAT.LCPOL.insuredsex
  is '���࣬��׼�ڸ��˿ͻ���';
comment on column YBT_UAT.LCPOL.insuredbirthday
  is '���࣬��׼�ڸ��˿ͻ���';
comment on column YBT_UAT.LCPOL.occupationtype
  is '���࣬��׼�ڸ��˿ͻ���';
comment on column YBT_UAT.LCPOL.appntname
  is '���࣬��׼�ڸ��˿ͻ���';
comment on column YBT_UAT.LCPOL.firstpaydate
  is 'Ϊ���α���������׽�����';
comment on column YBT_UAT.LCPOL.payenddate
  is 'Ϊ���α����������ս�����';
comment on column YBT_UAT.LCPOL.getstartdate
  is 'Ϊ���α����������������';
comment on column YBT_UAT.LCPOL.enddate
  is 'Ϊ���α�����������ֹ����';
comment on column YBT_UAT.LCPOL.accienddate
  is 'Ϊ���α�������������������ֹ����';
comment on column YBT_UAT.LCPOL.payendyearflag
  is 'A�����䣬M���£�D���գ�Y����';
comment on column YBT_UAT.LCPOL.insuyearflag
  is '�����ڼ����';
comment on column YBT_UAT.LCPOL.getstarttype
  is '���ն�Ӧ�ջ��߱�����Ч��Ӧ��
0 --���ն�Ӧ
1 --�𱣶�Ӧ
';
comment on column YBT_UAT.LCPOL.paymode
  is '0--��ϵͳ���ݲ�¼
1--�ֽ�
2--�ֽ��Ϳ
3--֧Ʊ
4--����ת�ʣ����Ʒ��̣�
5--�ڲ�ת��
6--POS�տ�
7--���д��ۣ��Ʒ��̣�
8--����ҵ��
9--�����տ�"
';
comment on column YBT_UAT.LCPOL.payintv
  is '���Ѽ��
-1 -- �����ڽ�,
0  -- ����,
1  -- �½�
3  -- ����
6  -- ���꽻
12 -- �꽻
';
comment on column YBT_UAT.LCPOL.payyears
  is '�����ս����ڱ�־Ϊ���ꡱ��  ��ʾ��Ҫ���ѵ�������
�����ս����ڱ�־Ϊ���¡���  ��ʾ��Ҫ���ѵ�����
�����ս����ڱ�־Ϊ���ա���  ��ʾ��Ҫ���ѵ�����
�����ս����ڱ�־Ϊ�����䡱�����ֶδ�Ž�������������ɵ���Ҫ���ѵ�������
';
comment on column YBT_UAT.LCPOL.years
  is '������������';
comment on column YBT_UAT.LCPOL.claimtimes
  is '���ֶμ�¼�����Ĵ�����ֻҪ�����˾���Ϊ���������ˣ��ڸ��ֶ��ϼ�1��
';
comment on column YBT_UAT.LCPOL.renewcount
  is 'n --����n��,n>0';
comment on column YBT_UAT.LCPOL.stopflag
  is '0 --����
1 --ͣ��
';
comment on column YBT_UAT.LCPOL.expiryflag
  is '0 --����
1 --����,
2 --��������
';
comment on column YBT_UAT.LCPOL.bnfflag
  is '0 -- ����������
1 -- ����������';
comment on column YBT_UAT.LCPOL.impartflag
  is '0 --û�н�����֪
1 --�н�����֪
';
comment on column YBT_UAT.LCPOL.reinsureflag
  is '0 --����Ҫ��ҵ�ֱ�
1 --��Ҫ��ҵ�ֱ�';
comment on column YBT_UAT.LCPOL.agentgetflag
  is '0 ---��ʾ��ͨ�����д���
1 ---��ʾͨ�����д���
';
comment on column YBT_UAT.LCPOL.livegetmode
  is '1--�ۻ���Ϣ
2--��ȡ�ֽ�
3--�ֽɱ���
4--����
5--�����
';
comment on column YBT_UAT.LCPOL.deadgetmode
  is '1--�ۻ���Ϣ
2--��ȡ�ֽ�
3--�ֽɱ���
4--����
5--�����
';
comment on column YBT_UAT.LCPOL.bonusgetmode
  is '1--�ۻ���Ϣ
2--��ȡ�ֽ�
3--�ֽɱ���
4--����
5--�����
';
comment on column YBT_UAT.LCPOL.bonusman
  is '0 ���� ͬͶ����
1 ���� ͬ������';
comment on column YBT_UAT.LCPOL.deadflag
  is '1 ������������־
2 Ͷ����������־
';
comment on column YBT_UAT.LCPOL.approveflag
  is '0 ���� δ����
1 ���� ����û��ͨ��
9 ���� ����ͨ��
';
comment on column YBT_UAT.LCPOL.appflag
  is '0 - Ͷ��
1 - �б�
2 - ���屣�����˺�δ��Ч״̬ �� ����������δ��Ч״̬
4 - ��ֹ
9 - �������Զ������ڼ�';
comment on column YBT_UAT.LCPOL.standbyflag1
  is '���ݲ�ͬ���ֵ�����Ҫ�󣬴�Ų�ͬ������
�������ֱ��룺311603����ŵ���ͬ�Ŀ��Ŀ�������';
comment on column YBT_UAT.LCPOL.standbyflag2
  is '���ݲ�ͬ���ֵ�����Ҫ�󣬴�Ų�ͬ������
�����յ��ڲ��Żݱ�־�������ֶζ�������������Ч��
1 Ĭ�� ����
0 ����
';
comment on column YBT_UAT.LCPOL.standbyflag3
  is '���ݲ�ͬ���ֵ�����Ҫ�󣬴�Ų�ͬ������';
comment on column YBT_UAT.LCPOL.getform
  is '0������ת��
1��������ȡ���Ϲ���ȡ��
2������֧��';
comment on column YBT_UAT.LCPOL.uintlinkvaliflag
  is '��¼�ͻ�ѡ���Ͷ���˻���Ч����Ϣ����¼��ʱ������Ϣ��¼����ǩ��ʱ����ҵ���߼�����
1��������Ч����Ч��Լ��ʱ�䣩
2��ǩ������Ч��ϵͳʱ�䣩
3����������
4������ԥ�ں���Ч';
comment on column YBT_UAT.LCPOL.bak1
  is '��������';
alter table YBT_UAT.LCPOL
  add constraint PK_LCPOL primary key (POLNO, TRANSNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCITY
prompt =====================
prompt
create table YBT_UAT.LDCITY
(
  cityid VARCHAR2(20) not null,
  city   VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDCITY
  add constraint PK_CITY primary key (CITYID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCODE
prompt =====================
prompt
create table YBT_UAT.LDCODE
(
  codetype  VARCHAR2(20) not null,
  code      VARCHAR2(20) not null,
  codename  VARCHAR2(120),
  codealias VARCHAR2(120),
  comcode   VARCHAR2(10),
  othersign VARCHAR2(10)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDCODE
  add constraint PK_LDCODE primary key (CODETYPE, CODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCOM
prompt ====================
prompt
create table YBT_UAT.LDCOM
(
  comcode            VARCHAR2(10) not null,
  outcomcode         VARCHAR2(10),
  shortname          VARCHAR2(100),
  address            VARCHAR2(120),
  zipcode            VARCHAR2(6),
  phone              VARCHAR2(18),
  fax                VARCHAR2(18),
  email              VARCHAR2(60),
  webaddress         VARCHAR2(100),
  satrapname         VARCHAR2(20),
  regionalismcode    VARCHAR2(20),
  comcitysize        VARCHAR2(1),
  servicename        VARCHAR2(120),
  serviceno          VARCHAR2(60),
  servicephone       VARCHAR2(18),
  servicepostaddress VARCHAR2(120),
  comgrade           VARCHAR2(2),
  comareatype        VARCHAR2(2),
  upcomcode          VARCHAR2(10),
  yearmonth          VARCHAR2(6),
  enddate            DATE,
  validflag          VARCHAR2(1),
  operator           VARCHAR2(50),
  makedate           DATE,
  maketime           VARCHAR2(8),
  modifydate         DATE,
  modifytime         VARCHAR2(8),
  remark             VARCHAR2(500),
  fileremark         VARCHAR2(500),
  comname            VARCHAR2(30) not null,
  name               VARCHAR2(30),
  bankplace          VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LDCOM.validflag
  is 'Y:��Ч
N:��Ч
';
comment on column YBT_UAT.LDCOM.comname
  is '���л�������';
alter table YBT_UAT.LDCOM
  add constraint PK_LDCOM primary key (COMCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCOMA
prompt =====================
prompt
create table YBT_UAT.LDCOMA
(
  comcode            VARCHAR2(10) not null,
  outcomcode         VARCHAR2(10),
  shortname          VARCHAR2(100),
  address            VARCHAR2(120),
  zipcode            VARCHAR2(6),
  phone              VARCHAR2(18),
  fax                VARCHAR2(18),
  email              VARCHAR2(60),
  webaddress         VARCHAR2(100),
  satrapname         VARCHAR2(20),
  regionalismcode    VARCHAR2(20),
  comcitysize        VARCHAR2(1),
  servicename        VARCHAR2(120),
  serviceno          VARCHAR2(60),
  servicephone       VARCHAR2(18),
  servicepostaddress VARCHAR2(120),
  comgrade           VARCHAR2(2),
  comareatype        VARCHAR2(2),
  upcomcode          VARCHAR2(10),
  yearmonth          VARCHAR2(6),
  enddate            DATE,
  validflag          VARCHAR2(1),
  operator           VARCHAR2(50),
  makedate           DATE,
  maketime           VARCHAR2(8),
  modifydate         DATE,
  modifytime         VARCHAR2(8),
  remark             VARCHAR2(500),
  fileremark         VARCHAR2(500),
  comname            VARCHAR2(30) not null,
  name               VARCHAR2(30),
  bankplace          VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LDCOMA.validflag
  is 'Y:��Ч
N:��Ч
';
comment on column YBT_UAT.LDCOMA.comname
  is '���л�������';
alter table YBT_UAT.LDCOMA
  add constraint PK_LDCOMA primary key (COMCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCOMB
prompt =====================
prompt
create table YBT_UAT.LDCOMB
(
  comcode            VARCHAR2(10) not null,
  outcomcode         VARCHAR2(10),
  address            VARCHAR2(120),
  zipcode            VARCHAR2(6),
  phone              VARCHAR2(18),
  fax                VARCHAR2(18),
  email              VARCHAR2(60),
  webaddress         VARCHAR2(100),
  satrapname         VARCHAR2(20),
  regionalismcode    VARCHAR2(20),
  comcitysize        VARCHAR2(1),
  serviceno          VARCHAR2(60),
  servicename        VARCHAR2(120),
  servicephone       VARCHAR2(18),
  servicepostaddress VARCHAR2(120),
  comgrade           VARCHAR2(2),
  comareatype        VARCHAR2(2),
  upcomcode          VARCHAR2(10),
  yearmonth          VARCHAR2(6),
  enddate            DATE,
  validflag          VARCHAR2(1),
  operator           VARCHAR2(50),
  makedate           DATE,
  maketime           VARCHAR2(8),
  modifydate         DATE,
  modifytime         VARCHAR2(8),
  remark             VARCHAR2(500),
  fileremark         VARCHAR2(500),
  comname            VARCHAR2(30) not null,
  name               VARCHAR2(30),
  bankplace          VARCHAR2(2)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCOMDEALINFO
prompt ============================
prompt
create table YBT_UAT.LDCOMDEALINFO
(
  comdealinfono VARCHAR2(50) not null,
  agentcom      VARCHAR2(20) not null,
  comtype       VARCHAR2(2) not null,
  comdealno     VARCHAR2(50),
  approvalno    VARCHAR2(20),
  makedate      DATE,
  startdate     DATE,
  enddate       DATE,
  repalcedate   DATE,
  status        VARCHAR2(1) not null,
  approval      VARCHAR2(50),
  char1         VARCHAR2(10),
  char2         VARCHAR2(10),
  id            NUMBER
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCOMDEALINFOA
prompt =============================
prompt
create table YBT_UAT.LDCOMDEALINFOA
(
  comdealinfono VARCHAR2(50) not null,
  agentcom      VARCHAR2(20) not null,
  comtype       VARCHAR2(2) not null,
  comdealno     VARCHAR2(50),
  approvalno    VARCHAR2(20),
  makedate      DATE,
  startdate     DATE,
  enddate       DATE,
  repalcedate   DATE,
  status        VARCHAR2(1) not null,
  approval      VARCHAR2(50),
  char1         VARCHAR2(10),
  char2         VARCHAR2(10),
  id            NUMBER
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCOMDEALINFOB
prompt =============================
prompt
create table YBT_UAT.LDCOMDEALINFOB
(
  comdealinfono VARCHAR2(50) not null,
  agentcom      VARCHAR2(20) not null,
  comtype       VARCHAR2(2) not null,
  comdealno     VARCHAR2(50),
  approvalno    VARCHAR2(20),
  makedate      DATE,
  startdate     DATE,
  enddate       DATE,
  repalcedate   DATE,
  status        VARCHAR2(1) not null,
  approval      VARCHAR2(50),
  char1         VARCHAR2(10),
  char2         VARCHAR2(10),
  id            NUMBER
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCUSTOMER
prompt =========================
prompt
create table YBT_UAT.LDCUSTOMER
(
  ldcustomerno   VARCHAR2(100) not null,
  cifid          VARCHAR2(30) not null,
  fullname       VARCHAR2(22),
  formername     VARCHAR2(22),
  idtype         VARCHAR2(30),
  idnumber       VARCHAR2(150),
  idexpiry       VARCHAR2(30),
  age            VARCHAR2(30),
  gender         VARCHAR2(10),
  censusregister VARCHAR2(10),
  maritalstatus  VARCHAR2(22),
  contactphoneno VARCHAR2(100),
  mobilephoneno  VARCHAR2(100),
  callback       VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDCUSTOMER
  add primary key (LDCUSTOMERNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDCUSTOMER
  add constraint AAA unique (CIFID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCUSTOMERACCOUNT
prompt ================================
prompt
create table YBT_UAT.LDCUSTOMERACCOUNT
(
  countno        VARCHAR2(100) not null,
  ldcustomerno   VARCHAR2(100),
  cifid          VARCHAR2(100),
  accountnumber  VARCHAR2(100),
  accountccy     VARCHAR2(100),
  accountbalance VARCHAR2(100),
  accountstatus  VARCHAR2(100),
  bak1           VARCHAR2(50),
  bak2           VARCHAR2(50),
  bak3           VARCHAR2(50),
  bak4           VARCHAR2(50),
  bak5           VARCHAR2(50),
  bak6           VARCHAR2(50),
  bak7           VARCHAR2(50),
  bak8           VARCHAR2(50),
  bak9           VARCHAR2(50),
  bak10          VARCHAR2(50)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDCUSTOMERACCOUNT
  add primary key (COUNTNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDCUSTOMERADDRESS
prompt ================================
prompt
create table YBT_UAT.LDCUSTOMERADDRESS
(
  ldcustomerno               VARCHAR2(100) not null,
  cifid                      VARCHAR2(100) not null,
  residentialaddresstype     VARCHAR2(100),
  residentialprovince        VARCHAR2(100),
  residentialcity            VARCHAR2(100),
  residentialdistrict        VARCHAR2(100),
  residentialdetailedaddress VARCHAR2(100),
  residentialpostcode        VARCHAR2(100),
  contactaddresstype         VARCHAR2(100),
  contactprovince            VARCHAR2(100),
  contactcity                VARCHAR2(100),
  contactdistrict            VARCHAR2(100),
  contactdetailedaddress     VARCHAR2(100),
  contactpostcode            VARCHAR2(100),
  homeaddresstype            VARCHAR2(100),
  homeprovince               VARCHAR2(100),
  homecity                   VARCHAR2(100),
  homedistrict               VARCHAR2(100),
  homedetailedaddress        VARCHAR2(100),
  homepostcode               VARCHAR2(100),
  permanentaddresstype       VARCHAR2(100),
  permanentprovince          VARCHAR2(100),
  permanentcity              VARCHAR2(100),
  permanentdistrict          VARCHAR2(100),
  permanentdetailedaddress   VARCHAR2(100),
  permanentpostcode          VARCHAR2(100),
  previouaddresstype         VARCHAR2(100),
  previouprovince            VARCHAR2(100),
  previoucity                VARCHAR2(100),
  previoudistrict            VARCHAR2(100),
  previoudetailedaddress     VARCHAR2(100),
  previoupostcode            VARCHAR2(100),
  previoucompany             VARCHAR2(100),
  previoucompanyaddress      VARCHAR2(100),
  previouposition            VARCHAR2(100),
  previouindustrytype        VARCHAR2(100),
  previouoccupation          VARCHAR2(100),
  previouemailaddress        VARCHAR2(100),
  previouincome              VARCHAR2(100),
  previoumaritalstatus       VARCHAR2(100),
  previouheight              VARCHAR2(100),
  previouweight              VARCHAR2(100),
  previouincomesource        VARCHAR2(100),
  previouwealthsource        VARCHAR2(100),
  previoutelephonesource     VARCHAR2(100),
  previouhealthcare          VARCHAR2(100),
  previoufamilyincome        VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDCUSTOMERADDRESS
  add constraint CCC primary key (CIFID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDMAXNO
prompt ======================
prompt
create table YBT_UAT.LDMAXNO
(
  notype  VARCHAR2(20) not null,
  nolimit VARCHAR2(12) not null,
  maxno   INTEGER not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on table YBT_UAT.LDMAXNO
  is '����������ˮ�ţ����еĺ����1��ʼ
NoType:
DOC_ID 	: EasyScan��ES_DOC_MAIN����doc_id�����к�
PAGE_ID	: EasyScan��ES_DOC_PAGES����page_id�����к�';
alter table YBT_UAT.LDMAXNO
  add constraint PK_LDMAXNO primary key (NOTYPE, NOLIMIT)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDMENUGRPA
prompt =========================
prompt
create table YBT_UAT.LDMENUGRPA
(
  menugrpcode        VARCHAR2(10) not null,
  menugrpname        VARCHAR2(100) not null,
  menugrpdescription VARCHAR2(100),
  menusign           VARCHAR2(5),
  operator           VARCHAR2(50),
  makedate           DATE,
  maketime           VARCHAR2(8),
  menustate          VARCHAR2(5),
  bak1               VARCHAR2(20),
  bak2               VARCHAR2(20),
  bak3               VARCHAR2(20),
  bak4               VARCHAR2(20),
  bak5               VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDMENUGRPA
  add constraint PK_LDMENUGRPA primary key (MENUGRPCODE, MENUGRPNAME)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDMENUGRPTOMENUA
prompt ===============================
prompt
create table YBT_UAT.LDMENUGRPTOMENUA
(
  menugrpcode VARCHAR2(10) not null,
  nodecode    VARCHAR2(10) not null,
  meddlemenu  VARCHAR2(10) not null,
  menudesc    VARCHAR2(10) not null,
  makedate    DATE,
  maketime    VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDMENUGRPTOMENUA
  add constraint PK_LDMENUGRPTOMENUA primary key (MENUGRPCODE, NODECODE, MEDDLEMENU, MENUDESC)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDOCCUPATION
prompt ===========================
prompt
create table YBT_UAT.LDOCCUPATION
(
  occupationcode VARCHAR2(10) not null,
  occupationname VARCHAR2(120),
  occupationtype VARCHAR2(10),
  worktype       VARCHAR2(10),
  workname       VARCHAR2(60),
  medrate        INTEGER,
  suddrisk       VARCHAR2(30),
  disearisk      VARCHAR2(30),
  hosiprisk      VARCHAR2(30)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.LDOCCUPATION.occupationtype
  is '����������ְҵ��𣬶����ô���0�����֡�
���ڷ�������ְҵ��𣬶�����С��0�����֡�
-1 ���� �ܱ�
-2 ���� �������
';
comment on column YBT_UAT.LDOCCUPATION.workname
  is '���չ�˾����';
comment on column YBT_UAT.LDOCCUPATION.medrate
  is '���������ı����������ô���0�����֡�
��׼����ʹ��1
���ڷ������ı�����������С��0�����֡�
1 ���� ��׼����
-1���� �ܱ�
-2���� δ����
';
alter table YBT_UAT.LDOCCUPATION
  add constraint PK_LDOCCUPATION primary key (OCCUPATIONCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDQUALIINFOA
prompt ===========================
prompt
create table YBT_UAT.LDQUALIINFOA
(
  staffid     VARCHAR2(25) not null,
  qualifitype VARCHAR2(100) not null,
  lessous     VARCHAR2(100),
  states      VARCHAR2(30),
  hour        DATE,
  makedate    DATE not null,
  maketime    VARCHAR2(8) not null,
  modifydate  DATE not null,
  modifytime  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDTRAINING
prompt =========================
prompt
create table YBT_UAT.LDTRAINING
(
  coursecode  VARCHAR2(100),
  coursetitle VARCHAR2(160)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUPLOADDOC
prompt ==========================
prompt
create table YBT_UAT.LDUPLOADDOC
(
  docid        VARCHAR2(30) not null,
  path         VARCHAR2(200),
  docname      VARCHAR2(150) not null,
  modifiedname VARCHAR2(30),
  makedate     DATE not null,
  maketime     VARCHAR2(8) not null,
  codetype     VARCHAR2(50),
  comcode      VARCHAR2(100) not null,
  agentcode    VARCHAR2(50) not null,
  prtno        VARCHAR2(50) not null,
  remark       VARCHAR2(200),
  docsize      VARCHAR2(30),
  contenttype  VARCHAR2(100),
  operator     VARCHAR2(30),
  bak1         VARCHAR2(20),
  bak2         VARCHAR2(20),
  bak3         VARCHAR2(20),
  bak4         VARCHAR2(20),
  bak5         VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDUPLOADDOC
  add constraint PK_LDUPLOADDOC primary key (DOCID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSER
prompt =====================
prompt
create table YBT_UAT.LDUSER
(
  emplid             VARCHAR2(8) not null,
  companycode        VARCHAR2(50),
  companyname        VARCHAR2(150),
  locationcode       VARCHAR2(50),
  locationname       VARCHAR2(150),
  deptid             VARCHAR2(100),
  department         VARCHAR2(150),
  costcentre         VARCHAR2(100),
  emplrcd            VARCHAR2(50),
  name               VARCHAR2(100),
  preferredfirstname VARCHAR2(100),
  positioncode       VARCHAR2(50),
  positiontitle      VARCHAR2(100),
  jobcode            VARCHAR2(50),
  jobtitle           VARCHAR2(150),
  reportsto          VARCHAR2(8),
  managertitle       VARCHAR2(150),
  managerid          VARCHAR2(8),
  managername        VARCHAR2(100),
  hiredate           DATE,
  rehiredate         DATE,
  terminationdate    DATE,
  emplclass          VARCHAR2(8),
  actndate           DATE,
  actnrsneffdt       DATE,
  functionalmgr      VARCHAR2(8),
  posndescr          VARCHAR2(150),
  funcmgremplid      VARCHAR2(8),
  funcmgrname        VARCHAR2(100),
  hrl1descr          VARCHAR2(150),
  hrl2descr          VARCHAR2(150),
  hrl3descr          VARCHAR2(150),
  hrl4descr          VARCHAR2(150),
  hrl5descr          VARCHAR2(150),
  status             VARCHAR2(50),
  operator           VARCHAR2(30),
  makedate           DATE,
  maketime           VARCHAR2(8),
  modifydate         DATE,
  modifytime         VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSERA
prompt ======================
prompt
create table YBT_UAT.LDUSERA
(
  emplid      VARCHAR2(8) not null,
  department  VARCHAR2(150),
  name        VARCHAR2(100),
  jobcode     VARCHAR2(50),
  companycode VARCHAR2(50),
  companyname VARCHAR2(150),
  location    VARCHAR2(50),
  status      VARCHAR2(50),
  hiredate    DATE,
  rehiredate  DATE,
  checkflag   VARCHAR2(30),
  operator    VARCHAR2(30),
  makedate    DATE,
  maketime    VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDUSERA
  add constraint PK_LDUSERA primary key (EMPLID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSERB
prompt ======================
prompt
create table YBT_UAT.LDUSERB
(
  emplid      VARCHAR2(8),
  department  VARCHAR2(150),
  name        VARCHAR2(100),
  jobcode     VARCHAR2(50),
  companycode VARCHAR2(50),
  companyname VARCHAR2(150),
  location    VARCHAR2(50),
  status      VARCHAR2(50),
  hiredate    DATE,
  rehiredate  DATE,
  checkflag   VARCHAR2(30),
  operator    VARCHAR2(30),
  makedate    DATE,
  maketime    VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSERINSUCODEA
prompt ==============================
prompt
create table YBT_UAT.LDUSERINSUCODEA
(
  usercode   VARCHAR2(30) not null,
  agentcom   VARCHAR2(20) not null,
  agentcode  VARCHAR2(30) not null,
  makedate   DATE,
  maketime   VARCHAR2(10),
  modifydate DATE,
  modifytime VARCHAR2(10),
  bak1       VARCHAR2(20),
  bak2       VARCHAR2(20),
  bak3       VARCHAR2(20),
  bak4       VARCHAR2(20),
  bak5       VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDUSERINSUCODEA
  add constraint LDUSERINSUCODEA primary key (USERCODE, AGENTCOM, AGENTCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSEROTHERINFO
prompt ==============================
prompt
create table YBT_UAT.LDUSEROTHERINFO
(
  usercode  VARCHAR2(30) not null,
  phone     VARCHAR2(30),
  chinaname VARCHAR2(120),
  bak1      VARCHAR2(50),
  bak2      VARCHAR2(50),
  bak3      VARCHAR2(50)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;
alter table YBT_UAT.LDUSEROTHERINFO
  add constraint PK_LDUSEROTHERINFO primary key (USERCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255;

prompt
prompt Creating table LDUSEROTHERINFOA
prompt ===============================
prompt
create table YBT_UAT.LDUSEROTHERINFOA
(
  usercode  VARCHAR2(30) not null,
  phone     VARCHAR2(30),
  chinaname VARCHAR2(120),
  bak1      VARCHAR2(50),
  bak2      VARCHAR2(50),
  bak3      VARCHAR2(50)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDUSEROTHERINFOA
  add constraint PK_LDUSEROTHERINFOA primary key (USERCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSEROTHERINFOB
prompt ===============================
prompt
create table YBT_UAT.LDUSEROTHERINFOB
(
  usercode  VARCHAR2(30),
  phone     VARCHAR2(30),
  chinaname VARCHAR2(120),
  bak1      VARCHAR2(50),
  bak2      VARCHAR2(50),
  bak3      VARCHAR2(50)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table LDUSERTOMENUGRP
prompt ==============================
prompt
create table YBT_UAT.LDUSERTOMENUGRP
(
  usercode    VARCHAR2(30) not null,
  menugrpcode VARCHAR2(10) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDUSERTOMENUGRP
  add constraint PK_LDUSERTOMENUGRP primary key (USERCODE, MENUGRPCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LDUSERTOMENUGRPA
prompt ===============================
prompt
create table YBT_UAT.LDUSERTOMENUGRPA
(
  usercode     VARCHAR2(30) not null,
  menugrpcode  VARCHAR2(10) not null,
  ldu_usercode VARCHAR2(6)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LDUSERTOMENUGRPA
  add constraint LDUSERTOMENUGRPA primary key (USERCODE, MENUGRPCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISK
prompt =====================
prompt
create table YBT_UAT.LMRISK
(
  char1         VARCHAR2(20),
  char2         VARCHAR2(20),
  char3         VARCHAR2(20),
  char4         VARCHAR2(20),
  char5         VARCHAR2(20),
  char6         VARCHAR2(20),
  checkdefflag  VARCHAR2(1),
  checkflag     VARCHAR2(2),
  destrate      FLOAT,
  enddate       VARCHAR2(10),
  insuaccflag   VARCHAR2(1),
  insurancecom  VARCHAR2(20) not null,
  mngcom        VARCHAR2(100),
  operator      VARCHAR2(50),
  origriskcode  VARCHAR2(8),
  riskcode      VARCHAR2(10) not null,
  riskname      VARCHAR2(120) not null,
  riskperiod    VARCHAR2(1) not null,
  riskprop      VARCHAR2(100) not null,
  riskshortname VARCHAR2(120),
  risktype      VARCHAR2(2) not null,
  riskver       VARCHAR2(100),
  saleschl      VARCHAR2(1),
  sign          VARCHAR2(2),
  startdate     VARCHAR2(10),
  submitflag    VARCHAR2(1),
  subriskflag   VARCHAR2(1) not null,
  subriskver    VARCHAR2(10),
  risk          VARCHAR2(10)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LMRISK
  add constraint PK_LMEISK primary key (RISKCODE, INSURANCECOM)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISKA
prompt ======================
prompt
create table YBT_UAT.LMRISKA
(
  char1         VARCHAR2(20),
  char2         VARCHAR2(20),
  char3         VARCHAR2(20),
  char4         VARCHAR2(20),
  char5         VARCHAR2(20),
  char6         VARCHAR2(20),
  checkdefflag  VARCHAR2(1),
  checkflag     VARCHAR2(2),
  destrate      FLOAT,
  enddate       VARCHAR2(10),
  insuaccflag   VARCHAR2(1),
  insurancecom  VARCHAR2(20) not null,
  mngcom        VARCHAR2(100),
  operator      VARCHAR2(50),
  origriskcode  VARCHAR2(8),
  riskcode      VARCHAR2(10) not null,
  riskname      VARCHAR2(120) not null,
  riskperiod    VARCHAR2(1) not null,
  riskprop      VARCHAR2(100) not null,
  riskshortname VARCHAR2(120),
  risktype      VARCHAR2(2) not null,
  riskver       VARCHAR2(100),
  saleschl      VARCHAR2(1),
  sign          VARCHAR2(2),
  startdate     VARCHAR2(10),
  submitflag    VARCHAR2(1),
  subriskflag   VARCHAR2(1) not null,
  subriskver    VARCHAR2(10),
  risk          VARCHAR2(10)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LMRISKA
  add constraint PK_LMEISKA primary key (RISKCODE, INSURANCECOM)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISKB
prompt ======================
prompt
create table YBT_UAT.LMRISKB
(
  char1         VARCHAR2(20),
  char2         VARCHAR2(20),
  char3         VARCHAR2(20),
  char4         VARCHAR2(20),
  char5         VARCHAR2(20),
  char6         VARCHAR2(20),
  checkdefflag  VARCHAR2(1),
  checkflag     VARCHAR2(2),
  destrate      FLOAT,
  enddate       VARCHAR2(10),
  insuaccflag   VARCHAR2(1) not null,
  insurancecom  VARCHAR2(20) not null,
  mngcom        VARCHAR2(100),
  operator      VARCHAR2(50),
  origriskcode  VARCHAR2(8),
  riskcode      VARCHAR2(10) not null,
  riskname      VARCHAR2(120) not null,
  riskperiod    VARCHAR2(1) not null,
  riskprop      VARCHAR2(100) not null,
  riskshortname VARCHAR2(120),
  risktype      VARCHAR2(2) not null,
  riskver       VARCHAR2(100),
  saleschl      VARCHAR2(1),
  sign          VARCHAR2(2),
  startdate     VARCHAR2(10),
  submitflag    VARCHAR2(1),
  subriskflag   VARCHAR2(1) not null,
  subriskver    VARCHAR2(10),
  risk          VARCHAR2(10)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISKPARAMSDEF
prompt ==============================
prompt
create table YBT_UAT.LMRISKPARAMSDEF
(
  riskcode   VARCHAR2(10) not null,
  riskver    VARCHAR2(8),
  dutycode   VARCHAR2(20) not null,
  othercode  VARCHAR2(6) not null,
  ctrltype   VARCHAR2(1),
  paramstype VARCHAR2(30) not null,
  paramscode VARCHAR2(30),
  paramsname VARCHAR2(100),
  char1      VARCHAR2(8),
  char2      VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LMRISKPARAMSDEF
  add constraint PK_LMEISKPARAMSDEF primary key (RISKCODE, DUTYCODE, OTHERCODE, PARAMSTYPE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISKPARAMSDEFA
prompt ===============================
prompt
create table YBT_UAT.LMRISKPARAMSDEFA
(
  riskcode   VARCHAR2(10) not null,
  riskver    VARCHAR2(8),
  dutycode   VARCHAR2(20) not null,
  othercode  VARCHAR2(6) not null,
  ctrltype   VARCHAR2(1),
  paramstype VARCHAR2(30) not null,
  paramscode VARCHAR2(30),
  paramsname VARCHAR2(100),
  char1      VARCHAR2(8),
  char2      VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LMRISKPARAMSDEFA
  add constraint PK_LMEISKPARAMSDEFA primary key (RISKCODE, DUTYCODE, OTHERCODE, PARAMSTYPE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISKPARAMSDEFB
prompt ===============================
prompt
create table YBT_UAT.LMRISKPARAMSDEFB
(
  riskcode   VARCHAR2(10),
  riskver    VARCHAR2(8),
  dutycode   VARCHAR2(20),
  othercode  VARCHAR2(6),
  ctrltype   VARCHAR2(1),
  paramstype VARCHAR2(30),
  paramscode VARCHAR2(30),
  paramsname VARCHAR2(100),
  char1      VARCHAR2(8),
  char2      VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LMRISKRELA
prompt =========================
prompt
create table YBT_UAT.LMRISKRELA
(
  riskcode     VARCHAR2(10) not null,
  relariskcode VARCHAR2(10) not null,
  relacode     CHAR(2),
  managecomgrp CHAR(300),
  char1        VARCHAR2(8),
  char2        VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;
alter table YBT_UAT.LMRISKRELA
  add constraint PK_LMRISKRELA primary key (RISKCODE, RELARISKCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255;

prompt
prompt Creating table LMRISKRELAA
prompt ==========================
prompt
create table YBT_UAT.LMRISKRELAA
(
  riskcode     VARCHAR2(10) not null,
  relariskcode VARCHAR2(10) not null,
  relacode     CHAR(2),
  managecomgrp CHAR(300),
  char1        VARCHAR2(8),
  char2        VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;
alter table YBT_UAT.LMRISKRELAA
  add constraint PK_LMRISKRELAA primary key (RISKCODE, RELARISKCODE)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255;

prompt
prompt Creating table LMRISKRELAB
prompt ==========================
prompt
create table YBT_UAT.LMRISKRELAB
(
  riskcode     VARCHAR2(10),
  relariskcode VARCHAR2(10),
  relacode     CHAR(2),
  managecomgrp CHAR(300),
  char1        VARCHAR2(8),
  char2        VARCHAR2(8)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table LOCATIONCODE
prompt ===========================
prompt
create table YBT_UAT.LOCATIONCODE
(
  locationid   VARCHAR2(20) not null,
  locationcode VARCHAR2(100),
  regionid     VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LOCATIONCODE
  add constraint PK_LOCATIONCODE primary key (LOCATIONID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LZCARD
prompt =====================
prompt
create table YBT_UAT.LZCARD
(
  id                VARCHAR2(20) not null,
  agentcom          VARCHAR2(10),
  managecom         VARCHAR2(30),
  certifytype       VARCHAR2(2),
  certifycode       VARCHAR2(20),
  certifystatus     VARCHAR2(1),
  certifystart      VARCHAR2(30),
  certifyend        VARCHAR2(30),
  operator          VARCHAR2(30),
  waitstatus        VARCHAR2(1),
  modifystatus      VARCHAR2(1),
  certifyno         VARCHAR2(30),
  certifynum        VARCHAR2(50),
  makedate          DATE,
  maketime          VARCHAR2(10),
  modifydate        DATE,
  modifytime        VARCHAR2(10),
  bak1              VARCHAR2(20),
  bak2              VARCHAR2(20),
  bak3              VARCHAR2(20),
  bak4              VARCHAR2(20),
  bak5              VARCHAR2(20),
  certifystatusflag VARCHAR2(1),
  city              VARCHAR2(20),
  checkoperator     VARCHAR2(30)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LZCARD
  add constraint PK_LZCARD primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LZCARDA
prompt ======================
prompt
create table YBT_UAT.LZCARDA
(
  id                VARCHAR2(20) not null,
  agentcom          VARCHAR2(10),
  managecom         VARCHAR2(30),
  certifytype       VARCHAR2(2),
  certifycode       VARCHAR2(20),
  certifystatus     VARCHAR2(1),
  certifystart      VARCHAR2(30),
  certifyend        VARCHAR2(30),
  operator          VARCHAR2(30),
  waitstatus        VARCHAR2(1),
  modifystatus      VARCHAR2(1),
  certifyno         VARCHAR2(30),
  certifynum        VARCHAR2(50),
  makedate          DATE,
  maketime          VARCHAR2(10),
  modifydate        DATE,
  modifytime        VARCHAR2(10),
  bak1              VARCHAR2(20),
  bak2              VARCHAR2(20),
  bak3              VARCHAR2(20),
  bak4              VARCHAR2(20),
  bak5              VARCHAR2(20),
  certifystatusflag VARCHAR2(1),
  city              VARCHAR2(20),
  checkoperator     VARCHAR2(30)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.LZCARDA
  add constraint PK_LZCARDA primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table LZCARDB
prompt ======================
prompt
create table YBT_UAT.LZCARDB
(
  id                VARCHAR2(20),
  agentcom          VARCHAR2(10),
  managecom         VARCHAR2(30),
  certifytype       VARCHAR2(2),
  certifycode       VARCHAR2(20),
  certifystatus     VARCHAR2(1),
  certifystart      VARCHAR2(30),
  certifyend        VARCHAR2(30),
  operator          VARCHAR2(30),
  waitstatus        VARCHAR2(1),
  modifystatus      VARCHAR2(1),
  certifyno         VARCHAR2(30),
  certifynum        VARCHAR2(50),
  makedate          DATE,
  maketime          VARCHAR2(10),
  modifydate        DATE,
  modifytime        VARCHAR2(10),
  bak1              VARCHAR2(20),
  bak2              VARCHAR2(20),
  bak3              VARCHAR2(20),
  bak4              VARCHAR2(20),
  bak5              VARCHAR2(20),
  certifystatusflag VARCHAR2(1),
  city              VARCHAR2(20),
  checkoperator     VARCHAR2(30)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table MENU
prompt ===================
prompt
create table YBT_UAT.MENU
(
  id               VARCHAR2(64) not null,
  par_uid          VARCHAR2(64),
  menu_name        VARCHAR2(40),
  menu_desc        VARCHAR2(100),
  menu_status      CHAR(1),
  menu_link        VARCHAR2(200),
  menu_index       NUMBER,
  t_s_uid          VARCHAR2(64),
  meddle_menu      NUMBER,
  meddle_menu_name VARCHAR2(64),
  crt_time         DATE,
  upd_time         DATE,
  sub_menu_name    VARCHAR2(64),
  sub_menu         NUMBER
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.MENU
  add primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table OTHERTRAINING
prompt ============================
prompt
create table YBT_UAT.OTHERTRAINING
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  y16                         VARCHAR2(30),
  y17                         VARCHAR2(30),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table OTHERTRAININGA
prompt =============================
prompt
create table YBT_UAT.OTHERTRAININGA
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  y16                         VARCHAR2(30),
  y17                         VARCHAR2(30),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table OTHERTRAININGB
prompt =============================
prompt
create table YBT_UAT.OTHERTRAININGB
(
  staffid                     VARCHAR2(8) not null,
  licensescode                VARCHAR2(100),
  licensescertificationsdescr VARCHAR2(150),
  issuedate                   DATE,
  expirationdate              DATE,
  licensecertificationno      VARCHAR2(100),
  issuedby                    VARCHAR2(100),
  verified                    VARCHAR2(1),
  renewal                     VARCHAR2(1),
  country                     VARCHAR2(20),
  states                      VARCHAR2(20),
  y16                         VARCHAR2(30),
  y17                         VARCHAR2(30),
  checkflag                   VARCHAR2(30),
  makedate                    DATE not null,
  maketime                    VARCHAR2(8) not null,
  modifydate                  DATE not null,
  modifytime                  VARCHAR2(8) not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table PLACCOUNTINSUREDDETAIL
prompt =====================================
prompt
create table YBT_UAT.PLACCOUNTINSUREDDETAIL
(
  serno         VARCHAR2(30) not null,
  serialno      VARCHAR2(20) not null,
  transrno      VARCHAR2(20) not null,
  insurcecom    VARCHAR2(8),
  comcode       VARCHAR2(8),
  insuredaccno  VARCHAR2(30),
  paymoney      NUMBER(12,2),
  clientname    VARCHAR2(30),
  clientidtype  VARCHAR2(6),
  clientidno    VARCHAR2(30),
  payresult     VARCHAR2(4),
  prtno         VARCHAR2(30),
  contno        VARCHAR2(30),
  proposalno    VARCHAR2(30),
  flag          VARCHAR2(20),
  paymodetimes  VARCHAR2(20),
  selltype      VARCHAR2(20),
  authrizedyear VARCHAR2(20),
  paymode       VARCHAR2(20),
  state         VARCHAR2(20),
  remark        VARCHAR2(20),
  socketflag    VARCHAR2(20),
  dealsuccflag  VARCHAR2(20),
  rightflag     VARCHAR2(20),
  makedate      DATE,
  maketime      VARCHAR2(20),
  modifydate    DATE,
  modifytime    VARCHAR2(20),
  standbyflag   VARCHAR2(100),
  bak1          VARCHAR2(20),
  bak2          VARCHAR2(20),
  bak3          VARCHAR2(20),
  bak4          VARCHAR2(20),
  bak5          VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.payresult
  is '�ۿ�״̬';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.flag
  is '��������״̬';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.state
  is '���������İ�ť״̬ 01����ɹ���״̬';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.socketflag
  is '��NDS�ۿ�����';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.dealsuccflag
  is 'NDSת���Ƿ�ɹ�';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.rightflag
  is '�Ƿ�Ҫ����';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.standbyflag
  is '�ۿ�������   ��ʼ�����ļ�����';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.bak1
  is '��Ա����';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.bak2
  is '��ʾ�Ƿ��Ѿ��Թ���';
comment on column YBT_UAT.PLACCOUNTINSUREDDETAIL.bak4
  is '��ǰ��Ӧ������һ���ۿ���Ϣ  Ϊ������׼��';
alter table YBT_UAT.PLACCOUNTINSUREDDETAIL
  add constraint PK_PLACCOUNTINSUREDDETAIL primary key (SERNO, SERIALNO, TRANSRNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RECORDALL
prompt ========================
prompt
create table YBT_UAT.RECORDALL
(
  transno  VARCHAR2(120),
  fileid   VARCHAR2(100),
  filetype VARCHAR2(100),
  counts   VARCHAR2(22),
  loser    VARCHAR2(5),
  succeed  VARCHAR2(22),
  operator VARCHAR2(30),
  makedate DATE,
  maketime VARCHAR2(22)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255;

prompt
prompt Creating table REGION
prompt =====================
prompt
create table YBT_UAT.REGION
(
  regionid VARCHAR2(20) not null,
  region   VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.REGION
  add constraint PK_REGION primary key (REGIONID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REGIONALL
prompt ========================
prompt
create table YBT_UAT.REGIONALL
(
  department VARCHAR2(160),
  region     VARCHAR2(22),
  city       VARCHAR2(22),
  subbranch  VARCHAR2(22)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table REVENUE
prompt ======================
prompt
create table YBT_UAT.REVENUE
(
  transno       VARCHAR2(20) not null,
  statement     VARCHAR2(10),
  firstname     VARCHAR2(10),
  lastname      VARCHAR2(10),
  livingaddress VARCHAR2(100),
  cnnativeheath VARCHAR2(100),
  ennativeheath VARCHAR2(100),
  tiveheath     VARCHAR2(10),
  reason1       VARCHAR2(10),
  reason2       VARCHAR2(10),
  reason2desc   VARCHAR2(100),
  bak1          VARCHAR2(100),
  bak2          VARCHAR2(100),
  bak3          VARCHAR2(100),
  liveheath     CHAR(1)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.REVENUE
  add primary key (TRANSNO)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SUBBRANCH
prompt ========================
prompt
create table YBT_UAT.SUBBRANCH
(
  subbranchid VARCHAR2(20) not null,
  subbranch   VARCHAR2(100),
  cityid      VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table YBT_UAT.SUBBRANCH
  add constraint PK_SUBBRANCH primary key (SUBBRANCHID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TAXREVENUE
prompt =========================
prompt
create table YBT_UAT.TAXREVENUE
(
  transno         VARCHAR2(20) not null,
  residentcountry VARCHAR2(100),
  residentnumber  VARCHAR2(20),
  residentdesc    VARCHAR2(100),
  bak1            VARCHAR2(100),
  bak2            VARCHAR2(100),
  bak3            VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TRACERT
prompt ======================
prompt
create table YBT_UAT.TRACERT
(
  tid      VARCHAR2(22),
  username VARCHAR2(22),
  opdate   DATE,
  optime   VARCHAR2(8),
  matter   VARCHAR2(160),
  states   VARCHAR2(160),
  jspname  VARCHAR2(160)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );


spool off
